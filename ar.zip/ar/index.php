<?php
define('LEVEL','1');
define('LANGUAGE','ar');
define('COUNTRY_ID','66124');
require_once(dirname(__FILE__) . '/../index.php');
