   <div class="container  " id="">
				   <div class="row">
                     <div class="col-md-12">
                     </div>
                     <div class="col-md-12 seperate_mar">
                        <div>
<div class="_1ws65d643" style="position:relative;"><div style="margin-top: 24px;"></div><span style="font-size: 0px;"></span><div class="_1ws65d6"><div class="_1v8tiivp"><div class="_1671pmsc"><div class="_18q6tiq" style="padding-top: 52%; background: rgb(216, 216, 216) none repeat scroll 0% 0%;"><div class="_1szwzht"><div class="_e296pg" style="width: 100%; height: 100%;"><div class="_6ikqekk" style="width: 100%; height: 100%; background-image: url('<?php echo $v->AdImage;?>');" role="img" aria-label="Find out how much you could earn hosting your place"></div></div></div></div></div><div class="_ynnb8vg"><div class="_d2f3gw" style="margin-bottom: 4px;"><div><div class="_7c46qo2"><span class="_74l3jy"><?php echo $v->adTitle;?></span></div></div></div><div style="margin-bottom: 12px;"><div><div class="_12n1ibqr"><span class="_16syclo"><?php echo $v->ShortDescription;?></span></div></div></div><a href="#"    class="_16tkiskg" aria-busy="false"><span class="_l8z70zb">Find out more</span></a></div></div></div>
			<div class="clearfix"></div>
</div>
	 </div>
                      </div>
                  </div>
				   
				   </div>
