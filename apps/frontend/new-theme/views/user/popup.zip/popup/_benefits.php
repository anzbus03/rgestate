<div class="lastrow   margin-top-5"><span class="pull-left bg-warning"><i class="fa fa-info-circle"></i> We won't share your personal details with anyone</span><div class="clearfix"></div></div>
<div class="col-md-12 bck-header-1">
                <div class="col-sm-2 pentagon"></div>
                <div class="col-sm-10 pentagon-icon-div">
                    <h5>
                        <i class="fa fa-users header-icon" style="margin-top:20px;"></i> 
                        <span class="headeri"  >Benefits of Login / Register</span>
                    </h5>
                </div>
                <div class="clearfix"></div>
            </div>
            
<div class="col-md-12 content-pad-0" style="min-height:260px;overflow-y:auto;text-align:justify;" id="memberAlert">
                    <ul class="content-ul">  
                        <li><i class="fa fa-caret-right icon-brown"></i><span>Protect yourself from Fraud</span></li>
                        <li><i class="fa fa-caret-right icon-brown"></i><span>Feeta – Safer place to buy and sell</span></li>
                        <li><i class="fa fa-caret-right icon-brown"></i><span>Save your favourite items in 1 place</span></li>
                        <li><i class="fa fa-caret-right icon-brown"></i><span>Improve customer support</span></li>
                    </ul>
                </div> 
 
 
