<?php defined('MW_PATH') || exit('No direct script access allowed');?>
 
 
<div class="container">

	<div class="row">
	
		<div class="col-md-12">
        <!--Tabs -->
        <div class="sign-in-form style-1">
           
             <h4 class="subheading_font row bold-style">Login Verification Code</h4>
          <div class="tabs-container alt"> 
<div class="clearfix"></div>
				<div class="clearfix"></div>
			<p class="sentacode">We sent a 4-digit code to <strong><?php echo $model->email; ?></strong></p>
            <!-- Login -->
			<div class="tab-content" id="tab1" style="border-top: 0px solid #e0e0e0;">
		   <div class=" "> 
 
            <!-- Login -->
							<div class="tab-content padding-top-0" id="tab1" style="border-top:0px;">
							<?php $form=$this->beginWidget('CActiveForm', array(
							'id'=>'login-form',
							'enableAjaxValidation'=>false,
							'clientOptions' => array(
							'validateOnSubmit'=>true,
							'validateOnChange'=>false,
							'validateOnType'=>true,
							),
							)); ?>
							<div id="right-col">


							<div id="signin-form">


								<div class="form-group  ">

						    <div class="row">

							<div class="col-sm-5"><?php echo $form->labelEx($user ,'otp_false');?></div>

							<div class="col-sm-7">

							<?php  
							 
							echo $form->textField($user , 'otp_false' ,  $user->getHtmlOptions('otp_false',array('class'=>'input-text form-control','placeholder'=>'' ,'maxlength'=>'4' ,'oninput'=>"this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');")));  ?>

							<?php echo $form->error($user, 'otp_false');?>

							</div>

							</div>
		</div> 

							<div class="form-group  ">

						    <div class="row">

							<div class="col-sm-5">&nbsp;</div>

							<div class="col-sm-7">

							<button  type="submit" class="btn btn-primary btn-block headfont btn-sm-s"  />Verify Code</button>
			<?php
							 $link =   Yii::app()->createUrl('user/Resend_otop_email',array('email'=>$email))  ; ?>
                            <a href="javascript:void(0)" data-href="<?php echo  $link;?>" onclick="sendOtpAgain(this)" class="bld-link2">Resend Verification Code?</a>
							</div>
		</div> 
							</div><!-- end #signin-form -->
							</div><!-- end #right-col -->
							<?php $this->endWidget();?>

			</div>

			<!-- Register -->
		 
            </div>
         	</div>

			<!-- Register -->
		 
            </div>
          </div>
       

		

		</div>
		 
		
	 </div>

</div>
<?php $this->renderPartial('popup/_benefits');?>
<script>
function sendOtpAgain(k){
	var hrf =  $(k).attr('data-href') ;
	$(k).html('Sending..') 
    $(k).removeAttr('onclick');
	$.get(hrf,function(data){ 
		if(data=='1'){
			$(k).hide();
		}
		else{
			alert("Failed to send code!!!")
		}
		
		})
}
</script>
