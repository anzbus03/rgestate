<?php defined('MW_PATH') || exit('No direct script access allowed');?>
<div class="container">
	<div class="row" id="login_opt">
		<div class="col-md-12">
        <!--Tabs -->
        <div class="sign-in-form style-1">
             <h4 class="subheading_font row bold-style">Log in to Feeta</h4>
          <div class="tabs-container alt"> 
<div class="clearfix"></div>
				<div class="clearfix"></div>
            <!-- Login -->
			<div  style="border-top: 0px solid #e0e0e0;">
		   <div class=" "> 
            <!-- Login -->
							<div class=" padding-top-0" style="border-top:0px;">
							 
							 <a href="<?php echo Yii::app()->createUrl('user/signin_phone_popup');?>" onclick="easyload(this,event,'pajax')" class="kbyheJ">Continue with Mobile Number</a>
							<a href="<?php echo Yii::app()->createUrl('user/signin_popup');?>" onclick="easyload(this,event,'pajax')" class="jilpeK">Continue with Email</a>
			</div>

			<!-- Register -->
	       </div>
         	</div>

			<!-- Register -->
		 
            </div>
          </div>
		</div>
	 </div>
</div>
<?php $this->renderPartial('popup/_benefits');?>
