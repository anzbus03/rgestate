<?php $this->renderPartial('grid',array('row'=>$row));?>
<?php $this->renderPartial('ad_iems_form');?>
