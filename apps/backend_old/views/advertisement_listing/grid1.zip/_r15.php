<?php $this->renderPartial('grid1',array('row'=>$row));?>
<?php $this->renderPartial('ad_iems_form');?>
