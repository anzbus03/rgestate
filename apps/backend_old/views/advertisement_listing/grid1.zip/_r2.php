<?php $this->renderPartial('grid2');?>
<?php $this->renderPartial('ad_iems_form');?>
