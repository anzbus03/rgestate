<?php $this->renderPartial('grid1slider',array('row'=>$row));?>
<?php $this->renderPartial('ad_iems_form');?>
