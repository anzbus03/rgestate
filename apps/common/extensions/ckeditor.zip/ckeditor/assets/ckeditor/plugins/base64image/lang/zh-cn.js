/*
Translation from original CKEDITOR language files:
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("base64image","zh-cn",{
	"alt":"替换文本",
	"lockRatio":"锁定比例",
	"vSpace":"垂直间距",
	"hSpace":"水平间距",
	"border":"边框大小"
});