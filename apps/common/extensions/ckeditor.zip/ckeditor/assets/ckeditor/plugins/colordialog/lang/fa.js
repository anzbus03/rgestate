/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'colordialog', 'fa', {
	clear: 'پاک کردن',
	highlight: 'متمایز',
	options: 'گزینه​های رنگ',
	selected: 'رنگ انتخاب شده',
	title: 'انتخاب رنگ'
} );
