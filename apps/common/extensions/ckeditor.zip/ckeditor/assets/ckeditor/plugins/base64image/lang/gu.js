/*
Translation from original CKEDITOR language files:
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("base64image","gu",{
	"alt":"ઑલ્ટર્નટ ટેક્સ્ટ",
	"lockRatio":"લૉક ગુણોત્તર",
	"vSpace":"લંબરૂપ જગ્યા",
	"hSpace":"સમસ્તરીય જગ્યા",
	"border":"બોર્ડર"
});