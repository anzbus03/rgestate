/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'colordialog', 'no', {
	clear: 'Tøm',
	highlight: 'Merk',
	options: 'Alternativer for farge',
	selected: 'Valgt',
	title: 'Velg farge'
} );
