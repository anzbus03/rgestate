<?php defined('MW_PATH') || exit('No direct script access allowed');

/**
 * PricePlanOrder
 * 
 * @package MailWizz EMA
 * @author Serban George Cristian <cristian.serban@mailwizz.com> 
 * @link http://www.mailwizz.com/
 * @copyright 2013-2017 MailWizz EMA (http://www.mailwizz.com)
 * @license http://www.mailwizz.com/license/
 * @since 1.3.4.4
 */

/**
 * This is the model class for table "{{price_plan_order}}".
 *
 * The followings are the available columns in table '{{price_plan_order}}':
 * @property integer $order_id
 * @property string $order_uid
 * @property integer $customer_id
 * @property integer $plan_id
 * @property integer $promo_code_id
 * @property integer $tax_id
 * @property integer $currency_id
 * @property string $subtotal
 * @property string $tax_percent
 * @property string $tax_value
 * @property string $discount
 * @property string $total
 * @property string $status
 * @property string $date_added
 * @property string $last_updated
 *
 * The followings are the available model relations:
 * @property Tax $tax
 * @property PricePlan $plan
 * @property Customer $customer
 * @property PricePlanPromoCode $promoCode
 * @property Currency $currency
 * @property PricePlanOrderNote[] $notes
 * @property PricePlanOrderTransaction[] $transactions
 */
class PricePlanOrder extends ActiveRecord
{
    const STATUS_INCOMPLETE = 'incomplete';
    
    const STATUS_COMPLETE = 'complete';
    
    const STATUS_PENDING = 'pending';
    
    const STATUS_FAILED = 'failed';
    
    const STATUS_REFUNDED = 'refunded';
    
    const STATUS_DUE = 'due';
     const STATUS_TRASHED = 'trash';
    
    protected $_initStatus;
    public $t_allowed;
    public $d_allowed;
    public $promo_allowed;
    public $team_manager;
    public $expired;
    public $active;
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return '{{price_plan_order}}';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		$rules = array(
			array('customer_id, plan_id,     payment_type,date_start', 'required'),
			array('created_by,show_trash,promo_allowed,is_offer', 'safe'),
			array('customer_id, plan_id, promo_code_id, currency_id, tax_id', 'numerical', 'integerOnly' => true),
			array('subtotal, discount, total, tax_value, tax_percent', 'numerical'),
            array('subtotal, discount, total, tax_value, tax_percent', 'type', 'type' => 'float'),
			array('status', 'in', 'range' => array_keys($this->getStatusesList())),
			array('ads_used,validity,no_of_featured,max_listing_per_day,no_of_users,valuation,photography,campain,seo,blog,banners,floor,email_campain,team_manager,expired,active', 'safe'),
			
            // The following rule is used by search().
			array('order_uid, customer_id, plan_id, promo_code_id, currency_id, tax_id, subtotal, tax_value, tax_percent, discount, total, status,from_date,to_date,show_all,d_allowed,t_allowed', 'safe', 'on'=>'search'),
            array('subtotal, tax_value, discount, total', 'safe', 'on'=>'customer-search'),
		);
        return CMap::mergeArray($rules, parent::rules());
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		$relations = array(
            'tax'            => array(self::BELONGS_TO, 'Tax', 'tax_id'),
			'plan'           => array(self::BELONGS_TO, 'Package', 'plan_id'),
			'customer'       => array(self::BELONGS_TO, 'ListingUsers', 'customer_id'),
			'deletedby'       => array(self::BELONGS_TO, 'User', 'deleted_by'),
			'sales_person'       => array(self::BELONGS_TO, 'User', 'created_by'),
			'promoCode'      => array(self::BELONGS_TO, 'PricePlanPromoCode', 'promo_code_id'),
			'currency'       => array(self::BELONGS_TO, 'Currency', 'currency_id'),
            'notes'          => array(self::HAS_MANY, 'PricePlanOrderNote', 'order_id'),
            'transactions'   => array(self::HAS_MANY, 'PricePlanOrderTransaction', 'order_id'),
		);
        return CMap::mergeArray($relations, parent::relations());
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		$labels = array(
			'max_listing_per_day'    => Yii::t('orders', 'No. of Property List'),
			
			'order_id'       => Yii::t('orders', $this->mTag()->getTag('order','Order')),
			'order_uid'      => Yii::t('orders', $this->mTag()->getTag('order_no.','Order no.')),
			'customer_id'    => Yii::t('orders', 'Customer'),
			'plan_id'        => Yii::t('orders', 'Package'),
			'promo_code_id'  => Yii::t('orders', 'Promo code'),
            'tax_id'         => Yii::t('orders', 'Tax'),
			'currency_id'    => Yii::t('orders', 'Currency'),
			'subtotal'       => Yii::t('orders', $this->mTag()->getTag('gross_amount','Gross Amount')),
            'tax_percent'    => Yii::t('orders', 'Tax percent'),
            'tax_value'      => Yii::t('orders',  $this->mTag()->getTag('vat_amount','VAT Amount')),
			'discount'       => Yii::t('orders', $this->mTag()->getTag('discount','Discount') ),
			'total'          => Yii::t('orders', $this->mTag()->getTag('net_cost','Net Cost') ),
			'total1'          => Yii::t('orders', $this->mTag()->getTag('total_amount','Total Amount')),
			'option'          => Yii::t('orders', $this->mTag()->getTag('options','Options')),
			'total3'            =>  Yii::t('orders', 'Total'),
			 'valuation' => 'Valuation and Mortgage',
            'photography' => 'Photography',
            'campain' => 'Social Media Campaign (Media Buying)',
            'seo' => 'SEO/SEM',
            'blog' => 'Blog upload PRL for client',
            'banners' => 'Banners',
            'floor' => 'Floor Plan',
             'email_campain' => 'Email campain',
            'details' =>  $this->mTag()->getTag('products/services','Products/Services'),
            'statusm' => $this->mTag()->getTag('status','Status'),
            'order_date' => $this->mTag()->getTag('order_date','Order Date'),
            'contract_period' => $this->mTag()->getTag('contract_period','Contract Period'),
            'duration' => $this->mTag()->getTag('duration','Duration'),
            'date' => $this->mTag()->getTag('date','Date'),
            'pricing' => $this->mTag()->getTag('pricing','Pricing'),
		);
        return CMap::mergeArray($labels, parent::attributeLabels());
	}
	
	    public function getPaymentName($status1 = null)
    {
        if (!$status1 && $this->hasAttribute('payment_type')) {
            $status1 = $this->payment_type;
        }
        if (!$status1) {
            return;
        }
        $list = $this->paymentArray();
        return isset($list[$status1]) ? $list[$status1] : Yii::t('app', ucfirst(preg_replace('/[^a-z]/', ' ', strtolower($status1))));
    }
		public function paymentArray(){
		return array(
		 'o' => 'Offer',
		'b' => $this->mTag()->getTag('bank_transfer/cash','Bank transfer/Cash'),
		'm' => $this->mTag()->getTag('mpgs_-_master_card','MPGS - Master Card'),
		);
	}
	 
	public $total_ordered;
	
	public function calculateTotalBalance($customer_id){
		
		  /*total_used*/
		  $criteria = new CDbCriteria;
		  $criteria->select = 'sum(t.amount) as total_used' ; 
		  $criteria->compare('t.user_id', (int)$customer_id);
		  $criteria->compare('t.status', 'active');
		  $criteria->group = 't.user_id';
		  $total_usedModel = UserPackages::model()->find($criteria);
		  if(empty($total_usedModel)){ $total_used =  0; }
		  else{
			  $total_used =  $total_usedModel->total_used;
		  }
		  
		
		  /*total_paid*/
		  $criteria = new CDbCriteria;
		  $criteria->select = 'sum(COALESCE(t.total,0)-COALESCE(t.tax_value,0)) as total_ordered' ;
		  $criteria->compare('t.customer_id', (int)$customer_id);
		  $criteria->compare('t.status', 'complete');
		  $criteria->group = 't.customer_id';
		  $total_paidMaodel = PricePlanOrder::model()->find($criteria);
		  if(!empty($total_paidMaodel)){ $total_paid = $total_paidMaodel->total_ordered;   }
		  else{
			  $total_paid = 0; 
		  }
		  
		  $account_balance = $total_paid-$total_used;
		  ListingUsers::model()->updateByPk((int) $customer_id,array('amount'=>$account_balance));
	}
    
    /**
     * @return array help text for attributes
     */
    public function attributeHelpTexts()
    {
        $texts = array(
			'customer_id'    => Yii::t('orders', 'The customer this order applies to, autocomplete enabled'),
			'plan_id'        => Yii::t('orders', 'The price plan included in this order, autocomplete enabled'),
			'promo_code_id'  => Yii::t('orders', 'The promo code applied to this order, autocomplete enabled'),
		);
        
        return CMap::mergeArray($texts, parent::attributeHelpTexts());
    }
    
    /**
     * @return array attribute placeholders
     */
    public function attributePlaceholders()
    {
        $placeholders = array(
            'customer_id'    => Yii::t('orders', 'Customer, autocomplete enabled'),
			'plan_id'        => Yii::t('orders', 'Plan, autocomplete enabled'),
			'promo_code_id'  => Yii::t('orders', 'Promo code, autocomplete enabled'),
			'currency_id'    => '',
			'subtotal'       => '0.0000',
			'discount'       => '0.0000',
			'total'          => '0.0000',
		);
        
        return CMap::mergeArray($placeholders, parent::attributePlaceholders());
    }

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	   public $from_date;public $to_date;
		  public $show_all;
		   public $show_trash;
	public function search()
	{
		$criteria = new CDbCriteria;$criteria->condition = '1'; 

        if ($this->customer_id) {
            if (is_string($this->customer_id)) {
                $criteria->with['customer'] = array(
                    'together' => true,
                    'joinType' => 'INNER JOIN',
                    'condition'=> '(CONCAT(customer.first_name, " ", customer.last_name) LIKE :c01 OR customer.email LIKE :c01 OR customer.company_name LIKE :c01)',
                    'params'   => array(':c01' => '%'. $this->customer_id .'%')
                );
            } else {
                $criteria->compare('t.customer_id', (int)$this->customer_id);
            }
        }
        
        if ($this->plan_id) {
            if (is_string($this->plan_id)) {
                $criteria->with['plan'] = array(
                    'together' => true,
                    'joinType' => 'INNER JOIN',
                    'condition'=> 'plan.package_name LIKE :p01',
                    'params'   => array(':p01' => '%'. $this->plan_id .'%')
                );
            } else {
                $criteria->compare('t.plan_id', (int)$this->plan_id);
            }
        }
        
        if ($this->promo_code_id) {
            if (is_string($this->promo_code_id)) {
                $criteria->with['promoCode'] = array(
                    'together' => true,
                    'joinType' => 'INNER JOIN',
                    'condition'=> 'promoCode.code LIKE :pc01',
                    'params'   => array(':pc01' => '%'. $this->promo_code_id .'%')
                );
            } else {
                $criteria->compare('t.promo_code_id', (int)$this->promo_code_id);
            }
        }
        
        if ($this->currency_id) {
            if (is_string($this->currency_id)) {
                $criteria->with['currency'] = array(
                    'together' => true,
                    'joinType' => 'INNER JOIN',
                    'condition'=> 'currency.code LIKE :cr01',
                    'params'   => array(':cr01' => '%'. $this->currency_id .'%')
                );
            } else {
                $criteria->compare('t.currency_id', (int)$this->currency_id);
            }
        }
        
        if ($this->tax_id) {
            if (is_string($this->tax_id)) {
                $criteria->with['tax'] = array(
                    'together' => true,
                    'joinType' => 'INNER JOIN',
                    'condition'=> 'currency.code LIKE :t01',
                    'params'   => array(':t01' => '%'. $this->tax_id .'%')
                );
            } else {
                $criteria->compare('t.tax_id', (int)$this->tax_id);
            }
        }
        
        if(!empty($this->created_by)){
         
                $criteria->select   =   ' t.* ';
            	//$criteria->join  .=   ' INNER   JOIN {{user}} gpu on gpu.user_id = t.created_by ';
            	//$criteria->condition   .=  ' and gpu.group_id = 8 '; 
                if(empty($this->show_all)){
                //    $criteria->compare('created_by',$this->created_by);
            	}
            	  $criteria->join  .=   ' LEFT JOIN {{listing_users}} usr1  on usr1.user_id = t.customer_id ';
           
            $criteria->join  .=   ' LEFT JOIN {{listing_users}} pusr2 on pusr2.user_id = usr1.parent_user ';
            $criteria->condition .=  ' and (CASE WHEN usr1.parent_user is NOT NULL THEN pusr2.created_by ELSE usr1.created_by END) = :team_manager  ' ;	
          	$criteria->params[':team_manager'] = (int) $this->created_by ;
        }
         if(!empty($this->team_manager)){
              $criteria->join  .=   ' LEFT JOIN {{listing_users}} usr1 on usr1.user_id = t.customer_id ';
           
            $criteria->join  .=   ' LEFT JOIN {{listing_users}} pusr2 on pusr2.user_id = usr1.parent_user ';
            $criteria->condition .=  ' and (CASE WHEN usr1.parent_user is NOT NULL THEN pusr2.created_by ELSE usr1.created_by END) = :team_manager  ' ;	
          	$criteria->params[':team_manager'] = (int) $this->team_manager ;
		}
         if(!empty($this->from_date)){
        $criteria->condition .= ' and DATE(t.date_added) >= :fromdate  ' ;
        $criteria->params[':fromdate'] = date('Y-m-d',strtotime($this->from_date));
		}
		if(!empty($this->to_date)){
        $criteria->condition .= ' and DATE(t.date_added) <= :to_date  ' ;
        $criteria->params[':to_date'] = date('Y-m-d',strtotime($this->to_date));
		}
		if(!empty($this->t_allowed)){
		    $criteria->compare('t.tax_value >', '0.1');
		}
		if(!empty($this->d_allowed)){
		    $criteria->compare('t.discount >',  '0.1');
		}
	 
        $criteria->compare('t.payment_type', $this->payment_type);
        $criteria->compare('t.order_uid', $this->order_uid, true);
		$criteria->compare('t.subtotal', $this->subtotal, true);
        $criteria->compare('t.tax_value', $this->tax_value, true);
        $criteria->compare('t.tax_percent', $this->tax_percent, true);
		$criteria->compare('t.discount', $this->discount, true);
		$criteria->compare('t.total', $this->total, true);
		$criteria->compare('t.status', $this->status);
        if(!empty($this->show_trash)){
			$criteria->compare('t.status',self::STATUS_TRASHED);
		}
		else{
			$criteria->compare('t.status!',self::STATUS_TRASHED);
		}
		
		if(!empty($this->promo_allowed)){
		 	$criteria->condition .= ' and t.promo_code_id!=""' ;
		}
		if(!empty($this->expired)){
		    $criteria->condition  .='  and (CASE WHEN t.validity ="0" THEN 1 ELSE  (DATEDIFF(DATE_ADD(DATE(t.date_start), INTERVAL t.validity DAY) , CURDATE())) END ) < 0  and t.status="complete" ';
		   
		}
			if(!empty($this->active)){
		    $criteria->condition  .='  and (CASE WHEN t.validity ="0" THEN 1 ELSE  (DATEDIFF(DATE_ADD(DATE(t.date_start), INTERVAL t.validity DAY) , CURDATE())) END ) >= 0  and t.status="complete" ';
		   
		}
	 
        $criteria->order = 't.order_id DESC';
        
		return new CActiveDataProvider(get_class($this), array(
            'criteria'   => $criteria,
            'pagination' => array(
                'pageSize' => $this->paginationOptions->getPageSize(),
                'pageVar'  => 'page',
            ),
            'sort'=>array(
                'defaultOrder' => array(
                    't.order_id'  => CSort::SORT_DESC,
                ),
            ),
        ));
	}
public $total_payment; 

public function getAdsUsed(){
	return  '(select COALESCE(count(package_used),0) from {{place_an_ad}} utlized where utlized.package_used = t.order_id and utlized.isTrash= "0")';
}
	public function orderStatistics(){
	    	$criteria = new CDbCriteria;
	    	$criteria->condition = '1'; 
	    	$criteria->select ='sum(COALESCE(t.total,0)) as total_payment,sum(COALESCE(t.tax_value,0)) as total,sum(COALESCE(t.discount,0)) as discount,t.date_added';
	    	$criteria->compare('t.status', 'complete');
	    	$criteria->group     = 'MONTH(t.date_added)';
	    	$criteria->limit     = 12;
	    	return self::model()->findAll($criteria);

	}
	public function orderStatisticsdatewise($from_date,$to_date){
	    	$criteria = new CDbCriteria;
	    	$criteria->condition = '1'; 
	    	$criteria->select ='sum(COALESCE(t.total,0)) as total_payment,sum(COALESCE(t.tax_value,0)) as tax_value,sum(COALESCE(t.discount,0)) as discount,t.date_added';
	    	$criteria->compare('t.status', 'complete');
	     
			if(!empty($from_date)){
				$criteria->condition .= ' and DATE(t.date_added) >= :fromDate ';
				$criteria->params[':fromDate']  = date('Y-m-d',strtotime($from_date));
			}
	     
			if(!empty($to_date)){
				$criteria->condition .= ' and DATE(t.date_added) <= :toDate ';
				$criteria->params[':toDate']  = date('Y-m-d',strtotime($to_date));
			}
	    	return self::model()->find($criteria);

	}
	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return PricePlanOrder the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
    const STATUS_TERMINATE = 'terminate';
    public function getStatusesList()
    {
        return array(
            self::STATUS_INCOMPLETE => Yii::t('app', $this->mTag()->getTag('incomplete','Incomplete')),
            self::STATUS_COMPLETE   => Yii::t('app', $this->mTag()->getTag('complete','Complete')),
            self::STATUS_PENDING    => Yii::t('app', $this->mTag()->getTag('pending','Pending')),
            self::STATUS_DUE        => Yii::t('app', $this->mTag()->getTag('due','Due')),
            self::STATUS_FAILED     => Yii::t('app', $this->mTag()->getTag('failed','Failed')),
            self::STATUS_REFUNDED   => Yii::t('app', $this->mTag()->getTag('refunded','Refunded')),
             self::STATUS_TERMINATE   => Yii::t('app', $this->mTag()->getTag('user_terminated','Terminated')),
             self::STATUS_TRASHED   => Yii::t('app', $this->mTag()->getTag('moved_to_trash','Moved To Trash')),
        );
    }
	public function beforeValidate()
    {
        if(!empty($this->date_start)){
			$this->date_start = date('Y-m-d',strtotime($this->date_start));
		}
		else{
			if($this->isNewRecord){
			$this->date_start = date('Y-m-d');
			}
		}
        return parent::beforeValidate();
    }
    protected function beforeSave()
    {
        if (!parent::beforeSave()) {
            return false;
        }
        if($this->isNewRecord and Yii::app()->isAppName('backend')){
			if(empty($this->status) or $this->status==self::STATUS_INCOMPLETE) { $this->status= 'pending'; }
			$this->created_by = Yii::app()->user->getId();
		}
		 
		/*
		if (!empty($this->promo_code_id) && !empty($this->promoCode)) {
            $this->discount = 0;
            
            if ($this->promoCode->type == PricePlanPromoCode::TYPE_FIXED_AMOUNT) {
                $this->discount += $this->promoCode->discount;
            } else {
                $this->discount += (($this->promoCode->discount / 100) * $this->total);
            }
            
             
        }
		$this->applyTaxes2();
		*/
		$this->calculate();
        if (empty($this->order_uid)) {
            $this->order_uid = $this->generateUid();
        }

        if ($this->isNewRecord) {
			$plan = $this->plan;
            $this->validity = $plan->validity_in_days ;
            $this->no_of_featured = $plan->no_of_featured ;
            $this->max_listing_per_day = $plan->max_listing_per_day ;
            $this->no_of_users = $plan->no_of_users ;
            $this->valuation = $plan->valuation ;
            $this->photography = $plan->photography ;
            $this->campain = $plan->campain ;
            $this->seo = $plan->seo ;
            $this->blog = $plan->blog ;
            $this->banners = $plan->banners ;
            $this->floor = $plan->floor ;
            $this->email_campain = $plan->email_campain ;
        }

        return true;
    }

    protected function afterConstruct()
    {
        $this->_initStatus = $this->status;
        if (empty($this->currency_id)) {
            $currency = Currency::model()->findDefault();
            $this->addRelatedRecord('currency', $currency, false);
            $this->currency_id = $currency->currency_id;
        }
        parent::afterConstruct();
    }

    protected function afterFind()
    {
        $this->_initStatus = $this->status;
        parent::afterFind();
    }

    protected function afterSave()
    {
        $options =Yii::app()->options;
        if($this->isNewRecord){
				if($this->is_offer=='1'){
					return false;
				}
				else{
			    $emailTemplate =  CustomerEmailTemplate::model()->findByAttributes(array('template_uid'=>"nz111h3hrv376"));;
			    $customer = $this->customer;
			    if($emailTemplate)
			    {
				 
					$subject		= $emailTemplate->subject;
					$emailTemplate  = $emailTemplate->content;							
					$url 			=   Yii::app()->apps->getAppUrl('backend', 'index.php/orders/update/id/'.$this->order_id, true);
					$emailTemplate = str_replace('[URL]','<a href="'.$url.'">'.$url.'</a>' , $emailTemplate);
					$receipeints = serialize(array($options->get('system.common.admin_email','support@feeta.pk')));
					//$receipeints = serialize(array('njalilvineeth@gmail.com'));
					$status = 'S'; 
					$adminEmail = new Email();			 
					$adminEmail->subject = $subject ;
					$adminEmail->message = $emailTemplate;
					$adminEmail->message = Yii::t('app',$adminEmail->message,array('[INVOICE DETAILS]'=>$this->InvoiceDetails($this,$customer)));
					$adminEmail->status = $status;
					$adminEmail->receipeints = $receipeints;
					$adminEmail->sent_on =   1;
					$adminEmail->type =   'REGISTER';
					$adminEmail->sent_on_utc =   new CDbExpression('NOW()');
					$adminEmail->save(false); 
					$adminEmail->send;
				}
				/*sending to customer*/
				/*
			    $emailTemplate =  CustomerEmailTemplate::model()->findByAttributes(array('template_uid'=>"jp701wpcwm989"));;
			    if($emailTemplate)
			    {
				 
				
					$subject		= $emailTemplate->subject;
					$emailTemplate  = $emailTemplate->content;							
					$receipeints = serialize(array($customer->email));
					//$receipeints = serialize(array('vineethnjalil@gmail.com'));
					$status = 'S'; 
					$adminEmail = new Email();	 
					$adminEmail->subject = $subject ;
					$adminEmail->message = Yii::t('app',$emailTemplate,array('[Customer]'=>$customer->first_name));
					$adminEmail->message = Yii::t('app',$adminEmail->message,array('[INVOICE DETAILS]'=>$this->InvoiceDetails($this,$customer)));
					$adminEmail->status = $status;
					$adminEmail->receipeints = $receipeints;
					$adminEmail->sent_on =   1;
					$adminEmail->type =   'REGISTER';
					$adminEmail->sent_on_utc =   new CDbExpression('NOW()');
					$adminEmail->save(false); 
					$adminEmail->send;
				}
				*/
				}
		}
        
        if (in_array($this->_initStatus, array(self::STATUS_INCOMPLETE, self::STATUS_PENDING, self::STATUS_DUE)) && $this->status == self::STATUS_COMPLETE) {
            
            /*customer*/
             $emailTemplate =  CustomerEmailTemplate::model()->findByAttributes(array('template_uid'=>"jp701wpcwm989"));;
			    if($emailTemplate)
			    {
				 
				    $customer = $this->customer;
					$subject		= $emailTemplate->subject;
					$emailTemplate  = $emailTemplate->content;	
					$emailTemplate_common = $this->commonTemplate()   ;
					$receipeints = serialize(array($customer->email));
					//$receipeints = serialize(array('vineethnjalil@gmail.com'));
					$status = 'S'; 
					$adminEmail = new Email();	 
					$adminEmail->subject = $subject ;
					$adminEmail->message = Yii::t('app',$emailTemplate,array('[Customer]'=>$customer->first_name));
					$adminEmail->message = Yii::t('app',$adminEmail->message,array('[INVOICE DETAILS]'=>$this->InvoiceDetails($this,$customer)));
					$adminEmail->message =   Yii::t('app',$emailTemplate_common, array('[CONTENT]'=>$adminEmail->message)); 
					$adminEmail->status = $status;
					$adminEmail->receipeints = $receipeints;
					$adminEmail->sent_on =   1;
					$adminEmail->type =   'REGISTER';
					$adminEmail->sent_on_utc =   new CDbExpression('NOW()');
					$adminEmail->save(false); 
					$adminEmail->send;
				}
				/*admin*/
				
				$emailTemplate =  CustomerEmailTemplate::model()->findByAttributes(array('template_uid'=>"pl117hej79c7d"));;
			    if($emailTemplate)
			    {
			    	$customer = $this->customer;
				    $admin_email =  $options->get('system.common.admin_email','support@feeta.pk');
					$subject		= Yii::t('app',$emailTemplate->subject,array('[INVOICE NUMBER]'=>$this->order_uid));
					$emailTemplate  = $emailTemplate->content;							
					$receipeints = serialize(array($admin_email));
					//$receipeints = serialize(array('njalilvineeth@gmail.com'));
					$status = 'S'; 
					$adminEmail = new Email();	 
					$adminEmail->subject = $subject ;
					$adminEmail->message = Yii::t('app',$emailTemplate,array('[CUSTOMER]'=>$customer->first_name));
					$adminEmail->message = Yii::t('app',$adminEmail->message,array('[AMOUNT]'=>$this->formattedTotalPaid ,'[INVOICE_NUMBER]'=>$this->order_uid,'[ADMIN_EMAIL]'=>$admin_email ));
					$adminEmail->status = $status;
					$adminEmail->receipeints = $receipeints;
					$adminEmail->sent_on =   1;
					$adminEmail->type =   'REGISTER';
					$adminEmail->sent_on_utc =   new CDbExpression('NOW()');
					$adminEmail->save(false); 
					$adminEmail->send;
				}
				if(!empty($this->no_of_users)){
					ListingUsers::model()->updateByPk($this->customer_id,array('max_no_users'=>$this->no_of_users));
				}
            //$this->customer->group_id = $this->plan->group_id;
            //$this->customer->save(false);
            //$this->customer->createQuotaMark();
        }
        //$this->calculateTotalBalance($this->customer_id);
        parent::afterSave();
    }
    protected function afterDelete()
    {
		 
        //$this->calculateTotalBalance($this->customer_id);

        parent::afterDelete();
    }
    
    public function calculate()
    {
        if (empty($this->plan_id)) {
            return $this;
        }
        
        $this->subtotal = $this->plan->price_per_month;
        $this->total    = $this->plan->price_per_month;
        
        if (!empty($this->promo_code_id) && !empty($this->promoCode)) {
            $this->discount = 0;
            
            if ($this->promoCode->type == PricePlanPromoCode::TYPE_FIXED_AMOUNT) {
                $this->discount += $this->promoCode->discount;
            } else {
                $this->discount += (($this->promoCode->discount / 100) * $this->total);
            }
            
            $this->total -= $this->discount;
            if ($this->total < 0) {
                $this->total = 0;
            }
        }
        
        $this->applyTaxes2();
 
        return $this;
    }
    
    public function getFormattedSubtotal()
    {
		if(defined('BASE_RATE')){
			 
			 $sub_total = number_format($this->subtotal*BASE_RATE,2,'.','') ;
			 $currency_code  =  CURRENCY_CODE;
		}
		else{
			$sub_total =  $this->subtotal;
			$currency_code  =  $this->currency->code;
		}
		
        return Yii::app()->numberFormatter->formatCurrency($sub_total,  $currency_code);
    }
    
    public function getFormattedTaxPercent()
    {
       
       
       
        return Yii::app()->format->formatNumber($this->tax_percent) . '%';
    }
    
      public function getFormattedTaxValue()
    {
		
		if(defined('BASE_RATE')){
			 $sub_total = number_format($this->tax_value*BASE_RATE,2,'.','') ;
			 $currency_code  =  CURRENCY_CODE;
		}
		else{
			$sub_total =  $this->tax_value;
			$currency_code  =  $this->currency->code;
		}
		
        return Yii::app()->numberFormatter->formatCurrency($sub_total,  $currency_code);
		
       // return Yii::app()->numberFormatter->formatCurrency($this->tax_value, $this->currency->code);
    }
    
    public function getFormattedDiscount()
    {
		
		if(defined('BASE_RATE')){
			 $sub_total = number_format($this->discount*BASE_RATE,2,'.','') ;
			 $currency_code  =  CURRENCY_CODE;
		}
		else{
			$sub_total =  $this->discount;
			$currency_code  =  $this->currency->code;
		}
		
        return Yii::app()->numberFormatter->formatCurrency($sub_total,  $currency_code);
        //return Yii::app()->numberFormatter->formatCurrency($this->discount, $this->currency->code);
    }
    
    public function getFormattedTotal()
    {
		
		if(defined('BASE_RATE')){
			 $sub_total = number_format($this->total*BASE_RATE,2,'.','') ;
			 $currency_code  =  CURRENCY_CODE;
		}
		else{
			$sub_total =  $this->total;
			$currency_code  =  $this->currency->code;
		}
		
        return Yii::app()->numberFormatter->formatCurrency($sub_total,  $currency_code);
        //return Yii::app()->numberFormatter->formatCurrency($this->total,  $this->currency->code);
    }
 
        public function getFormattedTotalPaid()
    {
		if(!empty($this->discount)){
         return Yii::app()->numberFormatter->formatCurrency($this->total - $this->discount,  $this->currency->code);
		}else{
		 return Yii::app()->numberFormatter->formatCurrency($this->total, $this->currency->code);
		}
    }
     public function getFormattedTotalTopup()
    {
		if(!empty($this->tax)){
         return Yii::app()->numberFormatter->formatCurrency($this->total - $this->tax_value,  $this->currency->code);
		}else{
		 return Yii::app()->numberFormatter->formatCurrency($this->total,  $this->currency->code);
		}
    }
    public function findByUid($order_uid)
    {
        return $this->findByAttributes(array(
            'order_uid' => $order_uid,
        ));    
    }
    
    public function generateUid()
    {
        //$unique = date('ydm-His');
        $unique  =  date('ydm-His').'-'.rand(10,100);
        $exists = $this->findByUid($unique);
        
        if (!empty($exists)) {
            return $this->generateUid();
        }
        
        return $unique;
    }

    public function getUid()
    {
        return $this->order_uid;
    }
    
    public function applyTaxes()
    {
        if (empty($this->customer_id)) {
            return $this;
        }
        
        if ($this->tax_id !== null && $this->tax_percent > 0 && $this->tax_value > 0) {
            return $this;
        }
        
        if (empty($this->tax_id) || empty($this->tax)) {
            $tax = $zoneTax = $countryTax = null;
            $globalTax = Tax::model()->findByAttributes(array('is_global' => Tax::TEXT_YES));
            /*
            if (!empty($this->customer) && !empty($this->customer->company)) {
                $company  = $this->customer->company;
                $zoneTax  = Tax::model()->findByAttributes(array('zone_id' => (int)$company->zone_id));
                if (empty($zoneTax)) {
                    $countryTax = Tax::model()->findByAttributes(array('country_id' => (int)$company->country_id));
                }
            }
            * */
            
            if (!empty($zoneTax)) {
                $tax = $zoneTax;
            } elseif (!empty($countryTax)) {
                $tax = $countryTax;
            } elseif (!empty($globalTax)) {
                $tax = $globalTax;
            } else {
                return $this;
            }
            
            if ($tax->percent < 0.1) {
                return $this;
            }
            
            $this->tax_id = $tax->tax_id;
            $this->addRelatedRecord('tax', $tax, false);    
        }
        
        
        $this->tax_percent = $this->tax->percent;
        $this->tax_value   = ($this->tax->percent / 100) * $this->total;
        $this->total += $this->tax_value;
        
        return $this;
    }
    
    public function getHtmlPaymentFrom($headingTag = 'strong', $separator = '<br />')
    {
        if (empty($this->customer_id)) {
            return;
        }
        
        $customer    = $this->customer;
        $paymentFrom = array();
        
        if ($headingTag !== null && $headingTag != "\n") {
            $paymentFrom[] = CHtml::tag($headingTag, array(), $customer->getFullName());
        } else {
            $paymentFrom[] = $customer->getFullName();
        }
        
        
        $paymentFrom[] = $customer->email;
        
        return implode($separator, $paymentFrom);
    }
    
    public function getHtmlPaymentTo($headingTag = 'strong', $separator = '<br />')
    {
        if (empty($this->customer_id)) {
            return;
        }
        
        $customer  = $this->customer;
        $paymentTo = array();
        
        if ($headingTag !== null && $headingTag != "\n") {
            $paymentTo[] = CHtml::tag($headingTag, array(), Yii::app()->options->get('system.common.site_name'));
        } else {
            $paymentTo[] = Yii::app()->options->get('system.common.site_name');
        }
        
        if ($separator !== null && $separator != "\n") {
            $paymentTo[] = nl2br(Yii::app()->options->get('system.common.company_info'));
        } else {
            $paymentTo[] = Yii::app()->options->get('system.common.company_info');
        }
        
        return implode($separator, $paymentTo);
    }
    
    public function getIsComplete()
    {
        return $this->status == self::STATUS_COMPLETE;
    }
     
	public function InvoiceDetails($order,$customer){
		$html  = '<table width="100%" height="100%" cellspacing="0" cellpadding="0" border="0"  align="center">
   <tbody>
      <tr>
         <td>
            <table width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
               <tbody>
              
                  <tr>
                     <td width="100%" align="center">
                        <table width="100%" cellspacing="0" cellpadding="0" border="0" bgcolor="#ffffff" align="center">
                           <tbody>
                          
                              <tr>
                                 <td style="color:#0e1724;text-align:left;font-size:16px;line-height:28px" width="100%" align="center">
                                    <table width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
                                       <tbody>
                                         
                                          <tr>
                                             <td colspan="3" style="padding:0;margin:0;font-size:1;line-height:0">
                                                <h2 style="color:#404040;font-size:22px;font-weight:bold;line-height:26px;padding:0px 30px;margin:0">
                                                   Invoice Details                                
                                                </h2>
                                             </td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </td>
                              </tr>
                                  
                               
                                                    
                                  <tr>
									 
                                 <td style="color:#0e1724;text-align:left;font-size:16px;line-height:28px" width="100%" align="center">
                                    <table width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
                                       <tbody>
                                          <tr>
											    <td width="30"> </td>
                                       
                                             <td   style="padding:0;margin:0;width:calc(100% - 30px;) ">
                                                 <table  width="100%" cellspacing="0"   style="font-size:13px;line-height:22px;  "cellpadding="0" border="0" align="center">
                                                 	 <tr><td>Invoice No#</td><td>'.$order->order_uid.'</td></tr>
													 <tr><td>Invoice Date</td><td>'. date('d-m-Y',strtotime($order->dateAdded)).'</td></tr>
                                                
													 <tr><td>COMPANY NAME:</td><td>'. $customer->company_name.'</td></tr>
													 <tr><td>PERSON NAME:</td><td>'. $customer->first_name.' ['. $customer->email.']</td></tr>
													 <tr><td>PHONE:</td><td>'.$customer->full_number.'</td></tr>';
													 if(!empty($order->created_by)){ 
														 
													 $sates_person = $order->sales_person;	 
													$html .= '<tr><td>SALES PERSON:</td><td>'.$sates_person->first_name.' '.$sates_person->last_name.'('.$sates_person->email.')</td></tr>';
													  }   
                                          
                                                 $html .= '<tr> <td   height="20"></td> </tr></table>
                                             </td>
                                             </td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </td>
                              </tr>
                              <tr>
                                 <td width="100%" align="center">
                                    <table width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
                                       <tbody>
                                          <tr bgcolor="#ffffff">
                                             <td width="30"></td>
                                             <td>
                                                <table width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
                                                   <tbody>
                                               
                                                    
                                                     
                                                      <tr>
                                                         <td colspan="3">
                                                      
                                                            <table  style="font-size:13px;line-height:22px;  " width="100%" cellspacing="0" cellpadding="0" border="0" bgcolor="#ffffff" align="center">
                                                               <tbody>
                                                                  <tr>
                                                                     <td style="padding:16px 0" width="calc(100% - 150px)" valign="top" height="86" align="left">
                                                                       <table class="table"  style="font-size:13px;line-height:22px;  text-align: left;width: 100%;  ">
                  
                    <tbody>
						 <tr>
                        <th>'.Yii::t('orders',$order->getAttributeLabel('subtotal')).':</th>
                        <td>'. $order->formattedSubtotal.'</td>
                    </tr>';
                    
                    if(!empty($order->tax_id)) { 
                        	$html .= '<tr>
                        <th>'.Yii::t('orders', $order->getAttributeLabel('tax_value')).':</th>
                        <td>'.$order->formattedTaxValue.'</td>
                    </tr> '; 
                      }  
                      
                       if(!empty($order->discount)) { 
                        	$html .= '<tr>
                        <th>'.Yii::t('orders', $order->getAttributeLabel('discount')).':</th>
                        <td>'.$order->formattedDiscount.'</td>
                    </tr> '; 
                      }  
                      
                      
                    	$html .= ' 
                    <tr>
                        <th>'.Yii::t('orders', $order->getAttributeLabel('total')).':</th>
                        <td>'.$order->formattedTotal.'</td>
                    </tr>
                    <tr> 
                    <tr>
                        <th>'.Yii::t('orders', 'Status').':</th>
                        <td>'.$order->statusName.'</td>
                    </tr>
                </tbody></table>
                                                                     </td>
                                                                     <td width="20"></td>
                                                                  </tr>
                                                                  <tr>
                                                                     <td     bgcolor="#fff"><a href="'.ASKAAN_PATH_BASE.'site/pdf/order_uid/'.base64_encode($order->order_id).'" style="color:#fff;background:#f27f52;padding:7px 10px; text-decoration: none;">Download Invoice</a></td>
                                                                  </tr>
                                                                
                                                                     
                                                               </tbody>
                                                            </table>
                                                         </td>
                                                      </tr>
                                                   </tbody>
                                                </table>
                                             </td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </td>
                              </tr>
                           </tbody>
                        </table>
                     </td>
                  </tr>
               </tbody>
            </table>
         </td>
      </tr>
   </tbody>
</table>';
return $html ; 
	}
public function applyTaxes2()
    {
        if (empty($this->customer_id)) {
            return $this;
        }
        
        /*
        if ($this->tax_id !== null && $this->tax_percent > 0 && $this->tax_value > 0) {
            return $this;
        }
        */ 
        if (empty($this->tax_id) || empty($this->tax)) {
            $tax = $zoneTax = $countryTax = null;
            $globalTax = Tax::model()->findByAttributes(array('is_global' => Tax::TEXT_YES));
            if (!empty($zoneTax)) {
                $tax = $zoneTax;
            } elseif (!empty($countryTax)) {
                $tax = $countryTax;
            } elseif (!empty($globalTax)) {
                $tax = $globalTax;
            } else {
                return $this;
            }
            
            if ($tax->percent < 0.1) {
                return $this;
            }
            
            $this->tax_id = $tax->tax_id;
            $this->addRelatedRecord('tax', $tax, false);    
        }
        
        
        $this->tax_percent = $this->tax->percent;
        $this->tax_value   = ($this->tax->percent / 100) * $this->total;
        $this->total += $this->tax_value;
        
        return $this;
    }
    public $available_listings;
    public $validity_in_days;
    public $avaliable_featured_listing;
    public $days_remaining;
    public $package_name;
    
    public function getContract_date(){
		if(empty($this->validity)){ return 'Unlimited'; }
		else{
			return $this->mTag()->getTag('start_date','Start Date').' : <span dir="ltr">'.date('d-m-Y',strtotime($this->date_start)).'</span>  <br />'.$this->mTag()->getTag('end_date','End Date').' : <span dir="ltr">'.date('d-m-Y', strtotime($this->date_start. ' '.$this->validity.'  days')) .'</span> ';
		}
	}
	public function getValidityTitle(){
		$ar = $this->getListingPackageMonthly();
		return isset($ar[$this->validity]) ? $ar[$this->validity] : '';
	}
	public function getListingPackageMonthly(){
		$nmonths = $this->mTag()->getTag('{n}_months','{n} Months');
		return array(
			'0'=> $this->mTag()->getTag('unlimited','Unlimited'),
			'30'=> Yii::t('app', $this->mTag()->getTag('{n}_month','{n} Month'),array('{n}'=>'1')),
			'90'=> Yii::t('app',$nmonths,array('{n}'=>'3')),
			'180'=>Yii::t('app',$nmonths,array('{n}'=>'6')),
			'270'=> Yii::t('app',$nmonths,array('{n}'=>'9')),
			'360'=> Yii::t('app',$nmonths,array('{n}'=>'12')),
			'720'=> Yii::t('app',$nmonths,array('{n}'=>'24')),
			'1080'=> Yii::t('app',$nmonths,array('{n}'=>'36')),
		);
	}
	public $used_query = '((SELECT   COALESCE(count(ad_id),0)    FROM {{featured_date}} f_used  where f_used.order_id = t.order_id and f_used.f_type="F")  - (SELECT COALESCE(count(order_id),0)   FROM {{featured_date}} f_unused  where f_unused.order_id = t.order_id and f_unused.f_type="U")) ';
	
	
    public function userActiveListingPackageAll($user_id  ){
		
		$criteria=new CDbCriteria;
			$criteria->select = "t.order_uid,t.order_id,t.no_of_featured,t.max_listing_per_day,package.package_name,((CASE WHEN t.max_listing_per_day = '0' THEN 1000000 ELSE t.max_listing_per_day END)-".$this->AdsUsed.") as available_listings ,  (t.no_of_featured-".$this->used_query.") as avaliable_featured_listing,DATEDIFF( DATE_ADD( t.date_start, INTERVAL t.validity  DAY),  NOW()  ) as   days_remaining";
			 $criteria->join = "INNER JOIN {{package}} package on t.plan_id = package.package_id ";
			$criteria->condition = "t.customer_id = :me and t.status = :complete and ((((CASE WHEN t.max_listing_per_day = '0' THEN 1000000 ELSE t.max_listing_per_day END)-".$this->AdsUsed.") > 0 ) or ((t.no_of_featured-".$this->used_query.") > 0 )) ";
			$criteria->condition .= ' and CASE WHEN t.validity = "0" THEN 1 ELSE  DATEDIFF( NOW(), t.date_start  ) <=  t.validity END  and t.date_start <= CURDATE()  '; 
			$criteria->params[':me'] = (int)$user_id;
			$criteria->params[':complete'] = self::STATUS_COMPLETE;
			return PricePlanOrder::model()->findAll($criteria);
	}
    public function userActiveListingPackage($user_id  ){
			$criteria=new CDbCriteria;
			$criteria->select = "sum((CASE WHEN t.max_listing_per_day = '0' THEN 1000000 ELSE t.max_listing_per_day END)-".$this->AdsUsed.") as available_listings";
			//$criteria->join = "INNER JOIN {{package}} package on t.plan_id = package.package_id ";
			$criteria->condition = "t.customer_id = :me and t.status = :complete and ((CASE WHEN t.max_listing_per_day = '0' THEN 1000000 ELSE t.max_listing_per_day END)-".$this->AdsUsed.") > 0 ";
			$criteria->condition .= '  and CASE WHEN t.validity = "0" THEN 1 ELSE    DATEDIFF( NOW(), t.date_start  ) <=  t.validity END  and t.date_start <= CURDATE() '; 
			$criteria->group  = 't.customer_id'; 
			$criteria->params[':me'] = (int)$user_id;
			$criteria->params[':complete'] = self::STATUS_COMPLETE;
			return PricePlanOrder::model()->find($criteria);
	}
    public function userActivePackageId($user_id){
			$criteria=new CDbCriteria;
			$criteria->select = "t.order_id  ";
			//$criteria->join = "INNER JOIN {{package}} package on t.plan_id = package.package_id ";
			$criteria->condition = "t.customer_id = :me and t.status = :complete and ((CASE WHEN t.max_listing_per_day = '0' THEN 1000000 ELSE t.max_listing_per_day END)-".$this->AdsUsed.") > 0 ";
			$criteria->condition .= '  and CASE WHEN t.validity = "0" THEN 1 ELSE    DATEDIFF( NOW(), t.date_start  ) <=  t.validity END  and t.date_start <= CURDATE() '; 
			$criteria->order =  'DATEDIFF( DATE_ADD( t.date_start, INTERVAL t.validity  DAY),  NOW()  ) ASC ,  t.order_id asc' ;
			$criteria->params[':me'] = (int)$user_id;
			$criteria->params[':complete'] = self::STATUS_COMPLETE;
			return PricePlanOrder::model()->find($criteria);
			 
	}
    public function getvalidateUserFeatured($user_id){
			$criteria=new CDbCriteria;
			$criteria->select = "t.order_id  ";
			//$criteria->join = "INNER JOIN {{package}} package on t.plan_id = package.package_id ";
			$criteria->condition = "t.customer_id = :me and t.status = :complete and (t.no_of_featured-".$this->used_query.") > 0 ";
			$criteria->condition .= '  and CASE WHEN t.validity = "0" THEN 1 ELSE   DATEDIFF( NOW(), t.date_start  ) <=  t.validity END  and t.date_start <= CURDATE() '; 
			$criteria->order =  'DATEDIFF( DATE_ADD( t.date_start, INTERVAL t.validity  DAY),  NOW()  ) ASC ,  t.order_id asc' ;
			$criteria->params[':me'] = (int)$user_id;
			$criteria->params[':complete'] = self::STATUS_COMPLETE;
			return PricePlanOrder::model()->find($criteria);
			 
	}
	
	public function getPackageDetails(){
		
		$html = '<ul class="package-detail-ul">';
						 	    
									   
								 	
										 
										if($this->max_listing_per_day !=''){
											$tot = $this->max_listing_per_day== 0  ? $this->mTag()->gettag('unlimited','Unlimited') :  (int) $this->max_listing_per_day;
											$html.=  '<li>'.Yii::t('app',$this->mTag()->getTag('{fl}_featured_listing_out_of_{','{fl} Featured Listing out of {st}  Standard Listing'),array('{fl}'=>'<b>'.(int) $this->no_of_featured.'</b>','{st}'=>'<b>'.$tot.'</b>')).'</li>';
										}
										if(!empty($this->no_of_users)){
											$html.=  '<li>'.Yii::t('app',$this->mTag()->getTag('{n}_user_accounts','{n} User Accounts'),array('{n}'=>'<b>'.(int) $this->no_of_users.'</b>')).'</li>';
										}
										
										 
										if(!empty($this->valuation)){
										$html.= '<li>'.$this->getAttributeLabel('valuation').'</li>';
										}
										if(!empty($this->photography)){
										$html.= '<li>'.$this->getAttributeLabel('photography').'</li>';
										}
										if(!empty($this->campain)){
										$html.= '<li>'.$this->getAttributeLabel('campain').'</li>';
										}
										if(!empty($this->seo)){
										$html.= '<li>'.$this->getAttributeLabel('seo').'</li>';
										}
										if(!empty($this->blog)){
										$html.= '<li>'.$this->getAttributeLabel('blog').'</li>';
										}
										if(!empty($this->banners)){
										$html.= '<li>'.$this->getAttributeLabel('banners').'</li>';
										}
									
										if(!empty($this->validity)){
											$html.= '<li class="druth" >'.Yii::t('app',$this->mTag()->getTag('{n}_vallidity','{n} vallidity'),array('{n}'=>'<b>'.$this->ValidityTitle.'</b>')).'</li>';
										
										}
								 
							
							 $html.= '</ul>';
						 
		return $html;
	 
	}
	public function getOrderLi(){
		$html  = '<div class="ordr-det">';
		$html .= '<h1 class="sml-header druth">'.$this->getAttributeLabel('contract_period').'</h1>';
		$html .= '<p>'.$this->Contract_date.'</p>';
		$html .= '<h1 class="sml-header drut"><span class="">'.$this->getAttributeLabel('duration').'</span><span class="pricecls">'.$this->ValidityTitle.'</span></h1>';
		$html .= '</div>';
        return $html;
	}
	public function getOrderLi2(){
		$html  = '<div class="ordr-det">';
		//$html .= '<h6 class="sml-header druth">'.$this->getAttributeLabel('contract_period').'</h6>';
		$html .= '<p class="no-m-fi">'.$this->Contract_date.'</p>';
		$html .= '<h1 class="sml-header drut"><span class="">'.$this->getAttributeLabel('duration').'</span><span class="pricecls">'.$this->ValidityTitle.'</span></h1>';
		$html .= '</div>';
        return $html;
	}
	public function getPricingLi(){
		$html  = '<div class="ordr-det">';
		$html .= '<h1 class="sml-header"><span class="pricecls1">'.$this->getAttributeLabel('subtotal').'</span><span class="pricecls">'.$this->formattedSubtotal.'</span></h1>';
		$html .= '<h1 class="sml-header"><span class="pricecls1">'.$this->getAttributeLabel('discount').'</span><span class="pricecls">'.$this->formattedDiscount.'</span></h1>';
		$html .= '<h1 class="sml-header"><span class="pricecls1">'.$this->getAttributeLabel('tax_value').'</span><span class="pricecls">'.$this->formattedTaxValue.'</span></h1>';
		$html .= '<h1 class="sml-header"><span class="pricecls1">'.$this->getAttributeLabel('total').'</span><span class="pricecls">'.$this->formattedTotal.'</span></h1>';
		$html .= '</div>';
        return $html;
	}
	public function getOrderStatusLi(){
		$html  = '<div class="ordr-det">';
		$html .= '<h1 class="sml-header"><span class="">'.$this->getAttributeLabel('order_uid').'</span><span class="pricecls" dir="ltr">'.$this->order_uid.'</span></h1>';
		$html .= '<h1 class="sml-header"><span class="">'.$this->getAttributeLabel('statusm').'</span><span class="pricecls '.$this->status.'">'.$this->StatusName.'</span></h1>';
		$html .= '<h1 class="sml-header"><span class="">'.$this->getAttributeLabel('order_date').'</span><span class="pricecls" dir="ltr">'.date('d-m-Y',strtotime($this->dateAdded)).'</span></h1>';
		$html .= '</div>';
        return $html;
	}
	public function getOptionCls(){
		$html  = '<div class="opts"><div><a href="javascript:void(0)" style="var(--secondary-color)">'.$this->mTag()->getTag('contract','Contract').'   </a><a href="'.Yii::app()->createUrl('member/order_detail',array('order_uid'=>$this->order_uid)).'"  class="margin-left-5" style="var(--secondary-color)"><i class="fa fa-eye"></i></a>  <a href="'.Yii::app()->createUrl('site/pdf',array('order_uid'=>base64_encode($this->primaryKey),'dw'=>'1')).'" target="_blank" class="margin-left-5" style="var(--secondary-color)"><i class="fa fa-download"></i></a> </div>';
		$html  .= '<div class="upparent">';
		if(!empty($this->u_contract)){
		$html  .= '<a href="javascript:void(0)"   class="cls-succes text-warning  ">'.$this->mTag()->getTag('uploaded','Uploaded').'</a> <a href="'.$this->U_contracturl.'" target="_blank"   class="cls-succes text-warning margin-left-5"><i class="fa fa-eye"></i></a>  <a href="'.$this->U_contracturl2.'" target="_blank"   class="cls-succes text-warning margin-left-5"><i class="fa fa-download"></i></a> <a href="javascript:void(0)" data-uid="'.$this->order_uid.'" class="text-danger margin-left-5" onclick="removePdf(this)" ><i class="fa fa-remove"></i></a>';
		}
		else{
		$html  .= '<a href="javascript:void(0)" onclick="uploadFile2(this)" data-uid="'.$this->order_uid.'" class="cls-succes text-warning"><i class="fa fa-plus"></i> '.$this->mTag()->getTag('upload_pdf_contract','Upload PDF contract').'</a>';
		}
		$html  .= '</div><a href="'.Yii::app()->createUrl('member/addons').'" class="cls-succes"><i class="fa fa-plus"></i> '.$this->mTag()->getTag('upgrade','Upgrade').'</a>  ';
		if($this->status==self::STATUS_COMPLETE){
	//	$html  .= '<br /><a href="javascript:void(0)" data-href="'.Yii::app()->createUrl('member/terminate',array('order_uid'=>$this->order_uid)).'" onclick="termicatePackage(this)" class="cls-danger"><i class="fa fa-stop"></i> '.$this->mTag()->getTag('terminate','Terminate').'</a> </div>';
		}
        return $html;
	}
	public function getU_contracturl(){
	    if(!empty($this->u_contract)){
	        //return "https://www.arabavenue.com/uploads/files/".$this->u_contract;
	        return "https://www.arabavenue.com/site/pdf_contract?f=".$this->u_contract;
	        //return Yii::app()->createUrl('site/pdf_contract',array('f'=>$this->u_contract))  ;
	    }
	}
	public function getU_contracturl2(){
	    if(!empty($this->u_contract)){
	        return "https://www.arabavenue.com/site/pdf_contract?dw=1&f=".$this->u_contract;
	       // return Yii::app()->createUrl('site/pdf_contract',array('dw'=>'1','f'=>$this->u_contract))  ;
	    }
	}
	public function getPermissionUContract(){
	 if(!empty($this->u_contract)){
	     return 1; 
	 }
	  return 0; 
	}
	
	public function subscriptionExpiry(){
		
		$html = CHtml::link($this->uid, array("orders/update", "id" => $this->order_id), array("fallbackText" => true));
		$html .= $this->Contract_date2;
		return $html;
		
		
		}
		public function getCheckApproveUrl(){
		return Yii::app()->apps->getAppUrl('frontend', 'member/addons', true);
		 
	}
	public function sendExpirNotification2(){
		//echo "WER";exit;
			$emailTemplate =  CustomerEmailTemplate::model()->getTemplateByUid('qk842w2rfw2c7');
			 $emailTemplate_common = $this->commonTemplate()   ;
			$options     =   Yii::app()->options;
			$support_phone  =  $options->get('system.common.support_phone');
			$support_email  =  $options->get('system.common.support_email');
			$notify     = Yii::app()->notify;
			if(empty($emailTemplate)) { return true ; }
			else{
				  $account_manager_id   =   $this->customer_id;
				  $account_managerModel = ListingUsers::model()->findByPk($account_manager_id);
				  if(empty($account_managerModel)){  return false ; }
				  
				  $subject =    $emailTemplate->subject ;
				  $emailTemplate = $emailTemplate->content; 
			
				  $emailTemplate = str_replace('[NAME]' , $account_managerModel->first_name.' '.$account_managerModel->last_name , $emailTemplate);
				   $emailTemplate = str_replace('[SITE_NAME]' ,'<b>'. $options->get('system.common.site_name').'</b>', $emailTemplate);
				   $emailTemplate = str_replace('[EXPIRY_DATE]' ,'<b>'. date('d M Y', strtotime($this->date_start. ' '.$this->validity.'  days')).'</b>', $emailTemplate);
				   $emailTemplate = str_replace('[UPGRADE_LINK]' ,CHtml::link('Click here to subscribe',$this->CheckApproveUrl,array('style'=>'color:#fff;background-color:#f27f52;font-size:14px;padding:5px 10px;text-align:center;min-width:200px;text-decoration:none')) , $emailTemplate);
				   $emailTemplate = str_replace('[PLANNAME]' ,@$this->plan->package_name , $emailTemplate);
				   $emailTemplate = str_replace('[START]' ,date('d M Y', strtotime($this->date_start)), $emailTemplate);
				   $emailTemplate = str_replace('[END]' ,date('d M Y', strtotime($this->date_start. ' '.$this->validity.'  days')), $emailTemplate);
			  
				 $status = 'S';
				    
				 $adminEmail = new Email();			 
				 $adminEmail->subject = $subject ;
				 $adminEmail->message =   Yii::t('app',$emailTemplate_common, array('[CONTENT]'=>$emailTemplate));
				 
				 $receipeints = serialize(array($account_managerModel->email));
				  
				 $adminEmail->status = $status;
				 $adminEmail->receipeints = $receipeints;
				 $adminEmail->sent_on =   1;
				 $adminEmail->type =   'S';
				 $adminEmail->sent_on_utc =   new CDbExpression('NOW()');
				 $adminEmail->save(false); 
				 $adminEmail->getSend(false);
			}
		 
			//return true; 
	}
		
	public function getSendRenewal(){
	    $last = !empty($this->last_send)? '<br />('.date('d M Y',strtotime($this->last_send)).')' : '' ; 
		return CHtml::link('Send Notification'.$last,'javascript:void(0)',array('class'=>"btn btn-xs btn-info",'onclick'=>'SendNotification(this)','data-id' => $this->primaryKey ));
	}
	public function getContract_date2(){
		if(empty($this->validity)){ return 'Unlimited'; }
		else{
			$days_remaining = ((strtotime(date('d-m-Y', strtotime($this->date_start. ' '.$this->validity.'  days'))) - strtotime(date('d-m-Y')))/ (60 * 60 * 24));
			if($days_remaining <= '0'){ return '<div class="display-block text-danger">Expired.'.$this->SendRenewal.'</div>';}
			else if($days_remaining<='30'){ return '<div class="display-block text-yellow">'.$days_remaining.' days remaining'.$this->SendRenewal.'</div>';}
			else{
			return '<div class="display-block text-success">'.$days_remaining.' days remaining</div>';
			}
		}
	}
	public function getCheckApproveUrlbackend(){
		return Yii::app()->apps->getAppUrl('backend', 'orders/create', true);
		 
	}
	public function sendExpirNotification(){
		//echo "WER";exit;
			$emailTemplate =  CustomerEmailTemplate::model()->getTemplateByUid('zt530qc54q1e8');
        	$options     =   Yii::app()->options; 
			$emailTemplate_common = $options->get('system.email_templates.common')  ;
			
			$support_phone  =  $options->get('system.common.support_phone');
			$support_email  =  $options->get('system.common.support_email');
			$notify     = Yii::app()->notify;
			if(empty($emailTemplate)) { return true ; }
			else{
				 
				  $account_manager_id   =   $this->customer_id;
				  $account_managerModel = ListingUsers::model()->findByPk($account_manager_id);
				  if(!empty($account_managerModel->created_by)){
					  $userAdmin = User::model()->find($account_managerModel->created_by);
				  }	 
				 
				  if(empty($account_managerModel)){  return false ; }
				  if(empty($userAdmin)){  return false ; }
				  
				  $subject =    $emailTemplate->subject ;
				  $emailTemplate = $emailTemplate->content; 
			
				  $emailTemplate = str_replace('[USER_NAME]' , $userAdmin->first_name.' '.$userAdmin->last_name , $emailTemplate);
				  $emailTemplate = str_replace('[NAME]' , '<b>'. $account_managerModel->first_name.' '.$account_managerModel->last_name.'('.$account_managerModel->company_name.')</b>' , $emailTemplate);
				   $emailTemplate = str_replace('[SITE_NAME]' ,'<b>'. $options->get('system.common.site_name').'</b>', $emailTemplate);
				   $emailTemplate = str_replace('[EXPIRY_DATE]' ,'<b>'. date('d M Y', strtotime($this->date_start. ' '.$this->validity.'  days')).'</b>', $emailTemplate);
				   $emailTemplate = str_replace('[UPGRADE_LINK]' ,CHtml::link('Click here to subscribe',$this->CheckApproveUrlbackend,array('style'=>'color:#fff;background-color:#f27f52;font-size:14px;padding:5px 10px;text-align:center;min-width:200px;text-decoration:none')) , $emailTemplate);
				   $emailTemplate = str_replace('[PLANNAME]' ,@$this->plan->package_name , $emailTemplate);
				   $emailTemplate = str_replace('[START]' ,date('d M Y', strtotime($this->date_start)), $emailTemplate);
				   $emailTemplate = str_replace('[END]' ,date('d M Y', strtotime($this->date_start. ' '.$this->validity.'  days')), $emailTemplate);
			  
				 $status = 'S';
				    
				 $adminEmail = new Email();			 
				 $adminEmail->subject = $subject ;
				 $adminEmail->message =   Yii::t('app',$emailTemplate_common, array('[CONTENT]'=>$emailTemplate));
				 $admin_email_alt = !empty($userAdmin->alt_email) ? $userAdmin->alt_email : $userAdmin->email;
				 
				 
				
				 $receipeints = serialize(array($admin_email_alt, $options->get('system.common.admin_email') ));
				 
				 $adminEmail->status = $status;
				 $adminEmail->receipeints = $receipeints;
				 $adminEmail->sent_on =   1;
				 $adminEmail->type =   'S';
				 $adminEmail->sent_on_utc =   new CDbExpression('NOW()');
				 $adminEmail->save(false); 
				 $adminEmail->getSend(false);
			}
		 
			//return true; 
	}
		
public function notification_to_send(){
		
			$criteria=new CDbCriteria;
			//$criteria->select = "t.order_uid,t.customer_id,t.order_id,t.no_of_featured,t.max_listing_per_day,package.package_name,((CASE WHEN t.max_listing_per_day = '0' THEN 1000000 ELSE t.max_listing_per_day END)-t.ads_used) as available_listings ,  (t.no_of_featured-".$this->used_query.") as avaliable_featured_listing,DATEDIFF( DATE_ADD( t.date_start, INTERVAL t.validity  DAY),  NOW()  ) as   days_remaining";
			//$criteria->join = "INNER JOIN {{package}} package on t.plan_id = package.package_id ";
			$criteria->condition  =  '1  and t.validity !="0" and  (DATEDIFF(DATE_ADD(DATE(t.date_start), INTERVAL t.validity DAY) , CURDATE()))  >= 0  and (((DATEDIFF(DATE_ADD(DATE(t.date_start), INTERVAL t.validity DAY) , CURDATE())) = 30) OR ((DATEDIFF(DATE_ADD(DATE(t.date_start), INTERVAL t.validity DAY) , CURDATE()))  = 15) ) and t.status=:complete and (CASE WHEN t.last_send is NULL THEN 15 WHEN  DATEDIFF(CURDATE(),t.last_SEND) >= 2 THEN 1 ELSE 0  END) ';
			$criteria->join  .=   ' LEFT JOIN {{listing_users}} usr1  on usr1.user_id = t.customer_id ';
            $criteria->join  .=   ' LEFT JOIN {{listing_users}} pusr2 on pusr2.user_id = usr1.parent_user ';
            $criteria->condition .=  ' and (CASE WHEN usr1.parent_user is NOT NULL THEN pusr2.created_by is NOT NULL ELSE usr1.created_by is NOT NULL  END)    ' ;	
			$criteria->params[':complete'] = self::STATUS_COMPLETE;
			return PricePlanOrder::model()->findAll($criteria);
	}
	
		public function getBackendCustomer(){
	 return CHtml::link($this->customer->getFullName(), Yii::app()->createUrl("listingusers/update", array("id" => $this->customer_id))).'<a title="Login as this user" target="_blank" class="" href="'.ASKAAN_PATH.'site/impersonate/id/'.$this->customer_id .'"> &nbsp; <span class="glyphicon glyphicon-random"></span> &nbsp;</a>' ;
	}
	public function getChildCustomer(){
		$ar = $this->customer_id;
		$childs = ListingUsers::model()->findAllByAttributes(array('parent_user'=>$this->customer_id));
		if(!empty($childs)){
			foreach($childs as $k=>$v){
				$ar .= ','.$v->user_id;
			}
			
			}
			return $ar;
	}
	public function getChildCustomerAds(){
		$ar[] = $this->customer_id;
		
		$childs = ListingUsers::model()->findAllByAttributes(array('parent_user'=>$this->customer_id));
		if(!empty($childs)){
			foreach($childs as $k=>$v){
				$ar[]=  $v->user_id;
			}
			
			} 
		$criteria = new CDbCriteria;
		$criteria->addInCondition('t.user_id', $ar );
		$data = PlaceAnAd::model()->findAll($criteria);
		foreach($data as $k=>$v){
			if(empty($v->package_used)){
				PlaceAnAd::model()->updateByPk($v->id,array('package_used'=>$this->order_id));
			}
		}
		return PlaceAnAd::model()->count($criteria);
		
		
	}
}
