<?php defined('MW_PATH') || exit('No direct script access allowed');

/**
 * Currency
 * 
 * @package MailWizz EMA
 * @author Serban George Cristian <cristian.serban@mailwizz.com> 
 * @link http://www.mailwizz.com/
 * @copyright 2013-2014 MailWizz EMA (http://www.mailwizz.com)
 * @license http://www.mailwizz.com/license/
 * @since 1.3.4.4
 */

/**
 * This is the model class for table "{{currency}}".
 *
 * The followings are the available columns in table '{{currency}}':
 * @property integer $currency_id
 * @property string $name
 * @property string $code
 * @property string $value
 * @property string $is_default
 * @property string $status
 * @property string $date_added
 * @property string $last_updated
 *
 * The followings are the available model relations:
 * @property PricePlanOrder[] $pricePlanOrders
 */
class Currency extends ActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return '{{currency}}';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		$rules = array(
            array('name, code, is_default, status', 'required'),
            array('name', 'length', 'max' => 100),
            array('base_rate', 'numerical'),
            array('code', 'length', 'is' => 3),
            array('code', 'match', 'pattern' => '/[A-Z]{3}/'),
            array('code', 'unique'),
            array('currency_id', 'safe'),
            array('is_default', 'in', 'range' => array_keys($this->getYesNoOptions())),
            array('status', 'in', 'range' => array_keys($this->getStatusesList())),
            
            array('name, code, is_default, status', 'safe', 'on' => 'search'),
        );
        return CMap::mergeArray($rules, parent::rules());
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		$relations = array(
			'pricePlanOrders' => array(self::HAS_MANY, 'PricePlanOrder', 'currency_id'),
		);
        return CMap::mergeArray($relations, parent::relations());
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		$labels = array(
			'currency_id'    => Yii::t('currencies', 'Currency'),
			'name'           => Yii::t('currencies', 'Name'),
			'code'           => Yii::t('currencies', 'Code'),
			'value'          => Yii::t('currencies', 'Value'),
			'is_default'     => Yii::t('currencies', 'Is default'),
			'base_rate'     => Yii::t('currencies', 'Rate ($1=?)'),
		);
        return CMap::mergeArray($labels, parent::attributeLabels());
	}
    
    protected function beforeValidate()
    {
        if ($this->code !== null) {
            try {
                Yii::app()->numberFormatter->formatCurrency(10.00, $this->code);
            } catch (Exception $e) {
                $this->addError('code', Yii::t('currencies', 'Unrecognized currecy code!'));
            }
        }
        if ($this->is_default == self::TEXT_NO) {
            $hasDefault = self::model()->countByAttributes(array('is_default' => self::TEXT_YES));
            if (empty($hasDefault)) {
                $this->is_default = self::TEXT_YES;
            }
        }
        $this->value = '1.00000000';
        $this->base_rate = '1';
        return parent::beforeValidate();
    }
    
    protected function afterSave()
    {
        if ($this->is_default == self::TEXT_YES) {
            self::model()->updateAll(array('is_default' => self::TEXT_NO), array('condition' => 'currency_id != :cid', 'params' => array(':cid' => (int)$this->currency_id)));
        }
        Yii::app()->options->set('system.common.country_cache',date('dMyHis'));
        return parent::afterSave();
    }

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		$criteria=new CDbCriteria;
		$criteria->compare('name', $this->name, true);
		$criteria->compare('code', $this->code, true);
		$criteria->compare('is_default', $this->is_default);
		$criteria->compare('status', $this->status);
		$criteria->order ='is_default,base_rate desc , name asc' ;
		return new CActiveDataProvider(get_class($this), array(
            'criteria'   => $criteria,
            'pagination' => array(
                'pageSize' => $this->paginationOptions->getPageSize(),
                'pageVar'  => 'page',
            ),
          
        ));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Currency the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
    
    public function findByCode($code)
    {
        return self::model()->findByAttributes(array('code' => $code));
    }
   
    public function findDefault2()
    {
      
        return self::model()->findByAttributes(array(
            'is_default' => self::TEXT_YES,
        ));
    }
    
    public function findDefault()
    {
         static $_defaultCurrency;
        if ($_defaultCurrency !== null) {
            return $_defaultCurrency;
        }
		$session = Yii::app()->session;
		$id		 = $session->itemAt('default_currency');
		if($id){
			 $_defaultCurrency = self::model()->findByPk($id);
		}
		if(empty($_defaultCurrency)){
			$_defaultCurrency = self::model()->findByAttributes(array(
            'is_default' => self::TEXT_YES,
			));
		}
        return $_defaultCurrency;
    }
    public function selectDefault()
    {
		static $_defaultCurrency;
        if ($_defaultCurrency !== null) {
            return $_defaultCurrency;
        }
		$session = Yii::app()->session;
		$id		 = $session->itemAt('default_currency');
		if($id){
			 $_defaultCurrency = self::model()->findByPk($id);
		}
		if(empty($_defaultCurrency)){
			$_defaultCurrency = self::model()->findByAttributes(array(
            'is_default' => self::TEXT_YES,
			));
		}
        return $_defaultCurrency;
    }
    
    public function getIsRemovable()
    {
        return $this->is_default != self::TEXT_YES;
    }
    
    public function getNameWithCode(){
		return $this->name.' ('.$this->code.')';
	}
    public function listData()
    {
		 
        $criteria =new CDbCriteria;
        $criteria->condition ="t.status=:sta";
        $criteria->order ="t.is_default='yes' desc,t.name asc";
        $criteria->params[':sta'] = 'active';
       // $criteria->order = 't.code';
        return   $this->findAll( $criteria) ;
        
    }
    public function listDataCurrency()
    {
		 
        $criteria =new CDbCriteria;
        $criteria->condition ="t.status=:sta and t.base_rate != 0 ";
        $criteria->params[':sta'] = 'active';
        $criteria->order = 't.code';
        return   $this->findAll( $criteria) ;
        
    }
    public function listDataWithBaseCurrency()
    {
		 
        $criteria =new CDbCriteria;
        $criteria->condition ="t.status=:sta and base_rate !=0";
        $criteria->params[':sta'] = 'active';
        $criteria->order = 't.code';
        return   $this->findAll( $criteria) ;
        
    }
     	public function  systemCurrencies()
    { 
	  $cacheKey =  'systemc-currencies'.Yii::app()->options->get('system.common.currencies','abcdefg');
		if(defined('LANGUAGE')){$cacheKey .= LANGUAGE ;   }
		if ($items = Yii::app()->cache->get($cacheKey) and !isset($_GET['refresh'])) { 
	 
			 return $items;
		}
		 
		$criteria=new CDbCriteria;
		$criteria->select = 'currency_id,code,base_rate';
			$criteria->condition ="t.status=:sta and base_rate  !=0.00";
	
		$criteria->order ="t.is_default='yes' desc,t.name asc";
		$criteria->params[':sta'] = 'active';
		$arra =  $this->findAll($criteria);
		$items =array();
		 if($arra)
		 {
			 foreach($arra as $k=>$v)
			 {
			 
				$items[$v->currency_id]  = array('name'=> $v->code,'rate'=>$v->base_rate);
			 }
		 } 
		Yii::app()->cache->set($cacheKey, $items,60 * 60 * 24 * 360  );
		return $items; 
	}
}
