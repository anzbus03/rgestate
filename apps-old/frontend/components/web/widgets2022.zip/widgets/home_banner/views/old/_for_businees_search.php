<form method="get"  action ="<?php echo Yii::App()->createUrl(BUSINESSTITLE);?>"  onsubmit="callprevet(event,this)"  id="for_sale">
                        <div class="row no-gutters" data-select2-id="13">
							  <div class="col-md-3 not-at-mobile padding-right-15" data-select2-id="12">
										<?php 
										echo  CHtml::hiddenField('locality','');
										echo  CHtml::hiddenField('word','');
										//,'onchange'=>'load_via_ajax23(this,"locality")'
										echo  CHtml::dropDownList('state','',$city,array('class'=>'form-control select2 no-radius' ,'data-url'=>Yii::App()->createUrl('site/select_location2') ,'empty'=>'Select City')); ?> 
                               
                           </div>
                         <div class="col-md-4 padding-right-15   not-at-mobile" data-select2-id="12">
										<div tabindex="-1" class="sc-chAAoq lgJTPn"  >
										<div class="sc-cBdUnI jNhpJt">
										<div class="sc-18n4g8v-0 gAhmYY sc-hdPSEv gaQgjK" style="width:100% !important;">
										<i class="rbbb40-1 MxLSp pointer" color="#F57082" size="20">
										<svg xmlns="http://www.w3.org/2000/svg" fill="#F57082" width="20" height="20" viewBox="0 0 20 20" aria-labelledby="icon-svg-title- icon-svg-desc-" role="img" class="rbbb40-0 kIxlGM">
										<linearGradient id="ckfdzuddo0096256u6dgh9rpm" x1="0" x2="100%" y1="0" y2="0">
										<stop offset="0" stop-color="#F57082"></stop>
										<stop offset="100%" stop-color="#F57082"></stop>
										</linearGradient>
										<desc id="icon-svg-desc-">It is an icon with title </desc>
										<path d="M10.2 0.42c-4.5 0-8.2 3.7-8.2 8.3 0 6.2 7.5 11.3 7.8 11.6 0.2 0.1 0.3 0.1 0.4 0.1s0.3 0 0.4-0.1c0.3-0.2 7.8-5.3 7.8-11.6 0.1-4.6-3.6-8.3-8.2-8.3zM10.2 11.42c-1.7 0-3-1.3-3-3s1.3-3 3-3c1.7 0 3 1.3 3 3s-1.3 3-3 3z" fill="url(#ckfdzuddo0096256u6dgh9rpm)"></path>
										</svg>
										</i>
										<div class="typeahead__container" id="form-user_v2" style="width:100%;">
										<div class="typeahead__field">
										<div class="typeahead__query">
										<input class="js-typeahead-user_v2" name="user_v1[query]" placeholder="Enter Location/Keywords" autocomplete="off">
										</div>
										</div>
										</div>
										<i class="rbbb40-1 MxLSp sc-fHSTwm hyorsL rightDown" color="#4F4F4F" size="12">
										<svg xmlns="http://www.w3.org/2000/svg" fill="#4F4F4F" width="12" height="12" viewBox="0 0 20 20" aria-labelledby="icon-svg-title- icon-svg-desc-" role="img" class="rbbb40-0 fQZfgq">
										<linearGradient id="ckfdzuddo0097256u5tby9y95" x1="0" x2="100%" y1="0" y2="0">
										<stop offset="0" stop-color="#4F4F4F"></stop>
										<stop offset="100%" stop-color="#4F4F4F"></stop>
										</linearGradient>
										<desc id="icon-svg-desc-">It is an icon with title </desc>
										<path d="M20 5.42l-10 10-10-10h20z" fill="url(#ckfdzuddo0097256u5tby9y95)"></path>
										</svg>
										</i>
										</div>
										</div>
										</div>
                            </div>
                           
                           <div class="col-md-3 padding-right-15   not-at-mobile home-home-type miniHidden" data-select2-id="73">
										<?php $ids = 5; 
										$categories = Category::model()->ListDataForJSON_ID_BySEctionNewSlug($ids );
										$time = rand(0,1000);
										?>
										<?php echo  CHtml::dropDownList('type_of','',$categories ,array('id'=>'','class'=>'form-control select2 no-radius select2-hidden-accessible','empty'=>'Property Type' )); ?> 
                           </div>
                            <div class="col-md-2 not-at-mobile">  
                              <button type="submit"   class="btn btn-secondary btn-block no-radius font-weight-bold">SEARCH</button>
                           </div>
                        </div>
						</form>
						   <div style="position:relative"> 
               <div class="top-search">
                  <strong><i class="mdi mdi-keyboard"></i> Top Search : </strong>
                  <a href="<?php echo Yii::app()->createUrl('listing/index',array('sec'=>BUSINESS_SLUG,'type_of'=>'Hotels'));?>"  data-id="Hotels">Hotels</a>
                  <a href="<?php echo Yii::app()->createUrl('listing/index',array('sec'=>BUSINESS_SLUG,'type_of'=>'Motels'));?>"  data-id="Motels">Motels</a>
                  <a href="<?php echo Yii::app()->createUrl('listing/index',array('sec'=>BUSINESS_SLUG,'type_of'=>'Hostels'));?>"  data-id="Hostels">Hostels</a>
               </div>
               <a href="javascript:void(0)" onclick="areaUnitChanger()"  class="chn_unit">Change  Area Unit</a>
			</div>
