<style>
.home-slider { margin-bottom:100px;}
.search-form-container {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -ms-flex-direction: column;
    flex-direction: column;
}.askaan-search-container span.fieldItem.checkbox {
    width: 100%;
    height: 100% !important;
}
.askaan-search-container input[type="radio"]:checked+label span{ font-weight: bold;color:var(--secondary-color)!important; } 
.askaan-search-container{ width:768px; margin:auto;padding:16px;background-color:rgba(34,34,34,.85);border-radius:10px;}
.home-mobile-search {
    font-size: 17px;
    font-weight: 700;
    display: inline-block;
    -webkit-box-sizing: content-box;
    box-sizing: content-box;
    width: 100%;
    height: 42px;
    padding: 0;
 
    text-transform: uppercase;
    color: #fff;
    border-style: hidden;
    border-radius: 4px;
    outline: none;
    background-color:var(--logo-color);
    -webkit-box-shadow: 0 .5rem .5rem rgba(34,34,34,.45);
    box-shadow: 0 .5rem .5rem rgba(34,34,34,.45);
    text-transform: none;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: center;
    -ms-flex-pack: center;
    justify-content: center;
    letter-spacing: 0;
    position: relative;
}
#listing_index .askaan-search-container{ width:100%;border-radius:0px; } 
.form-container-list  {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    position: relative;
    margin-top: 1rem;
    -webkit-transition: all .3s ease-in;
    transition: all .3s ease-in;
    -webkit-box-align: start;
    -ms-flex-align: start;
    align-items: flex-start;
}
.form-container-list-item   {
    position: relative;
    border-radius: 4px;
    color: #222;
    font-weight: 400;
    background-color: #fff;
        width: 160px;
        margin-right: 10px;
}
.list-item-p{
 
    min-height: 50px;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    height: auto;
    padding: 5px 10px 0;
    border-radius: 2px;
    background-color: #fff;
}
.list-item-p-label {
    font-size: 10px;
    font-weight: 700;
    color: #767676;
    display: block;
    text-transform: uppercase;
}

.list-item-p-label-button {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    

 
}
.list-item-p-label-button ,.list-item-p-label-button-container{
	    position: relative;
    -webkit-box-pack: justify;
    -ms-flex-pack: justify;
    justify-content: space-between;
    padding: 4px 0 2px;
    height: auto;
}
.list-item-p-label-button-container {
    font-size: 14px;
    float: left;
    width: 100%;
    margin: 0;
    padding-top: 0;
    padding-right: 5px;
    padding-bottom: 0;
    vertical-align: text-top;
    text-overflow: ellipsis;
    overflow: hidden;
    color: #222;
    font-weight: 400;
    border: none;white-space:nowrap;
}
.list-item-p-label-button svg {
    -webkit-transform: rotate(180deg);
    -ms-transform: rotate(180deg);
    transform: rotate(180deg);
    
        fill: #4c4a4a;
    height: 7px;
}
.search-popup-cntainer {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    z-index: 111;
    margin-top: 2px;
    display:none;
}
.form-container-list-item.active .list-item-p-label-button svg {
	-webkit-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    transform: rotate(0deg);
	
	 }
	.search-popup-cntainer  button:focus{ outline:none !important; }
.form-container-list-item.active .search-popup-cntainer{ display:block; }
.search-popup-cntainer-wrapper {
    padding: 10px;
    -webkit-box-shadow: 0 3px 6px 0 rgba(0,0,0,.25);
    box-shadow: 0 3px 6px 0 rgba(0,0,0,.25);
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    border-radius: 5px;
    background-color: #fff;
}.search-popup-cntainer-btn {
    min-height: 34px;
    width: 100%;
    border-radius: 0;
    font-size: 13px;
    display: block;
}
.search-popup-cntainer-btn:hover {
  
    background-color: #fafbfc;
}
.search-popup-cntainer-btn1 {
    text-align: center;
    color: #222;
    border: 1px solid #dedede;
    background-color: #fff;
}
.search-popup-cntainer-btn1.active {
    color: #fff;
    background-color: #49a8e5;
}

.search-cls-cntainer {
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    -webkit-box-pack: center;
    -ms-flex-pack: center;
    justify-content: center;
}.search-cls-btn {
    font-size: 11px;
    padding: 3px 6px;
    color: #fff;
    border: none;
    border-radius: 4px;
    background-color: #222;
}
.search-cls-cntainer {
    margin-left: auto;
    margin-top: 5px;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: end;
    -ms-flex-pack: end;
    justify-content: flex-center;
}
.location-flex {
    -webkit-box-flex: 1;
    -ms-flex:1;
    flex: 1;
}
.list-item-p,.search-cls-btn,.search-popup-cntainer-btn { cursor:pointer;}

.askaan-search-container a.srch{
    font-size: 13px;
    font-weight: 700;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    
    text-transform: uppercase;
    color: #fff;
    border: unset;
    border-radius: 2px;
    background-color:var(--secondary-color);
    -webkit-box-pack: center;
    -ms-flex-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    padding: 0;
    height: 50px;
    -webkit-box-flex: 0.8;
}
.askaan-search-container input.loc{
    font-size: 14px;
    font-weight: 400;
    margin: 0;
    width: unset;
    color: #222;
    border: none;
    background-color: transparent;
  
}
.askaan-search-container input:focus-visible,.askaan-search-container input:focus {
    outline: none !important;
}
 
.prop-type li {
 
    font-size: 12px;
    font-weight: 700;
    display: inline-block;
    margin-bottom: 10px;
    cursor: pointer;
    text-align: center;
    text-transform: uppercase;
    padding: 0 1px 3px;
    color: #a3a1a1;
    border: none;
    margin-right: 10px;
}
.prop-type li:last-child {
    margin-right: 0;
}
.prop-type li .askaan-listbox{ display:none}
.prop-type li.active .askaan-listbox{ display:block;}
.loc-listbox .askaan-listbox{ display:flex;flex-direct:row;flex-wrap:wrap;} 
.loc-listbox .askaan-listbox span{ line-height:1.2; flex:1;max-width:calc(50% - 12px);min-width:calc(50% - 12px); margin-left:5px;margin-right:5px;margin-bottom:5px;} 
.loc-listbox {
    width: 325px;    right: 0;
    left: unset;
}
.prop-type li.active {
    color: #222;
    border-bottom: 2px solid #49a8e5;
}ul.prop-type {
    margin-bottom: 5px;
    align-items: center;
    display: flex;
    justify-content: center;
}


.price-changer {
    font-size: 14px;
    float: left;
    width: 100%;
    margin: 0;
    padding-top: 0;
    padding-right: 5px;
    padding-bottom: 0;
    vertical-align: text-top;
    text-overflow: ellipsis;
    overflow: hidden;
    color: #222;
    font-weight: 400;
    border: none;
        display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
}
.price-changer-from {
    width: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
}
 
.price-changer-to-text {
    font-size: 12px;
    width: 40px;
     padding-right: 5%;
    margin-left: 5px;
}
.price-changer-to {
    width: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
}
.price-frm-selct {
    display: inline-block;
    position: relative;
    width: calc(50% - 14px);
    margin-right: 10px;
    vertical-align: top;
}
.price-frm-selct1 {
    font-size: 14px;
    font-weight: 700;
    display: block;
    width: calc(100% - 5px);
    text-align: center;
    text-transform: uppercase;
}

div.price-frm-selct2 {
    font-size: 14px;
    font-weight: 700;
    width: calc(100% - 10px);
    height: 32px;
    color: #222;
    border: 1px solid #dedede;
    border-radius: 4px;
    text-overflow: ellipsis;
    margin-bottom: 10px;
}
.price-frm-selct3 {
    width: 2px;
    height: 2px;
    left: 0;
    right: 0;
    margin: auto;
    position: absolute;
}
._12173fb7 {
    height: 100%;
    width: 100%;
    border: 1px solid #dedede;
    border-radius: 2px;
    font-size: 14px;
    padding: 0 10px;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    background-color: #fff;
    cursor: text;
}
.price-frm-selct4 {
    overflow-y: scroll;
    overflow-x: hidden;
    max-height: 200px;
    padding-right: 5px;
}.afbbc8c7 {
    display: none;
}
.price-list-row {
    min-width: 215px;
}
 
button.search-popup-cntainer-btn:disabled{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;cursor: not-allowed;
}
.srch-list input{
    border-radius: 4px;
    min-height: 38px;
    background: #fff url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' class='svg-icon-sprite' viewBox='0 0 32 32' fill='%23767676'%3E%3Cpath d='M16 0A9.8 9.8 0 006 9.5v.9c0 2 .5 3.9 1.5 5.6L16 32l8.5-16a11 11 0 001.5-5.6C26.3 5 22.2.4 16.9 0H16zm0 5.6c2.4 0 4.3 1.9 4.3 4.3s-1.9 4.3-4.3 4.3a4.3 4.3 0 01-4.3-4.3c0-2.3 1.9-4.3 4.3-4.3z'/%3E%3C/svg%3E") no-repeat;
    background-position-y: center;
    background-position-x: 5px;
    background-size: 24px;
    padding-left:34px;
    border: 1px  solid #dfdfdf;
    margin-right:15px;
    max-width:calc(100% - 15px);
} 
.only-for-mobile.srch-list-parent .home-mobile-search{ height:38px} 

.srch-list .ftl-itm { flex:1;}
.main_categories {
    position: absolute !important;
    margin-top: 0px;
    margin-bottom: 0px;
    position: relative;
    z-index: 99;
    bottom: -54px !important;
    min-width: 100% !important;
    left: 0px;
    right: 0px;
    max-width: 700px !important;
}.main_categories ul li a h3 {
    font-size: 16px !important;
    margin-top: 5px !important;
    color: color: #333;
    color: #333 !important;
    box-shadow: unset !important;text-shadow: unset !important;;
}.main_categories ul{ max-width:700px;}

.search-form-container  h1._head_askaan {
    color: #fff;
    margin: 0;
    padding: 0 10px;
    text-shadow: 2px 2px 0 rgba(0,0,0,.25);
    font-size:30px;
    text-align: center;
    font-weight: 600;
    letter-spacing: normal;
    line-height: 25px;
}.search-head {
   
    margin-bottom: 32px;
}
  #suestions .autocomplete-suggestions{
										      min-width: calc(100% + 21px);
    margin-left: -10px;
										  }
										  .f-end-s {
    -webkit-box-pack: end;
    -ms-flex-pack: end;
    justify-content: flex-end;
    height: 17px;
}
		.last-itm {
    margin-right: 0;
    -webkit-box-flex: 0.8;
    -ms-flex: 0.8;
    flex: 0.8;
}
		._reset-srch {
    font-size: 14px;
    font-weight: 400;
    margin-left: 10px;
    padding: 0 0 0 10px;
    vertical-align: middle;
    color: #fff;
    border: 0;
    border-radius: 0;line-height:1;
    background: transparent;max-width:100px;
}
._bath_filter {
    width: calc(8.33333% - 7.5px);
}
 
._first-iteme {
   
    max-width: calc(10% - 4px);
}
.loc-filter1 {
    
    max-width: calc(30% - 4px);
     
}
.only-for-mobile { display:none;}
.two-sect-selct {
    display: inline-block;
    position: relative;
    width: calc(100% - 15px);
    margin-right: 10px;
    vertical-align: top;
}
.divvisee {
    display: block!important;
    color: #767676;
    margin-bottom: 8px;
    white-space: nowrap;
}
.askaan-search-container select {
    width: 100%;
    border-radius: 8px;
    border: 1px solid #dbdbdb;
    padding: 5px 8px;
    line-height: 17px;
    color: #767676;
}.askaan-search-container select {
    display: inline;
      font-size: 14px;
    line-height: 20px;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    padding-left: 10px;
    margin-bottom: 0;
}
.propty-pe{width:calc(30% - 5px);}
@media only screen and (max-width: 768px) {
    .only-for-mobile.srch-list-parent {
    display: block;
    min-width: calc(100% - 30px);
}
select option:disabled {
    display:none;
}
.search-popup-cntainer-btn {
    min-height: 32px;
    }.askaan-listbox.spl {
    display: flex;
    padding: 2px;
    border: 1px solid #dbdbdb;
    border-radius: 8px;
}.askaan-listbox.spl .search-popup-cntainer-btn {
    min-height: 32px;
    border: 0px;
    border-radius: 6px;
}.search-popup-cntainer-btn {
    
    border-radius: 6px;
}
.col-sm-61 { flex:1;}
.only-for-mobile { display:block;}
.opened-filter  body{ overflow-y:hidden;}
.opened-filter header{ display:none; }.askaan-search-container{ display:none;}
.opened-filter .askaan-search-container{display:block;} 
.opened-filter .askaan-search-container {
 
    position: fixed;
    left: 0;
    right: 0;
    top: 0;border-radius: 0px;
    bottom: 0;width:100%;background:#fff;
    z-index: 11111;
        background-color: #fff;
    overflow: hidden;overflow-y:auto;
}
.form-container-list{ flex-direction:column;}
.form-container-list-item {
    
    width: 100% !important;
    margin: 0px !important;
    max-width: unset !important;
}
.list-item-p-label-button { display:none;}
.search-popup-cntainer { display:flex;flex-direction:row;    position: unset !important;}
.list-item-p {
    min-height: unset;

}
.search-cls-btn { display:none;}
.search-popup-cntainer-wrapper {
    padding: 10px 10px;
    -webkit-box-shadow:unset;
    box-shadow: unset;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    border-radius: 0px;
    background-color: #fff;    min-width: 100%;
}
.askaan-listbox { display:flex;overflow-x: auto;}.askaan-listbox  span{ flex:1;}
.askaan-search-container input.loc {
    
    border: 1px solid #eee;
    display: block;
    min-width: 100%;
    border-radius: 5px;
    height: 39px;padding-left:15px;
}
 .price-frm-selct{ display:none;}
 .askaan-listbox  span {
    flex: 1;
    margin-right: 10px;
    min-width: 58px;
}
#site_index .hero_single.version_2{ margin:0px !important;max-width: 100% !important;}
#site_index .search-form-container{ width:calc(100% - 30px);}
.search-form-container h1._head_askaan { font-size:20px;}
.search-head {
    margin-bottom: 32px;
    position: absolute;
    bottom: 130px;
}
.hide-for-mobile { display:none}
.searchupdate { 
    position: fixed;
 display:flex!important;
    z-index: 1111;
    left: 0;background:#fff;border-top:1px solid #dfdfdf;
    right: 0;
    width: 100%;
    bottom: 0px;
    padding:10px;    
}
.search-form-container{   }.form-container{margin-top: 60px !important;margin-bottom: 60px !important;}
.searchupdate .item-f {flex:1; margin-left:5px;margin-right:5px;border-radius: 6px !important;height: 40px !important;}
.close-div {
    position: fixed;
    top: 0px;
    align-items: center;
    padding: 10px;
    z-index: 11;
    background: #fff;
    border-bottom: 1px solid #dfdfdf;
    flex-direction: row;
    min-width: 100%;
    left: 0;
    right: 0;
}.close-div  .itn{ flex:1; }.close-div img { height:40px; }
.searchupdate ._reset-srch { color: #2f2f2f;    border: 1px solid #2f2f2f;
     }
     
     .opened-filter #listing_index .askaan-search-container {
  
    padding-left: 0px;
    padding-right: 0px;
}
.propty-pe {
 
    margin-top: 15px;
}
}
._0ab46ba6:hover scg{ fill:Red !important;; }
										   ._4610598b {
    display: inline-block;
    max-width: 100%;
    margin: 0;
    vertical-align: top; margin-top:-4px;
}.cb56c3b9 {
    display: -webkit-inline-box;
    display: -ms-inline-flexbox;
    display: inline-flex;
    -webkit-box-pack: justify;
    -ms-flex-pack: justify;
    justify-content: space-between;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}.db3dcae7 {
    display: -webkit-inline-box;
    display: -ms-inline-flexbox;
    display: inline-flex;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    max-width: 100%;
    vertical-align: top;
    height: 21px;
    margin: 4px 4px 0 0;
    padding-right: 5px;
    padding-left: 5px;
    list-style: none;
    border: 0.6px solid #222;
    border-radius: 3px;line-height:1;
    background-color: #fff;
}._0ab46ba6 {
    font-size: 12px;
    font-weight: 400;
    vertical-align: middle;
    color: #222;
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
}.c7f047fa span:first-child {
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
}._7fb7f2fa {
    fill: #222;
    stroke: #222;
    stroke-width: 1.5px;
    height: 1rem;
    margin-left: 10px;
    vertical-align: middle;
    border: none;
}
.hiden-when-no-focus { display:none}
.on-focus .hiden-when-no-focus{ display:inline-flex}
.more-f-cls{display:inline-flex}
.on-focus .more-f-cls{ display:none}
 #autocomt { width:1px;}
  #autocomt:focus { width:auto;}
  .form-container-list.lc-row{ height:52px;}
  #lcfex { position:relative;z-index:1; }
 ._4610598b {
    display: inline-flex;
}	.on-focus  ._4610598b {
    display: inline-block;
}	.on-focus  input { display:inline-block !important; }
	    .autocomplete-suggestions { border: 1px solid #999; background: #FFF; overflow: auto; }
.autocomplete-suggestion { padding: 2px 5px; white-space: nowrap; overflow: hidden; }
.autocomplete-selected { background: #F0F0F0; }
.autocomplete-suggestions strong { font-weight: normal; color: #3399FF; }
.autocomplete-group { padding: 2px 5px; }
.autocomplete-group strong { display: block; border-bottom: 1px solid #000; }

  @media only screen and (max-width: 768px){
.form-container-list.lc-row{ height:auto!important; }
._4610598b {
   
    min-width: 100%;  flex-wrap:wrap;
}#autocomt {
    width: 100% !important;    width: 100% !important;
    margin-top: 5px;
}.hiden-when-no-focus {
    display: inline-flex;
}.more-f-cls { display:none;}
  div[data-input="type"]{ margin-top:15px !important;}
.search-popup-cntainer-btn1.active {
    color: #fff;
    background-color: var(--logo-blur);
    color: var(--logo-color);
    border: 1px solid var(--logo-color) !important;
}.prop-type li.active{border-color: var(--logo-color) !important; }
}
.list-item-p-label-button-container {
 
    text-transform: capitalize !important;
}
</style>
<script>

$(function(){clickBtnSerach()});
</script>
<div class="search-form-container">			
<?php
$selected = 'property-for-sale';
$section = array('property-for-sale'=>'Buy','property-for-rent'=>'Rent');
$selected_text = $section[$selected];
$category =  array();
$bed = $filterModel->bedroomSearchIndex(); 
$rent_paid = $filterModel->paidArray() ;  
$price_sec = $filterModel->getPriceArray();
 $area_aray_sec = $filterModel->getSqft_aray();
$home_format ='properties/dubai-properties/sale/category-residential/type-villa/1-beds/rent-yearly/minPrice-1/maxPrice-2';
 
?>


<?php

?>
<form id="frm-act"    onsubmit="callprevet(event,this)"  > 
	<div hidden>
	<input id="sector"  class="maininput" value="<?php echo $selected;?>" name="sec">
<input id="cat"  class="maininput" value="" name="cat">
<input id="type"  class="maininput" value="" name="type">
<input id="beds"  class="maininput" value="" name="beds">
<input id="rent_paid"  class="maininput" value="yearly" name="rent_paid">
<input id="min-price"  class="maininput" value="" name="minPrice">
<input id="max-price"  class="maininput" value="" name="maxPrice">
<input id="city" value=""  class="maininput" name="city">
<input id="min-sqft"  value="<?php echo @$formData['minSqft'];?>" name="minSqft">
<input id="max-sqft" value="<?php echo @$formData['maxSqft'];?>" name="maxSqft">
</div>
<div class="askaan-search-container">
	  <div class="form-container">
				<div class="form-container-list margin-top-0 lc-row">
					<div class="form-container-list-item" data-input="sector" data-function="change_section"  >
								<div class="list-item-p list-item-purpose" onclick="openthisBpx(this)">
								   <label class="list-item-p-label" for="filter-title">purpose</label>
								   <div    class="list-item-p-label-button">
									  <span class="list-item-p-label-button-container">
										  <span class="button-container-text"><?php echo $selected_text;?></span>
									 </span>
									  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 12 6" class="eedc221b">
										 <path class="cls-1" d="M12 6L6 0 0 6h12z"></path>
									  </svg>
								   </div>
								</div>
								
								<div class="search-popup-cntainer">
									<div class="search-popup-cntainer-wrapper" role="listbox">
											<div>
												<div role="listbox" class="askaan-listbox spl">
													<?php
													foreach($section as $k=>$v){ ?>
													<span><button aria-label="<?php echo $v;?>" aria-value="<?php echo $k;?>"    class="search-popup-cntainer-btn1 search-popup-cntainer-btn <?php echo ($k==$selected) ? 'active' : '' ;?>"><?php echo $v;?></button></span>
													<?php } ?>
												</div>
												<div class="search-cls-cntainer"><button type="button" class="search-cls-btn"  onclick="openthisBpxInside(this)" >Close</button></div>
											</div>
									</div>
								
								</div>
					</div>
				
					<!---->
							<div class="form-container-list-item location-flex  splnew " id="lcfex"   >
								<div class="list-item-p list-item-purpose"  >
								   <label class="list-item-p-label margin-bottom-0" for="filter-title">location</label>

											<div class="dropdown-mul-1">
											<select style="display:none"  name="state" id="" multiple placeholder="Search by location"></select>
											</div>
									  
								   
								</div>
								
			 		</div>
					<!---->
					<div class="form-container-list-item  margin-right-0" data-input="type" data-function="changeproptype"  >
								<div class="list-item-p list-item-purpose" onclick="openthisBpx(this)">
								   <label class="list-item-p-label" for="filter-title">property type</label>
								   <div    class="list-item-p-label-button">
									  <span class="list-item-p-label-button-container">
										  <span class="button-container-text" id="ptype">Commerical</span>
									 </span>
									  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 12 6" class="eedc221b">
										 <path class="cls-1" d="M12 6L6 0 0 6h12z"></path>
									  </svg>
								   </div>
								</div>
								
								<div class="search-popup-cntainer loc-listbox">
									<div class="search-popup-cntainer-wrapper" role="listbox">
											<div>
												  <div class="miniCol12 smlCol24">
																				<?php 
																				$ids = 1; 
																				$categories = Category::model()->ListDataForJSON_ID_BySEctionNewSlugCache($ids );
																				 $time = rand(0,1000);
																				echo '<ul class="pr-selector">';
																				$tab_id = 1; 
																				foreach($categories as $k2=>$v2){
																					if($k2=='Mixed Use'){ continue; }
																					$cls = $tab_id=='1' ? 'active' : '';
																					echo '<li id="select'.$tab_id.'" data-tab-id="'.$tab_id.'" class="'.$cls.'" onclick ="activtetab(this)" >'.$k2.'</li>';
																					$tab_id++;
																					/*
																					if(is_array($v2)){
																						$title_h = $k2;
																						$count=0;
																								
																						foreach($v2 as $k=>$v){
																							 
																									if($count=='0'){  $time = rand(0,1000);
																									echo '<div class="pbs"><span class="fieldItem  checkbox spnblock"><input id="homeType'.$k2. $time.'" name="type_of"   onclick="propertytypechange(this,event)" ';  echo 'value="'.$k2.'" type="radio"><label for="homeType'.$k2. $time.'"><span class="melipsi">'.$title_h.'<i class="mls iconDownOpen"></i></span></label></span></div>'; 
																					
																									}
																							 $time = rand(0,1000);
																							$title_h = $v;
																						echo '<div class="pbs category_tt cat_'.$k2.' hide"><span class="fieldItem checkbox"><input id="homeType'.$k. $time.'"  class="h_type" name="type_of" ';  echo 'value="'.$k.'" type="radio"><label for="homeType'.$k. $time.'"><span class="melipsi">'.$title_h.'</span></label></span></div>'; 
																						$count++;
																						}
																					}
																					* */
																				} 
																				echo '</ul>';
																				$tab_id = 1; 
																				foreach($categories as $k2=>$v2){
																					if($k2=='Mixed Use'){ continue; }
																					$cls = $tab_id=='1' ? 'active' : '';
																					echo '<li id="cnt-select'.$tab_id.'" class="contns '.$cls.'" >';
																					$tab_id++;
																					 
																					if(is_array($v2)){
																						$title_h = $k2;
																						$count=0;
																								
																						foreach($v2 as $k=>$v){
																						 
																							 $time = rand(0,1000);
																							$title_h = $v;
																						echo '<div class="pbs category_tt cat_'.$k2.'  "><span class="fieldItem checkbox"><input id="homeType'.$k. $time.'"  class="h_type" name="type_of" ';  echo 'value="'.$k.'" onchange="setThisPropVal(this)" data-val="'.$title_h.'"  type="radio"><label for="homeType'.$k. $time.'"><span class="melipsi">'.$title_h.'</span></label></span></div>'; 
																						$count++;
																						}
																					}
																					 
																					echo '</li>';
																				} 
																				?>
																				</div>
                                                                     
												<div class="search-cls-cntainer"><button class="search-cls-btn" type="button"  onclick="openthisBpxInside(this)" >Close</button></div>
											</div>
									</div>
								
								</div>
					</div>
					<!---->
					
				
				</div>
				<!----form-container-list-end-->
				 
					<!---->
				<!----form-container-list-end-->
				<div class="form-container-list">
					 	<div class="form-container-list-item _area_filter"  id="area-parent" data-input="" data-function=""  >
								<div class="list-item-p list-item-purpose" onclick="openthisBpx(this)">
								   <label class="list-item-p-label" for="filter-title">Area (<?php echo AREANAME;?>)</label>
								   <div    class="list-item-p-label-button">
									  <span class="list-item-p-label-button-container">
										<span class="price-changer">
										<span class="price-changer-from"  id="area-changer-from">0</span>
										<span class="price-changer-to-text">to</span>
										<span class="price-changer-to" id="area-changer-to">Any</span>
										</span>
									 </span>
									  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 12 6" class="eedc221b">
										 <path class="cls-1" d="M12 6L6 0 0 6h12z"></path>
									  </svg>
								   </div>
								</div>
								
								<div class="search-popup-cntainer price-list-row">
									<div class="search-popup-cntainer-wrapper" role="listbox">
											<div class="only-for-mobile">
										<div class="row m-0">
										<div class="col-sm-61">
										
											<div class="two-sect-selct">
											<span class="divvisee"  >Minimum:</span>
											<select class=""  id="mobile-minsqft" onchange="changeValuedropDownSelect(this,'mobile-maxsqft','<','minSqft')">
												<option value="0">0</option>
												<?php
												foreach($area_aray_sec as $k=>$v){ 
												echo '<option value="'.$k.'">'.$v.'</option>';
												} ?>
												 </select>
											</div>
										
										</div>
										
										
										<div class="col-sm-61">
										
											<div class="two-sect-selct">
											<span class="divvisee">Maximum:</span>
											<select class="" id="mobile-maxsqft" onchange="changeValuedropDownSelect(this,'mobile-minsqft','>','maxSqft')">
												<option value="0">Any</option>
												<?php
												foreach($area_aray_sec as $k=>$v){ 
												echo '<option value="'.$k.'">'.$v.'</option>';
												} ?>
												 </select>
											</div>
										
										</div>
										
										
										</div>
										
										</div>
											
											<div>
												<div>
   <div class="price-frm-selct" id="minSqft" data-input="min-sqft" data-parent-input="area-changer-from">
      <span class="price-frm-selct1">min:</span>
      <div class="a0c631cb price-frm-selct2">
         <div class="price-frm-selct3">
            
         </div>
         <input placeholder="0" class="_12173fb7"  value="">
      </div>
      <div class="price-frm-selct4" >
		    <span><button type="button" aria-label="0" aria-value="" onclick="changeValuedropDown(this,'maxSqft','<','minSqft','area-parent')"    class="search-popup-cntainer-btn1 indeividual price-changer search-popup-cntainer-btn active">0</button></span>
		
		<?php
		foreach($area_aray_sec as $k=>$v){ ?>
		<span><button type="button" aria-label="<?php echo $v;?>" aria-value="<?php echo $k;?>" onclick="changeValuedropDown(this,'maxSqft','<','minSqft','area-parent')"   class="search-popup-cntainer-btn1 indeividual price-changer search-popup-cntainer-btn"><?php echo $v;?></button></span>
		<?php } ?>
      </div>
   </div>
   <div class="price-frm-selct"  id="maxSqft" data-input="max-sqft" data-parent-input="area-changer-to">
      <span class="price-frm-selct1">max:</span>
      <div class="a0c631cb price-frm-selct2">
         <div class="price-frm-selct3">
           
         </div>
         <input placeholder="Any"  class="_12173fb7" value="">
      </div>
      <div class="price-frm-selct4"> 
		  <span><button type="button"  aria-label="Any" aria-value="" onclick="changeValuedropDown(this,'minSqft','>','maxSqft','area-parent')"    class="search-popup-cntainer-btn1 indeividual search-popup-cntainer-btn active">Any</button></span>
		 
      		<?php
		foreach($area_aray_sec as $k=>$v){ ?>
		<span><button type="button"  aria-label="<?php echo $v;?>" aria-value="<?php echo $k;?>" onclick="changeValuedropDown(this,'minSqft','>','maxSqft','area-parent')"   class="search-popup-cntainer-btn1 indeividual search-popup-cntainer-btn"><?php echo $v;?></button></span>
		<?php } ?>

      
      </div>
   </div>
</div>
												<div class="search-cls-cntainer"><button class="search-cls-btn" type="button"   onclick="openthisBpxInside(this)" >Close</button></div>
											</div>
									</div>
								
								</div>
					</div>
					
					<div class="form-container-list-item <?php echo ($selected != 'property-for-rent')  ?  'd-none' : '';?>" data-input="rent_paid" data-function=""  >
								<div class="list-item-p list-item-purpose" onclick="openthisBpx(this)">
								   <label class="list-item-p-label" for="filter-title">rent frequency</label>
								   <div    class="list-item-p-label-button">
									  <span class="list-item-p-label-button-container">
										  <span class="button-container-text">Yearly</span>
									 </span>
									  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 12 6" class="eedc221b">
										 <path class="cls-1" d="M12 6L6 0 0 6h12z"></path>
									  </svg>
								   </div>
								</div>
								
								<div class="search-popup-cntainer">
									<div class="search-popup-cntainer-wrapper" role="listbox">
											<div>
												<div role="listbox" class="askaan-listbox">
													<?php
													foreach($rent_paid as $k=>$v){ ?>
													<span><button aria-label="<?php echo $v;?>" aria-value="<?php echo $k;?>"    class="search-popup-cntainer-btn1 search-popup-cntainer-btn"><?php echo $v;?></button></span>
													<?php } ?>
												</div>
												<div class="search-cls-cntainer"><button class="search-cls-btn" type="button"  onclick="openthisBpxInside(this)" >Close</button></div>
											</div>
									</div>
								
								</div>
					</div>
				
					<!---->
							<div class="form-container-list-item location-flex "  id="price-parent" data-input="" data-function=""  >
								<div class="list-item-p list-item-purpose" onclick="openthisBpx(this)">
								   <label class="list-item-p-label" for="filter-title">price(<?php echo CURRENCY_CODE;?>)</label>
								   <div    class="list-item-p-label-button">
									  <span class="list-item-p-label-button-container">
										<span class="price-changer">
										<span class="price-changer-from"  id="price-changer-from">0</span>
										<span class="price-changer-to-text">to</span>
										<span class="price-changer-to" id="price-changer-to">Any</span>
										</span>
									 </span>
									  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 12 6" class="eedc221b">
										 <path class="cls-1" d="M12 6L6 0 0 6h12z"></path>
									  </svg>
								   </div>
								</div>
								
								<div class="search-popup-cntainer price-list-row">
									<div class="search-popup-cntainer-wrapper" role="listbox">
											<div class="only-for-mobile">
										<div class="row m-0">
										<div class="col-sm-61">
										
											<div class="two-sect-selct">
											<span class="divvisee"  >Minimum:</span>
											<select class=""  id="mobile-minPrice" onchange="changeValuedropDownSelect(this,'mobile-maxPrice','<','minPrice')">
												<option value="0">0</option>
												<?php
												foreach($price_sec as $k=>$v){ 
												echo '<option value="'.$k.'">'.$v.'</option>';
												} ?>
												 </select>
											</div>
										
										</div>
										
										
										<div class="col-sm-61">
										
											<div class="two-sect-selct">
											<span class="divvisee">Maximum:</span>
											<select class="" id="mobile-maxPrice" onchange="changeValuedropDownSelect(this,'mobile-minPrice','>','maxPrice')">
												<option value="0">Any</option>
												<?php
												foreach($price_sec as $k=>$v){ 
												echo '<option value="'.$k.'">'.$v.'</option>';
												} ?>
												 </select>
											</div>
										
										</div>
										
										
										</div>
										
										</div>
										
									<div>
												<div>
   <div class="price-frm-selct" id="minPrice" data-input="min-price" data-parent-input="price-changer-from">
      <span class="price-frm-selct1">min:</span>
      <div class="a0c631cb price-frm-selct2">
         <div class="price-frm-selct3">
            
         </div>
         <input placeholder="0" class="_12173fb7"  value="">
      </div>
      <div class="price-frm-selct4" >
		    <span><button type="button" aria-label="0" aria-value="" onclick="changeValuedropDown(this,'maxPrice','<','minPrice')"    class="search-popup-cntainer-btn1 indeividual price-changer search-popup-cntainer-btn active">0</button></span>
		
		<?php
		foreach($price_sec as $k=>$v){ ?>
		<span><button  type="button" aria-label="<?php echo $v;?>" aria-value="<?php echo $k;?>" onclick="changeValuedropDown(this,'maxPrice','<','minPrice')"   class="search-popup-cntainer-btn1 indeividual price-changer search-popup-cntainer-btn"><?php echo $v;?></button></span>
		<?php } ?>
      </div>
   </div>
   <div class="price-frm-selct"  id="maxPrice" data-input="max-price" data-parent-input="price-changer-to">
      <span class="price-frm-selct1">max:</span>
      <div class="a0c631cb price-frm-selct2">
         <div class="price-frm-selct3">
           
         </div>
         <input placeholder="Any"  class="_12173fb7" value="">
      </div>
      <div class="price-frm-selct4"> 
		  <span><button  type="button" aria-label="Any" aria-value="" onclick="changeValuedropDown(this,'minPrice','>','maxPrice')"    class="search-popup-cntainer-btn1 indeividual search-popup-cntainer-btn active">Any</button></span>
		 
      		<?php
		foreach($price_sec as $k=>$v){ ?>
		<span><button  type="button" aria-label="<?php echo $v;?>" aria-value="<?php echo $k;?>" onclick="changeValuedropDown(this,'minPrice','>','maxPrice')"   class="search-popup-cntainer-btn1 indeividual search-popup-cntainer-btn"><?php echo $v;?></button></span>
		<?php } ?>

      
      </div>
   </div>
</div>
												<div class="search-cls-cntainer"><button class="search-cls-btn" type="button" onclick="openthisBpxInside(this)" >Close</button></div>
											</div>
									</div>
								
								</div>
					</div>
					<!---->
					<div class="form-container-list-item last-itm hide-for-mobile" data-input="" data-function=""  >
							 
								<a href="javascript:void(0)" role="button"  onclick="$('#frm-act').submit()" class="list-item-p list-item-purpose srch " aria-label="Find button">Find</a>
								
							 
								
					 </div>
					<!---->
					
				
				</div>
		 
				
				<div class="form-container-list f-end-s hide-for-mobile "> 	<div style="position:relative"> 
               <div class="top-search">
                  <strong><i class="mdi mdi-keyboard"></i> <?php echo $conntroller->tag->getTag('top_search','Top Search');?> : </strong>
                  <a href="<?php echo Yii::app()->createUrl('listing/index',array('sec'=>'for-sale','type_of'=>'commercial_warehouse','state'=>'all'));?>" data-id="Lands_Plots"><?php echo $conntroller->tag->getTag('warehouse','Warehouse');?></a>
                  <a href="<?php echo Yii::app()->createUrl('listing/index',array('sec'=>'for-sale','type_of'=>'commercial_retail','state'=>'all'));?>"  data-id="Villas"><?php echo $conntroller->tag->getTag('retail','Retail');?></a>
                  <a href="<?php echo Yii::app()->createUrl('listing/index',array('sec'=>'for-sale','type_of'=>'commercial_staff-accommodation','state'=>'all'));?>"  data-id="Apartments_Flats"><?php echo $conntroller->tag->getTag('staff_accomodation','Staff/Labour Accomodation');?></a>
                  <a href="<?php echo Yii::app()->createUrl('listing/index',array('sec'=>'for-sale','type_of'=>'commercial_Land','state'=>'all'));?>"  data-id="Offices"><?php echo $conntroller->tag->getTag('plots','Plots');?></a>
             
                  <a href="@update_category"  data-id="Offices"><?php echo $conntroller->tag->getTag('hospitals','Hospitals');?></a>
                  <a href="<?php echo Yii::app()->createUrl('listing/index',array('sec'=>'for-sale','type_of'=>'commercial_whole-commercial_building','state'=>'all'));?>"  data-id="Offices"><?php echo $conntroller->tag->getTag('full_buildings','Full Buildings');?></a>
				       <a href="#update_category"  data-id="Offices"><?php echo $conntroller->tag->getTag('schools','Schools');?></a>
               </div>
			</div>
 </div>
		</div>
		 
</div>
</form>
<div class="end"></div>
</div>
 
