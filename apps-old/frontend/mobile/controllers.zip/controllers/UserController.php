<?php defined('MW_PATH') || exit('No direct script access allowed');
 
 
class UserController extends Controller
{
     public function  Init()
     {  	 
			parent::Init();
	 }
	 public function  generateOutPut($status='',$code='1',$error_message=array(),$data=array()){
		 return json_encode(array("status"=>$status,"statusCode"=>$code,"errorMessage"=>$error_message,"data"=>$data))  ;		
	 }
	 public function html_encode($input){
		 return htmlspecialchars($input);
	 }
     public function actionSignup()
     {
		 
        $model = new ListingUsers();    
        $request = Yii::app()->request;
		$model->scenario = 'frontend_insert' ;  
        if ($request->isPostRequest  ) {
				
			$attributes =  (array)$request->getPost($model->modelName, array()) ;
			$model->attributes = $attributes;
			$model->status='A';
			$model->verification_code = md5(uniqid(rand(), true));
            if (!$model->save()) {
				echo $this->generateOutPut('FAILED','0',$user->getErrors(),$user->getErrors());
			}
			else
			{ 
				$succes_data = array("Id"=>$user->user_id,"Name"=>$this->html_encode($user->first_name),"Email"=>$this->html_encode($user->email));
				echo $this->generateOutPut('SUCCESS','1',array(),$succes_data);
			}
	    }
	    else{
				$input_data[] = array( 'field_name' => 'ListingUsers[first_name]' , 'label'=> $model->getAttributeLabel('first_name') , 'values' => '');
				$input_data[] = array( 'field_name' => 'ListingUsers[last_name]' , 'label'=> $model->getAttributeLabel('last_name') , 'values' => '');
				$input_data[] = array( 'field_name' => 'ListingUsers[email]' , 'label'=> $model->getAttributeLabel('email') , 'values' => '');
				$input_data[] = array( 'field_name' => 'ListingUsers[password]' , 'label'=> $model->getAttributeLabel('password') , 'values' => '');
				$input_data[] = array( 'field_name' => 'ListingUsers[country_id]' , 'label'=> $model->getAttributeLabel('country_id') , 'values' =>CHtml::listData(Countries::model()->Countrylist(),"country_id" ,"country_name"));
				$input_data[] = array( 'field_name' => 'ListingUsers[user_type]' , 'label'=> $model->getAttributeLabel('user_type') , 'values' =>$model->getUserType());
				echo $this->generateOutPut('SUCCESS','1',array(),$input_data);
		} 
	    Yii::app()->end();
    } 
}
