<?php
$merge_array = array_filter($_GET);
	$query = '';
	if(!empty($merge_array)){
	$query = http_build_query($merge_array);
	}
	$saveUrl = Yii::app()->createUrl('user/signupajax');
	$saveUrl = $saveUrl.'?'.$query ; 
	
	$form = $this->beginWidget('CActiveForm', array(
	'id' => 'werwer',
	'action'=>Yii::app()->createUrl('user/signup'),
	'enableAjaxValidation'=>true,
	'clientOptions'=>array(
	'validateOnSubmit'=>true,
	'validateOnChange'=>false,
	'afterValidate' => 'js:function(form, data, hasError) { 
	if(hasError) {
	return false;
	}
	else
	{
	$("#reg_btn").val("Processing...");
	ajaxSubmitHappenFav(form, data, hasError,"'.$saveUrl.'"); 
	}
	}',
	),
	'htmlOptions'=>array('class'=>'form   phs','style'=>'margin-top: 5px;' ),
	));
	?>
						<div class="clear"></div>	
	
				
			
		<div class="form-row  col-sm-6 no-padding-left" hint="">
		<label for="id_first_name">First Name: <i class="im im-icon-User"></i>
		<?php 
		echo $form->textField($model , 'first_name', array_merge($model->getHtmlOptions('first_name'),array("placeholder"=>"First Name." ,'class'=>''))); 
		?>
		  </label>
		<?php echo $form->error($model, 'first_name');?>
		<div class="clear"></div>
		</div>			
         
		<div class="form-row col-sm-6   pull-right no-padding-right" hint="">
		<label for="id_first_name">Last Name: <i class="im im-icon-User"></i>
		<?php 
		echo $form->textField($model , 'last_name', array_merge($model->getHtmlOptions('last_name'),array("placeholder"=>"Last Name" ,'class'=>''))); 
		?>
		 </label>
		<?php echo $form->error($model, 'last_name');?>
		<div class="clear"></div>
		</div>
	<div class="clearfix"></div>
	<div class="form-row" hint="">
			<label for="id_email">Email Address: <i class="im im-icon-Mail-Inbox"></i>
			<?php 
			echo $form->textField($model , 'email', array_merge($model->getHtmlOptions('email'),array("placeholder"=>"username@provider.com" ,'class'=>''))); 
			?>
			</label>
			<?php echo $form->error($model, 'email');?>
			<div class="clear"></div>
	</div>
    
 
<div class="clearfix"></div>
<div class="form-row col-sm-6 no-padding-left" hint="">
			<label for="id_email">Password: <i class="im im-icon-Lock-2"></i>
			<?php 
			echo $form->passwordField($model , 'password', array_merge($model->getHtmlOptions('password'),array("placeholder"=>"Password" ,'class'=>''))); 
			?>
			</label>
			<?php echo $form->error($model, 'password');?>
			<div class="clear"></div>
	</div>
    
	<div class="form-row  col-sm-6   pull-right no-padding-right" hint="">
		<label for="id_email">Confirm Password: <i class="im im-icon-Lock-2"></i>		
		<?php 
		echo $form->passwordField($model , 'con_password', array_merge($model->getHtmlOptions('con_password'),array("placeholder"=>"Password(confirm)" ,'class'=>''))); 
		?>
		</label>
		<?php echo $form->error($model, 'con_password');?>
		<div class="clear"></div>
	</div>
<div class="clearfix"></div>

		 

		<div class="clearfix"></div>
		<?php if(empty($short)){?>
		<div class="form-row ">
		<label for="id_gender">My Mother Calls Me </label>
		<?php 
		echo $form->dropDownList($model,'calls_me',array(''=>'- Select One -','M'=>'Male (M)','F'=>'Female (F)'),array( "class"=>"","empty"=>"- Select Nationality -","style"=>"")); 
		?>
		<?php echo $form->error($model, 'calls_me');?>
		<div class="clear"></div>
		</div>
		<div class="clearfix"></div>
		<div class="form-row">
		<label for="id_nationality">Nationality </label> 
		<?php
		echo $form->dropDownList($model,'country_id', CHtml::listData(Countries::model()->Countrylist(),"country_id" ,"country_name"),array("class"=>"", "empty"=>"- Select One -","style"=>";")); 
		?>
		<?php echo $form->error($model, 'country_id');?>
		<div class="clear"></div>
		</div>
		<?php } ?> 

	<div class="clearfix"></div>

 <div class="form-group">
        <div class="form-row ">
          <label class="form-check-label" for="gridCheck">
           Register Me &nbsp;&nbsp;
          </label>
          <div class="clearfix"></div>
           <?php
           $user_type_array = $model->getUserType();
           foreach( $user_type_array as $k=>$v){
			   $checked =  $k=='U' ? true :false ; 
			   echo '<label style="width:auto;float:left;display: inline-block;">'.$form->radioButton($model, 'user_type',$model->getHtmlOptions('user_type',array('class'=>'form-check-input', 'uncheckValue'=>null,'value'=>$k,'checked'=>$checked,'style'=>'width:auto;display: inline-block;float-left;height: auto;'))).'&nbsp;'.$v.'&nbsp;&nbsp;</label>';
		   }
		   ?>
			<div class="clearfix"></div>
      <?php echo $form->error($model, 'user_type');?>
		<div class="clearfix"></div>

</div>
</div>
	<div class="clearfix"></div>





 	<div class="fbregister-button-block">
		<?php if(empty($short)){?>
							<p>By clicking on Register, you agree to the <a href="<?php echo Yii::app()->createUrl('article/terms');?>" target="_blank" class="redbold">  Terms and Conditions</a> and the <a href="<?php echo Yii::app()->createUrl('article/condition');?>" target="_blank" class="redbold">  Privacy Policy</a>.</p>
							<?php } ?> 
							<input type="submit" class="red awesome fbregister-button frebites_button" id="reg_btn" value="Register" />
							<div class="clear"></div>
						</div>
					<?php $this->endWidget();?>
		 
