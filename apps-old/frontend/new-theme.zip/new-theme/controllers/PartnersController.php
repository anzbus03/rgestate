<?php defined('MW_PATH') || exit('No direct script access allowed');

 
class PartnersController extends Controller
{
    /**
     * List available published 
     */
  public $headerImage;
  public function init(){
	 
	  parent::Init();
      
    }
    public function actionIndex()
    {
        //echo"enter";exit;   
         $criteria = new CDbCriteria();
         $criteria->compare('status', Partners::STATUS_PUBLISHED);
         $criteria->order = 'partners_id DESC';
        
         $count = Partners::model()->count($criteria);
        
         $pages = new CPagination($count);
         $pages->pageSize = 100;
         $pages->applyLimit($criteria);

        $partners = Partners::model()->findAll($criteria);
   $this->setData(array(
            'pageTitle'     =>$this->tag->getTag('our_clients_&_partners','Our Clients & Partners'), 
            'pageMetaDescription'   =>$this->tag->getTag('our_clients_&_partners','Our Clients & Partners'), 
            'metaKeywords'   => $this->tag->getTag('our_clients_&_partners','Our Clients & Partners'), 
        ));
        $this->render('index', compact('partners', 'pages'));
    }
    
    /**
     * Helper method to load the article AR model
     */
    public function loadPartnersModel($slug)
    {
         $model = Partners::model()->findBySlugPublished( $slug );
        
        if ($model === null) {
            throw new CHttpException(404, Yii::t('app', 'The requested page does not exist.'));
        }
        
        return $model;
    }
	
}
