<?php defined('MW_PATH') || exit('No direct script access allowed');?>

<div class="container">

	<div class="row">
	
		<div class="col-md-12">
        <!--Tabs -->
        <div class=" " >
         
          <div class="tabs-container alt" > 
 <h4 class="subheading_font row bold-style">Successfully Saved.</h4>
            <!-- Login -->
			<div class="tab-content" id="tab1"  style="border-top: 0px  ;padding-top:0px;">
		 	<div class="tab_container no-margin no-padding">

<div id="tab1" class="tab_content active_content" id="fbsignin-form">
	 <div class="form">
		 <div class="emil_img text-center"><img src="data:image/svg+xml;base64,PHN2ZyBoZWlnaHQ9IjUxMiIgdmlld0JveD0iLTMgMCA1MTIgNTEyIiB3aWR0aD0iNTEyIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnPjxwYXRoIGQ9Im0wIDIzMi45MTc5NjloNDMuNjA1NDY5djUyLjMyODEyNWgtNDMuNjA1NDY5em0wIDAiIGRhdGEtb3JpZ2luYWw9IiMwMDAwMDAiIGNsYXNzPSJhY3RpdmUtcGF0aCIgZGF0YS1vbGRfY29sb3I9IiMwMDAwMDAiIHN0eWxlPSJmaWxsOiNFQjFBM0EiPjwvcGF0aD48cGF0aCBkPSJtMTA0LjY1NjI1IDMxMS40MTAxNTZoNDMuNjA1NDY5djM0Ljk1NzAzMmMwIDkuNTkzNzUtNy43NzczNDQgMTcuMzcxMDkzLTE3LjM3MTA5NCAxNy4zNzEwOTNoLTI2LjIzNDM3NXptMCAwIiBkYXRhLW9yaWdpbmFsPSIjMDAwMDAwIiBjbGFzcz0iYWN0aXZlLXBhdGgiIGRhdGEtb2xkX2NvbG9yPSIjMDAwMDAwIiBzdHlsZT0iZmlsbDojRUIxQTNBIj48L3BhdGg+PHBhdGggZD0ibTE2OS4xNTYyNSAyMjYuNTQyOTY5IDE2Mi4yNS03Mi4xMTcxODh2MjA5LjMxMjVsLTE2Mi4yNS03Mi4xMTcxODd6bTAgMCIgZGF0YS1vcmlnaW5hbD0iIzAwMDAwMCIgY2xhc3M9ImFjdGl2ZS1wYXRoIiBkYXRhLW9sZF9jb2xvcj0iIzAwMDAwMCIgc3R5bGU9ImZpbGw6I0VCMUEzQSI+PC9wYXRoPjxwYXRoIGQ9Im02MS4wNDY4NzUgMzExLjQxMDE1Nmg1Mi4zMjgxMjV2OTUuOTMzNTk0aC01Mi4zMjgxMjV6bTAgMCIgZGF0YS1vcmlnaW5hbD0iIzAwMDAwMCIgY2xhc3M9ImFjdGl2ZS1wYXRoIiBkYXRhLW9sZF9jb2xvcj0iIzAwMDAwMCIgc3R5bGU9ImZpbGw6I0VCMUEzQSI+PC9wYXRoPjxwYXRoIGQ9Im00NDQuNzg1MTU2IDYuMTY0MDYyLTY5Ljc2OTUzMSA2OS43NzM0Mzh2NjEuMDQ2ODc1aDYxLjA0Njg3NWw2OS43Njk1MzEtNjkuNzY5NTMxem0tMzAuNTIzNDM3IDEwNC42NTYyNWMtNy4yMjY1NjMgMC0xMy4wODIwMzEtNS44NTU0NjgtMTMuMDgyMDMxLTEzLjA4MjAzMSAwLTcuMjIyNjU2IDUuODU1NDY4LTEzLjA4MjAzMSAxMy4wODIwMzEtMTMuMDgyMDMxIDcuMjIyNjU2IDAgMTMuMDgyMDMxIDUuODU5Mzc1IDEzLjA4MjAzMSAxMy4wODIwMzEgMCA3LjIyNjU2My01Ljg1OTM3NSAxMy4wODIwMzEtMTMuMDgyMDMxIDEzLjA4MjAzMXptMCAwIiBkYXRhLW9yaWdpbmFsPSIjMDAwMDAwIiBjbGFzcz0iYWN0aXZlLXBhdGgiIGRhdGEtb2xkX2NvbG9yPSIjMDAwMDAwIiBzdHlsZT0iZmlsbDojRUIxQTNBIj48L3BhdGg+PHBhdGggZD0ibTU5LjkzMzU5NCAxOTguMDM1MTU2aDg5LjQ0NTMxMmMxMy44MzIwMzIgMCAyNS4wNDY4NzUgMTEuMjE0ODQ0IDI1LjA0Njg3NSAyNS4wNDY4NzV2NzIuMDAzOTA3YzAgMTMuODMyMDMxLTExLjIxNDg0MyAyNS4wNDY4NzQtMjUuMDQ2ODc1IDI1LjA0Njg3NGgtODkuNDQ1MzEyYy0xMy44MzU5MzggMC0yNS4wNTA3ODItMTEuMjE0ODQzLTI1LjA1MDc4Mi0yNS4wNDY4NzR2LTcyLjAwMzkwN2MwLTEzLjgzMjAzMSAxMS4yMTQ4NDQtMjUuMDQ2ODc1IDI1LjA1MDc4Mi0yNS4wNDY4NzV6bTAgMCIgZGF0YS1vcmlnaW5hbD0iIzAwMDAwMCIgY2xhc3M9ImFjdGl2ZS1wYXRoIiBkYXRhLW9sZF9jb2xvcj0iIzAwMDAwMCIgc3R5bGU9ImZpbGw6I0VCMUEzQSI+PC9wYXRoPjxwYXRoIGQ9Im00MTkuNDkyMTg4IDM0Ni41NDY4NzUtNjEuNjY3OTY5IDYxLjY3MTg3NSA4Ni4zMzk4NDMgODYuMzM5ODQ0IDYxLjY2Nzk2OS02MS42Njc5Njl6bTUuNDk2MDkzIDg4Ljg3MTA5NGMtNC4yODkwNjItLjMzMjAzMS03LjY5NTMxMi0zLjc0MjE4OC04LjAyMzQzNy04LjAzMTI1bC00LjE4NzUtNTQuMzg2NzE5IDE3LjM5MDYyNS0xLjMzNTkzOCAzLjYwOTM3NSA0Ni45NDE0MDcgNDcuOTA2MjUgMy42Nzk2ODctMS4zMzIwMzIgMTcuMzkwNjI1em0wIDAiIGRhdGEtb3JpZ2luYWw9IiMwMDAwMDAiIGNsYXNzPSJhY3RpdmUtcGF0aCIgZGF0YS1vbGRfY29sb3I9IiMwMDAwMDAiIHN0eWxlPSJmaWxsOiNFQjFBM0EiPjwvcGF0aD48cGF0aCBkPSJtNDc5LjY2Nzk2OSAyMDYuNzUzOTA2YzAgMTQuNDUzMTI1LTExLjcxMDkzOCAyNi4xNjQwNjMtMjYuMTY0MDYzIDI2LjE2NDA2My0xNC40NDkyMTggMC0yNi4xNjAxNTYtMTEuNzEwOTM4LTI2LjE2MDE1Ni0yNi4xNjQwNjMgMC0xNC40NDkyMTggMTEuNzEwOTM4LTI2LjE2NDA2MiAyNi4xNjAxNTYtMjYuMTY0MDYyIDE0LjQ1MzEyNSAwIDI2LjE2NDA2MyAxMS43MTQ4NDQgMjYuMTY0MDYzIDI2LjE2NDA2MnptMCAwIiBkYXRhLW9yaWdpbmFsPSIjMDAwMDAwIiBjbGFzcz0iYWN0aXZlLXBhdGgiIGRhdGEtb2xkX2NvbG9yPSIjMDAwMDAwIiBzdHlsZT0iZmlsbDojRUIxQTNBIj48L3BhdGg+PHBhdGggZD0ibTQ0NC45NDkyMTkgMjQxLjY0MDYyNWgxNy4xMjEwOTNjMTQuNTM5MDYzLjAwMzkwNiAyNi4zMjAzMTMgMTEuNzkyOTY5IDI2LjMyMDMxMyAyNi4zMjgxMjV2NDMuNDQxNDA2aC02OS43Njk1MzF2LTQzLjQ0MTQwNmMwLTE0LjUzOTA2MiAxMS43ODkwNjItMjYuMzI4MTI1IDI2LjMyODEyNS0yNi4zMjgxMjV6bTAgMCIgZGF0YS1vcmlnaW5hbD0iIzAwMDAwMCIgY2xhc3M9ImFjdGl2ZS1wYXRoIiBkYXRhLW9sZF9jb2xvcj0iIzAwMDAwMCIgc3R5bGU9ImZpbGw6I0VCMUEzQSI+PC9wYXRoPjxwYXRoIGQ9Im00MDkuODk4NDM4IDIxNS40NzY1NjJjMCA5LjYzMjgxMy03LjgwODU5NCAxNy40NDE0MDctMTcuNDQxNDA3IDE3LjQ0MTQwNy05LjYzMjgxMiAwLTE3LjQ0MTQwNi03LjgwODU5NC0xNy40NDE0MDYtMTcuNDQxNDA3IDAtOS42MzI4MTIgNy44MDg1OTQtMTcuNDQxNDA2IDE3LjQ0MTQwNi0xNy40NDE0MDYgOS42MzI4MTMgMCAxNy40NDE0MDcgNy44MDg1OTQgMTcuNDQxNDA3IDE3LjQ0MTQwNnptMCAwIiBkYXRhLW9yaWdpbmFsPSIjMDAwMDAwIiBjbGFzcz0iYWN0aXZlLXBhdGgiIGRhdGEtb2xkX2NvbG9yPSIjMDAwMDAwIiBzdHlsZT0iZmlsbDojRUIxQTNBIj48L3BhdGg+PHBhdGggZD0ibTM5Mi40NTcwMzEgMjQxLjY0MDYyNWMxNC40NDkyMTkgMCAyNi4xNjQwNjMgMTEuNzE0ODQ0IDI2LjE2NDA2MyAyNi4xNjQwNjN2MjYuMTY0MDYyaC01Mi4zMjgxMjV2LTI2LjE2NDA2MmMwLTE0LjQ0OTIxOSAxMS43MTQ4NDMtMjYuMTY0MDYzIDI2LjE2NDA2Mi0yNi4xNjQwNjN6bTAgMCIgZGF0YS1vcmlnaW5hbD0iIzAwMDAwMCIgY2xhc3M9ImFjdGl2ZS1wYXRoIiBkYXRhLW9sZF9jb2xvcj0iIzAwMDAwMCIgc3R5bGU9ImZpbGw6I0VCMUEzQSI+PC9wYXRoPjxwYXRoIGQ9Im0zMjguODUxNTYyIDEyLjMzMjAzMS0xMi4zMzIwMzEtMTIuMzMyMDMxLTUzLjI3NzM0MyA1My4yNjE3MTljLTI3LjEwMTU2My0yMC4yODEyNS02NS41MTU2MjYtMTQuNzUzOTA3LTg1Ljc5Njg3NiAxMi4zNDc2NTZzLTE0Ljc1MzkwNiA2NS41MTU2MjUgMTIuMzQ3NjU3IDg1Ljc5Njg3NWMyNy4xMDU0NjkgMjAuMjg1MTU2IDY1LjUxNTYyNSAxNC43NTM5MDYgODUuODAwNzgxLTEyLjM0NzY1NiAxNi4yOTI5NjktMjEuNzczNDM4IDE2LjI5Mjk2OS01MS42NzU3ODIgMC03My40NDkyMTl6bS0xMDIuMDk3NjU2IDEzMy4zNzVjLTI0LjA4NTkzNyAwLTQzLjYwOTM3NS0xOS41MjM0MzctNDMuNjA5Mzc1LTQzLjYwNTQ2OSAwLTI0LjA4NTkzNyAxOS41MjM0MzgtNDMuNjA5Mzc0IDQzLjYwOTM3NS00My42MDkzNzQgMjQuMDgyMDMyIDAgNDMuNjA1NDY5IDE5LjUyMzQzNyA0My42MDU0NjkgNDMuNjA5Mzc0LS4wMjczNDQgMjQuMDcwMzEzLTE5LjUzNTE1NiA0My41NzQyMTktNDMuNjA1NDY5IDQzLjYwNTQ2OXptMCAwIiBkYXRhLW9yaWdpbmFsPSIjMDAwMDAwIiBjbGFzcz0iYWN0aXZlLXBhdGgiIGRhdGEtb2xkX2NvbG9yPSIjMDAwMDAwIiBzdHlsZT0iZmlsbDojRUIxQTNBIj48L3BhdGg+PHBhdGggZD0ibTIzNS40NzI2NTYgMzYzLjczODI4MWgtMzQuODgyODEybC01Mi4zMjgxMjUgNTIuMzI4MTI1IDk1LjkzMzU5MyA5NS45MzM1OTQgNjkuNzY5NTMyLTY5Ljc2OTUzMXptLTQxLjA1MDc4MSA2My42MDU0NjkgMzQuODg2NzE5LTM0Ljg4NjcxOSAxMi4zMzIwMzEgMTIuMzMyMDMxLTM0Ljg4NjcxOSAzNC44ODY3MTl6bTM4LjQ5NjA5NCAzOC40OTYwOTQtMTIuMzMyMDMxLTEyLjMzMjAzMiAzNC44ODY3MTgtMzQuODg2NzE4IDEyLjMzMjAzMiAxMi4zMzIwMzF6bTAgMCIgZGF0YS1vcmlnaW5hbD0iIzAwMDAwMCIgY2xhc3M9ImFjdGl2ZS1wYXRoIiBkYXRhLW9sZF9jb2xvcj0iIzAwMDAwMCIgc3R5bGU9ImZpbGw6I0VCMUEzQSI+PC9wYXRoPjwvZz4gPC9zdmc+" style="width:86px;margin: 0px auto 41px;" /></div>
		<?php
		if($option=='update'){
		    ?>
		     <h2 class="large_h2 text-center" >Your  property has been successfully  <br /> updated    on  Feeta.pk</h2>
		    <?php
		    
		}
		else{ ?> 
		 <h2 class="large_h2 text-center" >Your  property has been successfully uploaded on Feeta.pk
    </h2>
		 <?php } ?>
	 			<style>
	 			    .btn.update-btn ,   .btn.view-btn ,  .btn.post-new{ width: 114px;

display: inline-block;

font-size: 15px !important;

padding: 8px 10px !important;

height: auto !important;

line-height: 24px;

border-radius: 5px !important; margin-right:10px ; }
.btn.post-new { background: var(--logo-color);}
	 			  
	 			</style>
						<div class="text-center margin-top-20">
						    	<a href="<?php echo Yii::app()->createUrl('place_an_ad/update',array('slug'=>$ad->slug));?>" class="btn btn-warning update-btn" >Edit</a>
							<?php
							if($ad->status=='A'){ ?> 
							<a href="<?php echo $ad->DetailUrl;?>" class="btn btn-secondary view-btn " >View</a>
						    <?php } ?> 
							<a href="<?php echo Yii::app()->createUrl('place_an_ad/create');?>" class="btn btn-danger  post-new "   >Post New</a>
					 		</div>
							<span id="login-form"> </span>
		<div id="register-head">
		 
			    <?php  
				
				$form = $this->beginWidget('CActiveForm',array( 
				'enableAjaxValidation'=>true,
				'htmlOptions' =>array('id'=>'form-account-logina','data-abide'=>'','style'=>''),
				'clientOptions' => array(
				'validateOnSubmit'=>true,
				),
				)); 
				;?>
				<button data-layer-action="login" style="margin-top:0px; width:100%;  " id="resend_btn" class="hide btn red awesome fbsignin-button headfont" name="resent" value="resent" type="submit"  ><i class="fa fa-mail-forward"></i> Resent Verification Email</button>
				<?php $this->endWidget();?>
			<div class="clear"></div>
		</div>
	
		 <!-- end #right-col -->
		<div class="clearfix"></div>
	</div>
	<div class="clearfix"></div>
</div><!-- end #tab1 -->

		 
		</div><!-- end .tab_container -->
	
			</div>

			<!-- Register -->
		 
            </div>
          </div>
       

		

		</div>
	 
		<div class="col-md-4 hide"> 
		<div class="description-item"><i class="description-star-icon description-icon my-i"></i> <h3 class="description-title">Don’t receive th email ?</h3>
		 <p >1. Is <a href="mailto:<?php echo $model->email;?>" class="link_color"><?php echo $model->email;?></a> your correct email without typos? If not <a href="<?php echo Yii::app()->createUrl('user/signup');?>"> you can restart the signup process </a></p>
		 <p >2. Check your spam folder </p>
		 <p >3. Click <a href="javascript:void(0)" onclick="$('#resend_btn').click();"  class="link_color">here</a> to resend the  email </p>
		 
		 </div>
		 <div class="clearfix"></div>
		 <div style="position:relative;">
		<div class="description-item"><i class="description-open-icon description-icon my-i"></i> <h3 class="description-title">Still having trouble?</h3>
		 <p class="description-content"><a href="<?php echo Yii::app()->createUrl('contact/index');?>"  class="link_color">Contact Us</a></p>
		</div>
		</div>
		
		
		 	</div>
	</div>

</div>
  
<style>input, input[type=text], input[type=password], input[type=email], input[type=number], textarea, select {
    	height: 51px;
            line-height: 51px;
            padding: 0 20px;
            outline: 0;
            font-size: 15px;
            color: gray;
            margin: 0 0 16px;
            max-width: 100%;
            width: 100%;
            box-sizing: border-box;
            display: block;
            background-color: #fff;
            border: 1px solid #dbdbdb;
            box-shadow: 0 1px 3px 0 rgba(0,0,0,.06);
            font-weight: 500;
            opacity: 1;
            border-radius: 3px;
    margin-left: 0 !important;
    width:100%;
}.no-padding-left{padding-left:0px;}.no-padding-right{padding-right:0px;}.pull-right{ float:right;}.forgotpassword a{color:#82addc !important;}</style>
