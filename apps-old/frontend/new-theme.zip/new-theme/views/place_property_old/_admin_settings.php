
				 <style>#place_an_ad   .row {
    margin-left: 0px;
    margin-right: 0px;
 }</style>
				        <div class="insidecontent">

<div class="clearfix"></div>
 <h3 class="subHeadh2"> Contact Details</h3>
<div class="clearfix"></div>
<div class="row">					  
 
										<div class="clearfix"></div>
											<div class="form-group col-lg-3">
										<?php 
									 	echo $form->labelEx($model, 'contact_person');?>
										<?php echo $form->textField($model, 'contact_person', $model->getHtmlOptions('contact_person')); ?>
										<?php echo $form->error($model, 'contact_person');?>
										</div> 
										<div class="clearfix"></div>
										<div class="row">
										<div class="form-group col-lg-3">
										<?php 
									 	echo $form->labelEx($model, 'mobile_number');?>
										<?php echo $form->textField($model, 'mobile_number', $model->getHtmlOptions('mobile_number')); ?>
										<?php echo $form->error($model, 'mobile_number');?>
										</div> 
											<div class="form-group col-lg-3">
										<?php 
									 
										echo $form->labelEx($model, 'landline');?>
										<?php echo $form->textField($model, 'landline', $model->getHtmlOptions('landline')); ?>
										<?php echo $form->error($model, 'landline');?>
										</div> 
										  <div class="form-group col-lg-6">
												 
										<?php echo $form->labelEx($model, 'user_id');?>
 
										<?php echo $form->dropDownList($model, 'user_id', CHtml::listData(ListingUsers::model()->findAllByPk($model->user_id),'user_id','fullName') , $model->getHtmlOptions('user_id') ); ?>
										<?php echo $form->error($model, 'user_id');?>
									</div>
							 
							 
							 <div class="clearfix"><!-- --></div>
							 	
										 	 <div class="form-group col-lg-6 hide">
									 
										<?php echo $form->hiddenField($model, 'section_id'   ); ?>
										<?php echo $form->error($model, 'section_id');?>
										<?php echo $form->hiddenField($model, 'listing_type'   ); ?>
										<?php echo $form->error($model, 'listing_type');?>
										<?php echo $form->hiddenField($model, 'w_for'   ); ?>
										<?php echo $form->error($model, 'w_for');?>
										<?php echo $form->hiddenField($model, 'category_id'   ); ?>
										<?php echo $form->error($model, 'category_id');?>
									</div>
		</div>					 
		</div>					 
                <div class="clearfix"><!-- --></div>
                </div>
                   <div class="_2ytqd"></div>
                
            
				  <div class="insidecontent">
				 <div class="clearfix"></div>
		<h3 class="subHeadh2">Admin Settings</h3>
		 <h2 class="main_head_purpose"></h2>
		<div class="clearfix"></div> 
		<div class="row">
		<div class="form-group col-lg-6">
		<?php echo $form->labelEx($model, 'status');?>
		<?php echo $form->dropDownList($model, 'status', $model->statusArray()    , $model->getHtmlOptions('community_id' ,array('class'=>'form-control selectt2') )); ?>
		<?php echo $form->error($model, 'status');?>
		</div> 
		<div class="form-group col-lg-6">
		<?php echo $form->labelEx($model, 'featured');?>
		<?php echo $form->dropDownList($model, 'featured', array('N'=>'Not Featured' , 'Y'=>'Featured' )    , $model->getHtmlOptions('featured' ,array('class'=>'form-control selectt2') )); ?>
		<?php echo $form->error($model, 'featured');?>
		</div> 
		</div>
		
		</div> 
		<div class="clearfix"></div> 
		<script>
var modelName = '<?php echo $model->modelName;?>';
var cityUrl   = '<?php echo Yii::App()->createUrl($this->id.'/getCityId');?>';
var customer_url = '<?php echo Yii::app()->createUrl('place_an_ad/Customer' );?>';
 
 
</script>
