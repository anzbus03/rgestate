   <div id="categoryTypeToggleDiv" style="display:none;padding:10px;top:10px;position:absolute; left:0px;max-height:300px;overflow-y:auto;width:280px;"  class="box boxCard boxBasic backgroundBasic zIndexNavigation filterContainer pbs txtL">
                                                                    <div class="  ">
																			
																	 
                                                                        <div class="miniCol12 smlCol24">
																				<?php 
																				  
																				$ids =  !empty($filterModel->section_id) ? $filterModel->section_id : ''; 
																	 
																				$categories = Category::model()->ListDataForJSON_ID_BySEctionSlugNewN($ids );
																				foreach($categories as $k=>$v){
																					$title_h = $v;
																					echo '<div class="pbs"><span class="fieldItem checkbox"><input id="homeType'.$k.'"  class="h_type" name="type_of" ';if($k==$filterModel->type_of){ echo 'checked="true"'; } echo 'value="'.$k.'" type="radio" onChange = "timuteChange()"><label for="homeType'.$k.'"><span class="melipsi">'.$title_h.'</span></label></span></div>'; 
																				} 
																				?>
																				</div>
                                                                    </div>
                                                                </div>
<script> var load_category_url = '<?php echo Yii::App()->createUrl('site/load_category_url');?>'</script>
