<?php $this->widget('frontend.components.web.widgets.footer.FooterWidget'); ?> 
