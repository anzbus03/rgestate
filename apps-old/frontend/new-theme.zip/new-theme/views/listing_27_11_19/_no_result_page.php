<div id="leftColumn" class="leftColumn" style="<?php echo !empty($full_width) ? 'width:80%;margin:auto;' :'width:50%';?>;">
    <div id="scrollContent">
      <div id="srpHeaderLeftColumn" class="plm" ><!-- react-empty: 118 --></div>
      <div id="resultsColumn"><div data-reactroot="" class="plm"><h6 class="typeLowlight">0 Results.</h6><h2>Your search does not match any properties.</h2><div class="ptm"><div><h5 class="typeWeightNormal mbm">Adjust filters to find more homes:</h5><div>
			<div>
			<button class="btn btnTertiary mrs mbs" onclick="removeAllFilters()">Remove All Filters</button>
			</div></div></div>
			<div class="txtC" style="padding: 80px 0px;">
			<img alt="No homes found" src="//static.trulia-cdn.com/images/search-web/no_results.svg" style="width: 50%; max-width: 300px; min-width: 240px;"></div>
			</div></div>
  
    </div>
 
  </div>
