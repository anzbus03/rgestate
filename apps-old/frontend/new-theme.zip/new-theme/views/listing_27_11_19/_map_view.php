    <div class="mapColumn" id="map-load"  style="height:calc(100vh - 128px)!important; " >
 
            </div>
	<?php 
	$locations = array();
	$avg_latitude ='';
	$avg_longitude ='';
	$count = 0; 
	$latitude = '25.266666';
	$longitude = '55.316666';
	foreach($ads as $k=>$v){
		if($k==0){
			$latitude = $v->location_latitude;
			$longitude =$v->location_longitude;;
		}
	   
		$locations[] = array($v->MapHtml,$v->location_latitude,$v->location_longitude,$k+1,$v->TypeColor);	 
	}
	
	 
	 
	?>
 
<script type="text/javascript">
	
    var locations =  <?php echo json_encode($locations);?>;
    var my_logitude = '<?php echo $longitude;?>';
    var my_latitude = '<?php echo $latitude;?>';
  var bounds = new google.maps.LatLngBounds();
   var map = new google.maps.Map(document.getElementById('map-load'), {
     //  zoom: 11,
      center: new google.maps.LatLng(my_latitude,my_logitude),
      mapTypeId: google.maps.MapTypeId.ROADMAP,
      disableDefaultUI: true,
scrollwheel: false,
    navigationControl: true,
    mapTypeControl: false,
    scaleControl: true,
    zoomControl:true,
    draggable: true,
    });

    var infowindow = new google.maps.InfoWindow({
           
          maxWidth: 200
        });
 

    var marker, i, markerData = [];
 

    for (i = 0; i < locations.length; i++) { 
		
		    
	 
	   marker = new google.maps.Marker({
        position: new google.maps.LatLng(locations[i][1], locations[i][2]),
        map: map,
        icon: {
      path: google.maps.SymbolPath.CIRCLE,
      scale: 4, //tamaño 0
      fillColor :locations[i][4],
      fillOpacity: 1,
        strokeColor: locations[i][4],
    },
      });
	  markerData.push(marker);
  bounds.extend(marker.position);

      google.maps.event.addListener(marker, 'click', (function(marker, i) {
        return function() {
          infowindow.setContent(locations[i][0]);
          infowindow.open(map, marker);
           //  marker.set('labelClass', 'dotNewListings typeEmphasize active  noWrap');
          
        }
      })(marker, i));

      google.maps.event.addListener(marker, 'mouseover', (function(marker, i) {
        return function() {
          infowindow.setContent(locations[i][0]);
          infowindow.open(map, marker);
         //  marker.set('labelClass', 'dotNewListings typeEmphasize active  noWrap');
          
        }
      })(marker, i));



 





      google.maps.event.addListener(marker, 'mouseout', (function(marker, i) {
        return function() {
         infowindow.close();
           // marker.set('labelClass', 'dotNewListings');
             
          
        }
      })(marker, i));


      
    }
   
     map.fitBounds(bounds);
     
 
    google.maps.event.addListener(infowindow, 'domready', function() {

    // Reference to the DIV that wraps the bottom of infowindow
    var iwOuter = $('.gm-style-iw');

    /* Since this div is in a position prior to .gm-div style-iw.
     * We use jQuery and create a iwBackground variable,
     * and took advantage of the existing reference .gm-style-iw for the previous div with .prev().
    */
    var iwBackground = iwOuter.prev();

    // Removes background shadow DIV
    iwBackground.children(':nth-child(2)').css({'display' : 'none'});

    // Removes white background DIV
    iwBackground.children(':nth-child(4)').css({'display' : 'none'});

   // Moves the shadow of the arrow 76px to the left margin.
    iwBackground.children(':nth-child(1)').attr('style', function(i,s){ return s + 'left: 76px !important;'});

    // Moves the arrow 76px to the left margin.
    iwBackground.children(':nth-child(3)').attr('style', function(i,s){ return s + 'left: 76px !important;'});

    // Changes the desired tail shadow color.
     iwBackground.children(':nth-child(3)').find('div').children().css({'box-shadow': 'rgba(72, 181, 233, 0.6) 0px 1px 6px', 'z-index' : '1'});

    // Reference to the div that groups the close button elements.
    var iwCloseBtn = iwOuter.next();

    // Apply the desired effect to the close button
    iwCloseBtn.css({opacity: '1', right: '38px', top: '3px', border: '', 'border-radius': '13px', 'box-shadow': '0 0 5px #3990B9','display':'none'});

    // If the content of infowindow not exceed the set maximum height, then the gradient is removed.
    if($('.iw-content').height() < 140){
      $('.iw-bottom-gradient').css({display: 'none'});
    }

    // The API automatically applies 0.7 opacity to the button after the mouseout event. This function reverses this event to the desired value.
    iwCloseBtn.mouseout(function(){
      $(this).css({opacity: '1'});
    });
  });




	
      $(".xsCol12Landscape").mouseover(function() {
		var i = $(this).index();
		var marker = markerData[i];
	// $('.cardPhoto source').attr('srcset', '#image');
	// $('.cardPhoto img').attr('src', '#image').alt('#address');
	// $('.cardDetails .cardPrice').attr('text', '#price');
	
		var imgsrcset = $(this).find('.cardPhoto source').attr('srcset');
		
		var imgsrc = $(this).find('.cardPhoto img').attr('src');
		
		var imgalt = $(this).find('.cardPhoto img').attr('alt');
		
		var price = $(this).find('.cardDetails .cardPrice').text();
		var ad_title = $(this).find('.txt').text();
		var li_title = $(this).find('.listInline').html();
		
		
		var locationHTML = '<div class="cardPhoto backgroundPulse" style="height:80px;width:200px; background-image:url('+imgsrc+') ; background-position:center center;background-size:cover; background-repeat:no-repeat;"> <div class="tagsListContainer"></div></div><div class="cardDetails man pts pbn phm h6 typeWeightNormal"><div><span class="cardPrice h5 man pan typeEmphasize noWrap typeTruncate">' + price + '</span></div><div data-reactid="61"> <ul class="listInline typeTruncate mvn" data-reactid="62">'+li_title+'</ul></div><div class="cardDetails man pts pbn phm h6 typeWeightNormal"  ><div ><span class="cardPrice h5 man pan typeEmphasize noWrap typeTruncate" data-reactid="59" style="width:120px;font-size:12px;">'+ad_title+'</span></div></div>';		
		
		
		//console.log(i);
		if(marker && locations[i]) {
			infowindow.setContent(locationHTML);
			infowindow.setContent(locationHTML);
			infowindow.open(map, marker);
		}        
      });
  </script>
 
