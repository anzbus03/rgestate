<style> .padding-0{ padding:0px !important;}.margin-0{ margin:0px !important;}


</style>
<div id="map_locator">
<?php   $this->renderPartial('_filter_html_top_map');?>
<?php 
if(empty($adsCount)){
 
	$this->renderPartial('_no_result_page',array('full_width'=>true)); 
}
else{   
	
	?> 
	
	 
	
 
        <div class="container margin-top-40" id="">
           
            <div class="row hFrwo margin-0">
                <div class="col-md-9 padding-0 the-head-sorter">
                <h3 class="headline  margin-bottom-0 margin-left-0"><?php 
									$head_section_title1 ='';
									if(!empty($categoryModelm)){
											$head_section_title1 = $categoryModelm->category_name;
											$prop_title = ''; 
									}
									else if(!empty($listingTypeModelTitle)){
											$head_section_title1 = $listingTypeModelTitle .'properties'; 
											$prop_title = 'properties';
									}
									$title1 = Yii::t('app','{c} for {s}',array('{c}'=>!empty($head_section_title1) ? $head_section_title1 : 'Properties'));
									
									if(empty($sectionModel)){
										$title1 =  Yii::t('app',$title1,array('for {s}'=>''));									 
										$title1 =  $title1;
									}
									else{
										$title1 =  Yii::t('app',$title1,array('{s}'=>$filterModel->SectionViewTitle));
									}
									if(empty($title)){
										$title1 = 'Explore '.$title1; 
									}

									switch($filterModel->section_id){
									case  'new-development':
									$tt =    'New Developments' ;
									break;
									default:
									$tt =    $title1 ;
									break;

									}
									echo $tt ; echo !empty($title) ?  $title : '' ;
					 
                    ?>
                    </h3>
                </div>
                  <div class="col-sm-3 pull-right padding-right-0 map-changer" style="max-width:135px;">
                    <div class="map_btns text-right miniHidden xxsHidden">
						<?php $get =$_GET ; $get['view'] = 'map' ;?> 
                        <a href="<?php echo  Yii::app()->createUrl('listing/index', array_filter($get) );?>" title="Map View" class="map_icon disabled gridIcon">
                            <i class="fa fa-map"></i>
                        </a> 
                        <a href="javascript:void(0)" title="Grid View" class="th_icon gridIcon">
                            <i class="fa fa-th"></i>
                        </a> 
                    </div>
                </div>
               
                <div class="col-sm-3  pull-right map-sorter">
                    <div class="ak_search">
                        <div class="form mvn">
                            <div class="horizontalContainer">
                                <div style="flex: 4 1 0%;">
                                    <div class="field mtn pln">
                                        <span id="sortFieldItem" class="fieldItem fieldItemFullWidth select">
                                             <div class="selectPretty" data-reactid="12">
                                                        <select id="sortingOptions" data-reactid="13" name="sort"  onchange="alertthisVal(this);setThisValueSort(this)">
														<?php 
														$sortArray = $filterModel->sortArray();
														foreach($sortArray as $k=>$v){
														echo '<option value="'.$k.'">'.$v.'</option>';
														} 
														?>
                                                        </select>
                                                        <div class="selectDisplay btn btnDefault" data-reactid="23"><span class="selectLabel" data-reactid="24"><?php echo $filterModel->sortHTml;?></span><span class="selectTrigger" data-reactid="25"><i class="fa fa-chevron-down" data-reactid="26"></i></span></div>
                                                    </div>
                                        </span>
                                    </div>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
               
            </div>
              <div class="row hFrwo margin-0 hidden " style="margin-top:-10px;">
                <div class="col-sm-4 padding-0 margin-0">
                    <span class="  margin-0" id="loader_againn">
                      
                               <?php 
                                if(!empty($title)){
    									    	echo Yii::t('trans', '{c} properties  available on {t} ' ,array('{c}'=>$adsCount ,'{t}'=> $title ))  ;
    										}else{
    										    echo Yii::t('trans', '{c} properties  available' ,array('{c}'=>$adsCount ))  ;
    							}
                                ?> 
                                  
                    </span>
                </div>
            </div>
          
        </div>
		
		<?php
		/*	if(!empty($load_location)){ ?> 
		<div class="container margin-top-20">
			 <div class="col-md-12  padding-0">
						  <h3 class="headline  margin-bottom-20   padding-left-0   col-md-12 no-margin-left  "> Top Cities</h3> 
			  </div>
			  <div class="clearfix"></div>
		<div class="_ba2wq3" id="ids">
                                     <?php
                                     $country_get = Yii::App()->request->getQuery('country','');
										foreach($load_location as $k=>$v){ ?>
  <a href="<?php echo Yii::app()->createUrl('listing/index',array('section_id'=>$filterModel->section_id,'country'=> $country_get));?>">
                  <div class="col-md-3">
                     <div class="spanstyle">
                        <div class="col-md-4" style="padding: 0px;width:80px;"><img src="<?php echo $this->appAssetUrl('images/Villas.jpg');?>" alt=""> </div>
                        <div class="col-md-8 spanfontstyle">
                           <h3><?php echo $v->state_name;?></h3>
                            <p>
                           <i><?php echo !empty( $country_name) ?  $country_name : '';?></i>    .
                           </p>
                        </div>
                     </div>
                  </div>   </a>
                                                        <?php } ?>
									
									<div class="clearfix"></div></div>
									<div class="clearfix"></div>
		</div>
		  
         <script> $(function(){ generateLinksSlider2(); })
         </script>
		<?php }  */
		?>  
		<div class="container margin-top-20">
			<?php // echo $this->renderPartial('_ad_section_listing');?>
			 <style>
	.listing-item-content.absC { position:absolute;z-index:11111;}
	html .listing-item-container .listing-item-content.absC h3.white {  color:#fff !important; text-shadow: 2px 2px 3px #666;}
	._add_row_5 .listing-item{ height:242px;  }
	._add_row_3 .listing-item{ height:208px;  }
	 
	._add_row_1 .simple-slick-carousel .slick-slide{ padding:10px;  }
	.slick-prev, .slick-next { z-index:1; border-radius: 50% !important;padding: 10px 10px;}
	.slick-prev::before, .slick-next::before { font-size:18px;}
	.slick-prev {    left: 46px; } 
	.home_section .seperate_mar { padding:0px !important; }
  ._ba2wq3 {
    margin-left: -8px !important;
    margin-right: -8px !important;
}

.listing_page ._add_row_3  .col-sm-4.mul_sliderh { padding-right:0px;  }
.listing_page ._add_row_3  ._ba2wq3.rrf {
    margin-left: -15px !important;
    margin-right: 0px !important;
} 
html .listing_page #map_locator ._add_row_3 .listing-item-content.spanfont  {
    padding-top: 6px;
}
html .listing_page #map_locator ._add_row_3 .listing-item-content.spanfont h3  {
    margin: 0 !important;
}
.listing_page #slideSheet.mrsNN  {
    margin-left: -8px !important;
    margin-right: -8px !important;
}
.listing_page ._add_row_3 .block_tag.for_sale_tag {
    background: #006800;
    color: #fff;
}
  .listing_page ._add_row_3  .col-sm-4:nth-child(3n+1) {
    clear: both;
}
.agents_d ._eiid8jn , .agents_d ._w1effmn  { color: #484848 !important; } 
.agents_d .listing-item {
    background: #fff;
    border: 1px solid #eee;
}
	 </style>
			  <div class="ad_row_1 margin-top-30">
				 <?php
		    	 $loaded_advertisement = false ; 	 
				$secModel = !empty($sectionModel) ?  $sectionModel->section_name : '' ;
				 foreach($tags as $k=>$v){
				         if($v->tag_id=='12' and !$loaded_advertisement) {
								$loaded_advertisement = true ; 
								echo $this->renderPartial('_ad_section_listing');
						}
						 $criteria = PlaceAnAd::model()->search(1);
						 $criteria->join  .= ' INNER  JOIN {{place_ad_tags}} tg on tg.ad_id = t.id and tg.tag_id = :tag_id'  ;
						 $criteria->join  .= ' left join {{category}} cat ON cat.category_id = t.category_id ';
						 $criteria->select  .= ' ,cat.category_name, (SELECT image_name FROM {{ad_image}} img  WHERE  img.ad_id = t.id and  img.status="A" and  img.isTrash="0"  limit 1  )   as ad_image '  ;
						 $order = '';
						
						 if(!empty($sectionModel)){
													
							 $criteria->condition .= '  and t.section_id = "'.(int) $sectionModel->section_id.'"  ';
						 }
						 else if(!empty($categoryModelm)){
							  $criteria->condition .= '  and t.category_id = "'.(int) $categoryModelm->category_id.'"  ';
						 }
						 else if(!empty($listingTypeModel)){
							  $criteria->condition .= '  and t.listing_type = "'. $listingTypeModel .'"  ';
						 }
						 if(!empty($filterModel->country)){
							 $order .= ' t.country = "'.(int) $filterModel->country.'" desc , ';
						 }
						 $criteria->order = $order.'-t.priority  desc , t.id desc'; 
						 $criteria->limit =   $v->limit_p;
						$criteria->params[':tag_id'] = $v->tag_id;
						if(empty($sectionModel) and !empty($categoryModelm) and  in_array($categoryModelm->category_id,array('101','96')) and $v->tag_id=='12' ){
							 $header = Yii::t('app',$v->tag_name,array('{t}'=>$head_section_title,'{p}'=>$prop_title)) ;
							 $criteria2 = clone $criteria;
							 $this->turnbyTurn($criteria2,$v,0,9,1, $header );
							 $this->turnbyTurn($criteria2,$v,0,9,2,'');
							 $this->turnbyTurn($criteria2,$v,9,9,1,'');
							 $this->turnbyTurn($criteria2,$v,9,9,2,'');
							  
							 
						 }
						 else if(in_array($v->tag_id,array('7','8'))){
							  $agentData = array();
							  if(isset($stateModel) and !empty($stateModel)){
								  $agentData['agent_regi'] = $stateModel->state_id ;
							  }
							  if(!empty($filterModel->country)){
								$agentData['country_id'] = $filterModel->country ;
							  }
							 $criteria = ListingUsers::model()->findAgents( $agentData ,$count_future=false,$user_type='A',$return=1);
						  
								  $criteria->join .= ' INNER JOIN {{listing_users_tag}} tg on tg.user_id = t.user_id and tg.tag_id = :tgid ';
								   if($v->tag_id=='7'){
										$criteria->params[':tgid'] = '13';
								   }
								   if($v->tag_id=='8'){
										$criteria->params[':tgid'] = '16';
								   }
								   $field = Agents::model()->findAll($criteria);
								   if(!empty($field)){
									   $header = Yii::t('app',$v->tag_name,array('{t}'=>$head_section_title,'{p}'=>$prop_title)) ;
									   $sub_header =   '' ;
									   $rw_ids = 'row_ids_'.$v->now_of_rows.'_'.$v->tag_id;
									   $tag = $v; 
									   echo'<div class="agents_d">';
									  $this->renderPartial('//user_listing/ad/_ad_row'.$v->now_of_rows,compact('tag','field','header','sub_header','rw_ids','secModel'));
									   echo '</div>';
								   }
						 }
						else{
						$field = PlaceAnAd::model()->findAll($criteria);
						 if(!empty($field)){
						   $head_section_title = '' ; 
						   $prop_title = '' ; 
						   $prop_title = 'property';
					       if(!empty($categoryModelm)){
							   $head_section_title = $categoryModelm->category_name;
							   $prop_title = ''; 
						   }
						   else if(!empty($listingTypeModelTitle)){
							   $head_section_title = $listingTypeModelTitle; 
							   $prop_title = 'property';
						   }
						 $header = Yii::t('app',$v->tag_name,array('{t}'=>$head_section_title,'{p}'=>$prop_title)) ;
						 $sub_header =   '' ;
						 $rw_ids = 'row_ids_'.$v->now_of_rows.'_'.$v->tag_id;
						 $tag = $v; 
						  $this->renderPartial('ad/_ad_row'.$v->now_of_rows,compact('tag','field','header','sub_header','rw_ids','secModel'));
						 }
						 }
				 } 
				 ?>	 
				 
				 <div class="clearfix"></div>
		</div>
			<?php
		if(!$loaded_advertisement){ ?> 
			<div class="container margin-top-20 ">
			<?php      echo $this->renderPartial('_ad_section_listing');?>
			</div>
		<?php } ?> 
			
			  
			
		<div class="container margin-top-40">
		   <h3 class="headline  margin-bottom-40 margin-left-0"><?php 
                 
					if(!empty($title)){ 
							echo Yii::t('trans', '{s} in {l}' ,array('{l}'=>$title, '{s}'=>$tt));
					}else{
									echo $tt;
					}
                    ?>
                    </h3>
		<div id="slideSheet" class="mrsNN" >
		<ul class="list-group  no-margin no-padding listing_pageStyleN" id="suggestionList" style="overflow: hidden;clear: both;">
		<?php
		$works = $ads ; 
		$this->renderPartial('//listing/_list_proprty',compact('works','checkIcon','property_of_featured_developers' )); 

		?>		
		<li id="suggest_friends_last_id" style="display:none;"></li>
		</ul>
	

		<div style="clear:both"></div>
		<div class="bar-results bottom">
		<div class="paging-holder">
		<div class="paging"><div class="text-center loadingDiv marTop15 no-margin"> </div> </div>
		</div>
		</div>
		
		
			<div class="clearfix"></div>
		</div>
		<div class="clearfix"></div>
		</div>
<div class="clearfix"></div>
</div>
      <?php $limit =  '8' ; ?> 
  		<script type="text/javascript">
			/*
									var total_pages =  '<?php  echo (int)$pages->pageSize ;?>'
								var loadingHtml    	= '<a href="javascript:void(0)" class="btn  btn-primary   btn-more btn-lg btn-shadow btn-rounded btn-icon-right disabled"><i class="fa fa-spinner fa-pulse margin-right-10"></i></a>';
								var	loadMoreHtml 	= '<a href="javascript:void(0)" class="btn   btn-primary  btn-shadow btn-rounded btn-icon-right"   id="refresh_list" ><?php echo  'Load More' ;?></a>';  
								var afterFinishHtml = '';   
								var elementId='slideSheet';
								var appendId='suggest_friends_last_id';
								var scroll=true;
								var limit='<?php echo $limit;?>';
								var offest='<?php echo  $limit;?>';
								var formID  = 'frmId';
								var checkFuture = true ;
								var scroll_Pagination5;
								var busy = false;
								var slug ='<?php echo Yii::app()->createUrl('listing/fetch_work');?>';
								var loadingDiv ; 
								$(document).ready(function () {
										loadingDiv  =  $('.loadingDiv');
										caroselSingleAfter();
									});
 
					var currentPage = 1;
					var intervalID = -1000;				 
					var scroll = true;
					var stopPagination = false;
					$(document).ready(function () {
						  $(window).scroll(function() {
						 
					
						  if($(window).scrollTop() + $(window).height() > $('#slideSheet').height() &&  scroll && !stopPagination) {
							   
							  scroll = false;
							  
							  checkScroll();
						}
						})
					 })
				 
					
	 */
                     </script>
                     
                     
<?php } ?>                        
<script>
var timer_ajax; 
var mainListUrl = '<?php echo Yii::app()->createUrl('listing/index');?>/';
var autoCompleteUrl = '<?php echo Yii::app()->createUrl('listing/autocomplete');?>';
  $(function(){ changeForm() ;  caroselSingleAfter(); })
</script>
 <style>
	 #suggestionList .col-sm-3:nth-child(4n+1){ clear:both; }
				.autocomplete-suggestions { border: 1px solid #999; background: #FFF; overflow: auto; cursor:pointer ;  }
				.autocomplete-suggestion { padding: 2px 5px; white-space: nowrap; overflow: hidden; }
				.autocomplete-selected { background: #F0F0F0; }
				.autocomplete-suggestions strong { font-weight: normal; color: #000; }
				.autocomplete-group { padding: 2px 5px; }
				.autocomplete-group strong { display: block; border-bottom: 1px solid #000; }
				
				.btnTertiary, .btnTertiary:visited, a.btnTertiary, a.btnTertiary:visited {
				border: 1px solid #FF5A5F;
				background: #fff;
				color: #FF5A5F;
				font-weight: 600;
				}
			    .btnTertiary:hover  { background: #FF5A5F;color:#fff; border: 1px solid #FF5A5F; } 
            </style>
			<style>.boxCard{ display:none; }.opened .boxCard{ display:block !important; }</style>
  
   
