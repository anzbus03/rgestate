<style>
	  input, input[type=text], input[type=password], input[type=email], input[type=number], textarea, select {
    	height: 51px;
            line-height: 51px;
            padding: 0 20px;
            outline: 0;
            font-size: 15px;
            color: gray;
            margin: 0 0 16px;
            max-width: 100%;
            width: 100%;
            box-sizing: border-box;
            display: block;
            background-color: #fff;
            border: 1px solid #dbdbdb;
            box-shadow: 0 1px 3px 0 rgba(0,0,0,.06);
            font-weight: 500;
            opacity: 1;
            border-radius: 3px;
    margin-left: 0 !important;
}
#contact input,#contact label,#contact textarea {
    margin-bottom: 0px;  margin-top: 0px;
}
#contact .rows {
    margin-bottom: 15px;
}
.errorMessage {   color:#e13009!important;}
	  </style>
<div class="clearfix"></div>
  <!-- Header Container / End --> 

<!-- Content
================================================== -->

<!-- Map Container -->
 
<div class="clearfix"></div>
<!-- Map Container / End -->

<div class="home-banner-outer contact-us">
 <div class="inner-banner " style="background:url('<?php echo $this->app->apps->getBaseUrl('assets/img/valuation.jpg');?>') no-repeat center;height:75vh;background-size:cover;"  >
    <div class="olay" style="position: absolute;left: 0;right: 0 !important;bottom: 0;top: 0;background: rgba(0,0,0,0.1);"></div>
  <div class="container">
    <div class="tit-innrhd animatedParent">
      <div class="theme-title banner_text animated growIn go">
      
        	        	   
				 
      </div>
    </div>
    
</div>
</div>
 

</div>
 
<!-- Container / Start -->
<div class="container margin-top-20">
<style>
	.tit-innrhd {
     
    text-align: center;
}

.theme-title::before {

    position: absolute;
    border-left: 2px solid #fff;
    border-top: 2px solid #fff;

}
.theme-title-part::before, .theme-title::before {

    content:unset;
    width: 26px;
    height: 26px;
    top: 0;
    left: 0;

}
.theme-title h1 { color: #fff; position:relative;  font-size: 24px;
 
}  
.theme-title p { color: #fff; position:relative;  font-size: 16px;
 
    max-width:600px;margin:Auto; margin-top:50px;
}  
 
 html a#arablogo::after { color:#fff; }

    .left-content-bl {
  
    border-right: 1px dotted #d8e4ef;
}.right-contentl {
    padding: 0px 0px 25px 0px !important;
   
}.sidebar-header {
    font-size:19.6px;
    border-bottom: 3px solid #d8e4ef;
    padding:  0px 0 10px 2px;
     font-size: 22px;
line-height: 32px;
}
    #pre-method-text {
    margin-top: 8px;
    color: #7B7B7B;
}#contact-method li {
   
    padding-bottom: 4px;
}
#contact-telephone {
  
    padding-left: 0px;
}#contact-telephone span, #contact-skype span, #contact-email span {
    font-weight: bold;
    font-size: 1.1em;
} a.link-color:hover{ text-decoration:underline; color : var(--link-color);}
.link-color { color : var(--link-color);}
.pk-text { color: var(--logo-color);}
#contact #mainContainerClass { background: #eee; max-width:100%;}
</style>
	<div class="row margin-top-40">

		<!-- Contact Details -->
		<!-- Contact Form -->
	 
		 <style>
		 .forms-wrapper {
    width: 100%;
    position: relative;
    background: #fff;
    border-radius: 3px;
    box-shadow: 0 3px 8px 0 rgba(0,0,0,.15),0 1px 2px 0 rgba(0,0,0,.3);
    top: 0;
    padding: 30px;margin-top: -30vh;
    width: 900px;
margin-left: auto;
margin-right: auto;
max-width: 98%;
} 
.forms-wrapper { margin-bottom:50px; }		
.forms-wrapper textarea		{
    height: 50px !important;
    min-height: unset !important;
}
.forms-wrapper .sign-in-form .errorMessage {
    color: #e13009 !important;
    position: relative;
    top: unset !important;
    position: relative;
    bottom: unset !important;
    width: 100% !important;
    line-height: 30px;
    font-size: 14px;
}
@media only screen and (max-width: 600px) {
 .forms-wrapper .form-group   { width:100%;float:left; padding-right:1%}
 .forms-wrapper .form-group.spl-12   { width:100%;float:left; padding-right:1%}
 .forms-wrapper { padding:10px; padding-top:30px; }
 .use-mortgagecalc {  }.theme-title p{ font-size:14px;}
 html .checkboxes label { font-size:11px; line-height:1.2; }
 .checkboxes { margin-top:10px; margin-right:0px; }.home-banner-outer.contact-us .inner-banner { border-radius:0px !important; }
}/*
 CSS for the main interaction
*/
.tabset > input[type="radio"] {
  position: absolute;
  left: -200vw;
}

.tabset .tab-panel {
  display: none;
}
.tabset h2 { font-size:23px; }
.tabset  label.required { font-weight:600 !important; }
.tabset > input:first-child:checked ~ .tab-panels > .tab-panel:first-child,
.tabset > input:nth-child(3):checked ~ .tab-panels > .tab-panel:nth-child(2),
.tabset > input:nth-child(5):checked ~ .tab-panels > .tab-panel:nth-child(3),
.tabset > input:nth-child(7):checked ~ .tab-panels > .tab-panel:nth-child(4),
.tabset > input:nth-child(9):checked ~ .tab-panels > .tab-panel:nth-child(5),
.tabset > input:nth-child(11):checked ~ .tab-panels > .tab-panel:nth-child(6) {
  display: block;
}

/*
 Styling
*/
 

.tabset > label {
  position: relative;
  display: inline-block;
  padding: 15px 15px 25px;
  border: 1px solid transparent;
  border-bottom: 0;
  cursor: pointer;
  font-weight: 600;
}

.tabset > label::after {
  content: "";
  position: absolute;
  left: 15px;
  bottom: 10px;
  width: 22px;
  height: 4px;
  background: #8d8d8d;
}

.tabset > label:hover,
.tabset > input:focus + label {
  color: #06c;
}

.tabset > label:hover::after,
.tabset > input:focus + label::after,
.tabset > input:checked + label::after {
  background: #06c;
}

.tabset > input:checked + label {
  border-color: #ccc;
  border-bottom: 1px solid #fff;
  margin-bottom: -1px;
}

.tab-panel {
  padding: 30px 0;
  border-top: 1px solid #ccc;
}
 

.tabset {
  max-width: 65em;
}.form-control.LJB {
   
    max-width: 435px;
}
.tabset a { color:var(--link-color); }
		 </style>
	 
		<div class="col-lg-12 padding-0">
		    <div class="row">
             <div class="col-sm-12">
			<section id="contact">
				 <div id="contact-message"></div> 
		 
						<div class="forms-wrapper">
							<!-- 
  
  Radio version of tabs.

  Requirements:
  - not rely on specific IDs for CSS (the CSS shouldn't need to know specific IDs)
  - flexible for any number of unkown tabs [2-6]
  - accessible

  Caveats:
  - since these are checkboxes the tabs not tab-able, need to use arrow keys

  Also worth reading:
  http://simplyaccessible.com/article/danger-aria-tabs/
-->
 <script>
 function initAutocomplete1()
{
	 
	var input2 = document.getElementById('PropertyValuation_address');
	var options2 = { 
		  types: ['address'],
	componentRestrictions: {country: '<?php echo COUNTRY_CODE;?>' }
	};

 	var autocomplete2  = new google.maps.places.Autocomplete(input2, options2);
	 google.maps.event.addListener(autocomplete2, 'place_changed', function() { 
		 	var place2 = autocomplete2.getPlace();
			var lat2 = place2.geometry.location.lat();
			var lng2 = place2.geometry.location.lng();
			$("#<?php echo $model->modelName;?>_location_latitude").val(lat2);
			$("#<?php echo $model->modelName;?>_location_longitude").val(lng2);
			 
			 
			
			
});
	 
	 

}
$(function(){
	 initAutocomplete1(); 
	})

 </script>
 <div class="tabset">
<?php
   if(!empty($HomeInsuraceCompany)){
	   foreach($HomeInsuraceCompany as $k=>$v){ 
		   $active = '' ;
		   if(empty($slug)){
			   if($k=='0'){
			   $active = 'checked' ;
			   $active_id = $v->primaryKey;
			   $activeModel = $v;
			   }
		   }
		   else{
			   if($slug==$v->slug){
			    $active =  'checked' ;
			    $activeModel = $v;
			    $active_id = $v->primaryKey;
				}
		   }
		   
		?>
		
  <input type="radio" name="tabset" id="bank_<?php echo $v->primaryKey;?>" aria-controls="marzen_<?php echo $v->primaryKey;?>" <?php echo   $active ;?>>
  <label for="bank_<?php echo $v->primaryKey;?>" style="padding:0px;"><a style="display: block;width: 100%;height: 100%;padding:15px 15px 25px" href="<?php echo Yii::app()->createUrl('forms/property_valuation',array('slug'=>$v->slug));?>"><?php echo $v->bank_name;;?></a></label>
  
  <?php }
  
	}
	if(empty($activeModel)){
		 throw new CHttpException(404, Yii::t('app', 'The requested page does not exist.'));
	}
   ?>  
  <script>
  $(function(){ $('select').select2(); })
  
  </script>
  <h1>Know the right price of your property</h1>
  <p>Just let us know few property details.</p>
  <div class="tab-panels">
   <div id="WERWER"></div>
    <section id="marzen_1" class="tab-panel" style="display:block !important;">
      
      <div class="row">
		  <div class="col-sm-7">
	                <?php $this->renderPartial('//forms/_success_html_valuation');?>
                
                <style>
             #cn_property{padding:0!important;overflow:hidden}html input.input-text.form-control,html select.input-text.form-control,input.pwdfield{border:1px solid #dfe0e3;border-radius:3px;color:#72727d;font:13px arial;height:24px;padding:1px 0;width:100%;margin-right:10px}html textarea.input-text.form-control{border:1px solid #dfe0e3;line-height:1.4;padding:10px 8px;color:#72727d;font:13px arial}.sign-in-form label{margin-bottom:0}.sign-in-form .btn.btn-primary{background-color:var(--logo-color);box-shadow:unset;border:0;font-family:Lato,Helvetica,Arial,sans-serif;font-size:14px;color:#fff;line-height:40px;border-radius:5px}.btn-sm-s{max-width:100%!important;line-height:35px!important;padding:0}.col-sm-5 label{color:#72727d!important;line-height:1;text-align:right}html .container_check input:checked~.checkmark{background-color:#90ee90;border:1px solid transparent}.container_check input:checked~.checkmark{background-color:#dc143c;border:1px solid transparent}.container_check .checkmark{position:absolute;top:0;left:0;height:20px;width:20px;-webkit-border-radius:3px;-moz-border-radius:3px;-ms-border-radius:3px;border-radius:3px;-moz-transition:all .3s ease-in-out;-o-transition:all .3s ease-in-out;-webkit-transition:all .3s ease-in-out;-ms-transition:all .3s ease-in-out;transition:all .3s ease-in-out}.container_check input:checked~.checkmark::after{display:block}.container_check .checkmark::after{content:"";position:absolute;display:none;left:7px;top:3px;width:5px;height:10px;border:solid #fff;border-top-width:medium;border-right-width:medium;border-bottom-width:medium;border-left-width:medium;border-top-width:medium;border-right-width:medium;border-bottom-width:medium;border-left-width:medium;border-width:0 2px 2px 0;-webkit-transform:rotate(45deg);-ms-transform:rotate(45deg);transform:rotate(45deg)}#frm_ctnt .errorMessage{font-size:12px;color:#e13009!important;padding:2px 0 0;top:unset!important}.grecaptcha-badge{z-index:999911119999!important}
                .success-modal .info .title {
    font-weight: var(--weight-800);
    margin: 0;
    line-height: 1.42857143;
    color: #333;
    font-weight: 600 !important;
    font-size: 18px;
} .form-control.LJB {
    border-color: #ddd;
    appearance: none;
    border-radius: 16px;
    border-style: solid;
    border-width: 2px;
    line-height: 36px;
    min-height: 48px;
    width: 100%;
    text-indent: 18px;
    font-size: 16px !important;
}
html textarea.input-text.form-control {
border-color: #ddd;
appearance: none;
border-radius: 16px;
border-style: solid;
border-width: 2px;
line-height: 36px;
min-height: 48px;
width: 100%;
text-indent: 18px;
font-size: 16px !important;
}.radio-toolbar input[type="radio"] {
  display: none;
}

.radio-toolbar label {
  display: inline-block;
  background-color: #fff;
  border:1px solid #7f7f7f;
  border-radius:5px; 
  padding:  5px 15px;
   
  font-size: 16px;
  cursor: pointer;
  color: var(--black-color);
  height: 60px;
display: flex;
justify-content: flex-start;
align-items: center;
background-color: #fff;
color: #7f7f7f;
font-size: 14px;
cursor: pointer;
line-height: 1.43;
transition: all .3s ease-in-out;
margin-bottom:10px !important;
width:calc(33% - 20px);
box-shadow: 0 1px 3px 0 rgba(0,0,0,.06);border: 1px solid #dfe0e3;
}.radio-toolbar.smalln label { width:width:calc(33.3333%- 30px);; text-align:center; } 
.radio-toolbar label svg { width:42px;  height:42px; margin-right:5px;}
.radio-toolbar input[type="radio"]:checked+label {
  background-color:var(--secondary-color); color:#fff; 
}
.radio-toolbar label {
    
    float: left;
    margin-right: 10px;
    line-height:1.5;
}
.tabset > input:checked + label{ background-color:var(--secondary-color) !important;color:#fff !important;  }
.tabset > input:checked + label a{  color:#fff !important;  }
.tab-panel {
    
    border-top: 1px solid var(--secondary-color);
}
                </style>
                 <script>
                     function ajaxSubmitHappenlistn(e,t,i,a){i?alert("error"):$.ajax({type:"POST",url:a,data:e.serialize(),success:function(e){var t;e=JSON.parse(e);$("#requestBtn").length>0&&(void 0!==(t=$("#requestBtn").attr("data-html"))&&($("#requestBtn").attr("disabled",!1),$("#requestBtn").html(t)));$("#bb2").length>0&&(void 0!==(t=$("#bb2").attr("data-html"))&&($("#bb2").attr("disabled",!1),$("#bb2").html(t)));"1"==e.status?($("#topThirdPlacementLeadFormContainer").hide(),	 $("html, body").animate({    scrollTop: $("#WERWER").offset().top}, 1000), $(".rms-data-h").addClass("hide"),$(".success-modal").addClass("visible"),Moveit.put(popGroup,{start:"0%",end:"0%",visibility:0}),Moveit.put(tick,{start:"0%",end:"0%",visibility:0}),Moveit.put(tick2,{start:"0%",end:"0%",visibility:0}),Moveit.put(circle,{start:"0%",end:"0%",visibility:0}),Moveit.animate(circle,{visibility:1,start:"0%",end:"100%",duration:1,delay:0,timing:"ease-out"}),Moveit.animate(tick,{visibility:1,start:"0%",end:"100%",duration:.2,delay:.5,timing:"ease-out"}),Moveit.animate(tick2,{visibility:1,start:"0%",end:"80%",duration:.2,delay:.7,timing:"ease-out"}),Moveit.animate(popGroup,{visibility:1,start:"20%",end:"60%",duration:.2,delay:1,timing:"ease-in"}).animate(popGroup,{visibility:1,start:"100%",end:"100%",duration:.2,delay:1.2,timing:"ease-in-out"})):($("#msg_alert").html(e.msg).show(),setTimeout(function(){$("#msg_alert").hide()},7e3))}})}
                     
                 </script>
               <div id="topThirdPlacementLeadFormContainer" class="pan plm rms-data-h">
               <div class="backgroundBasic sign-in-form   " id="topPanelLeadFormContainer">
                     <div data-reactroot="" class="pvn clearfix">
                        <div class="false"  >
							      
						   <?php
						   $mainTex =  'Send' ; 
						      
							$form = $this->beginWidget('CActiveForm', array(
							'id'=>'signin-form',
							'action'=>Yii::app()->createUrl('forms/validateValuation'),
							'enableAjaxValidation'=>true,
							'clientOptions'=>array(
							'validateOnSubmit'=>true,'validateOnChange'=>false,
							'beforeValidate' => 'js:function(form) {

							form.find("#bb2").html("'. 'Validating...' .'");
							return true;
							}',
							'afterValidate' => 'js:function(form, data, hasError) { 
							if(hasError) {
							form.find("#bb2").html("'.$mainTex.'");
							return false;
							}
							else
							{
							form.find("#bb2").val("'. 'Please wait..' .'"); 
				
							ajaxSubmitHappenlistn(form, data, hasError,"'.Yii::app()->createUrl('forms/SendValuation').'"); 
						
							}
							}',
							),
							'htmlOptions'=>array('class'=>'form leadContact right_leadContact phs recapt','style'=>'margin-top: 5px;' ),
							));
							?>
                            <style>
                            img.ag{max-width:110px!important;max-height:50px!important;margin-bottom:0;margin-left:auto;text-align:center;margin-right:auto;display:block}.ptn.man.kw-agent-info__agentItem___2iGT_.h7{font-weight:700;line-height:20px;display:flex}.ptn.man.kw-agent-info__agentItem___2iGT_.h7 span{margin-right:10px;font-weight:400;display:inline-block;max-width:90px;overflow:hidden;white-space:nowrap;min-width:90px;font-size:11px}
                            .ptn.man.kw-agent-info__agentItem___2iGT_.h7 { line-height:25px;}
                            </style>
                           
                              
													<div class="clearfix"></div>
													 <h2 class="margin-top-0">About Your Property</h2>
													<div class="clearfix"></div>
													<div class="form-group  ">
													<div class="row">
													<div class="col-sm-12">
													<?php  	
													$model->bank_id = $activeModel->primaryKey;
													echo $form->textField($model , 'address' ,  $model->getHtmlOptions('address',array('class'=>'input-text form-control LJB','autofocus' =>'1' )));  ?>
													<?php  	echo $form->hiddenField($model , 'location_longitude');  ?>
													<?php  	echo $form->hiddenField($model , 'location_latitude');  ?>
													<?php  	echo $form->hiddenField($model , 'bank_id');  ?>
													<?php echo $form->error($model, 'bank_id');?>
													<?php echo $form->error($model, 'address');?>
													</div>
													</div>
													</div> 

													<div class="clearfix"></div>
													<script>
													function setCheckox(id,k){
														$('#<?php echo $model->modelName;?>_'+id).val($(k).val());
													}
													</script>
													<div class="clearfix"></div>
													<div class="clearfix"></div>
														<div class="clearfix"></div>
													<?php $id = 'o_status'; ?> 
													<div class="form-group  " style="width:100%;">
													<div class="row">
													<div class="col-sm-12">
													<?php  	echo $form->labelEx($model , $id);  ?>
													<div>
												<div class="radio-toolbar property-typ1">
													<?php $property_type_Array = $model->o_status_array();
													foreach($property_type_Array as $k=>$v){ 
														$checked ='';if($k==$model->$id){ $checked = 'checked' ;}
														?> 
													<input type="radio" id="<?php echo $id;?>_<?php echo $k;?>" <?php echo $checked;?> onchange="setCheckox('<?php echo $id;?>',this)" name="<?php echo $id;?>" value="<?php echo $k;?>"  >
													<label for="<?php echo $id;?>_<?php echo $k;?>">
													<?php
													switch($k){
														case '1':
														echo '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" version="1.1" width="15" height="15" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve"><g> <g xmlns="http://www.w3.org/2000/svg"> <g> <path d="M172.55,391.902c-0.13-0.64-0.32-1.27-0.57-1.88c-0.25-0.6-0.56-1.18-0.92-1.72c-0.36-0.55-0.78-1.06-1.24-1.52 c-0.46-0.46-0.97-0.88-1.52-1.24c-0.54-0.36-1.12-0.67-1.73-0.92c-0.6-0.25-1.23-0.45-1.87-0.57c-1.29-0.26-2.62-0.26-3.9,0 c-0.64,0.12-1.27,0.32-1.88,0.57c-0.6,0.25-1.18,0.56-1.72,0.92c-0.55,0.36-1.06,0.78-1.52,1.24c-0.46,0.46-0.88,0.97-1.24,1.52 c-0.37,0.54-0.67,1.12-0.92,1.72c-0.25,0.61-0.45,1.24-0.57,1.88c-0.13,0.64-0.2,1.3-0.2,1.95c0,0.65,0.07,1.31,0.2,1.95 c0.12,0.64,0.32,1.27,0.57,1.87c0.25,0.61,0.55,1.19,0.92,1.73c0.36,0.55,0.78,1.06,1.24,1.52c0.46,0.46,0.97,0.88,1.52,1.24 c0.54,0.361,1.12,0.671,1.72,0.921c0.61,0.25,1.24,0.45,1.88,0.57c0.64,0.13,1.3,0.2,1.95,0.2c0.65,0,1.31-0.07,1.95-0.2 c0.64-0.12,1.27-0.32,1.87-0.57c0.61-0.25,1.19-0.561,1.73-0.921c0.55-0.36,1.06-0.78,1.52-1.24c0.46-0.46,0.88-0.97,1.24-1.52 c0.36-0.54,0.67-1.12,0.92-1.73c0.25-0.6,0.44-1.23,0.57-1.87s0.2-1.3,0.2-1.95S172.68,392.542,172.55,391.902z" fill="currentColor" data-original="#000000" style=""/> </g> </g> <g xmlns="http://www.w3.org/2000/svg"> <g> <path d="M459.993,394.982c-0.039-0.1-0.079-0.199-0.121-0.297c-9.204-21.537-30.79-29.497-56.336-20.772l-69.668,19.266 c-4.028-12.198-14.075-22.578-28.281-27.85c-0.088-0.032-0.176-0.064-0.265-0.094l-76.581-25.992 c-6.374-8.239-26.34-29.321-63.723-29.321c-26.125,0-49.236,17.922-62.458,37.457H10c-5.523,0-10,4.477-10,10v126.077 c0,5.523,4.477,10,10,10h59.457c5.523,0,10-4.477,10-10v-8.634h27.883c5.523,0,10-4.477,10-10v-2.878 c16.254,1.418,21.6,4.501,36.528,13.109c11.48,6.62,28.831,16.625,60.077,30.674c0.145,0.065,0.292,0.127,0.439,0.185 c5.997,2.359,17.72,6.065,32.173,6.065c10.06,0,21.445-1.797,33.131-7.094l153.991-55.136c0.274-0.098,0.544-0.208,0.808-0.33 C449.204,442.646,471.135,423.563,459.993,394.982z M59.457,473.455H20V367.378h39.457V473.455z M97.34,454.821H79.457v-87.443 H97.34V454.821z M426.496,431.074l-153.922,55.111c-0.135,0.048-0.318,0.12-0.451,0.174c-0.135,0.055-0.27,0.113-0.403,0.174 c-21.437,9.852-41.814,3.954-49.8,0.849c-30.182-13.581-46.291-22.87-58.061-29.657c-16.364-9.436-24.249-13.984-46.519-15.823 V361.36c9.479-15.536,27.861-31.439,47.679-31.439c33.986,0,48.387,22.105,48.953,22.997c1.221,1.986,3.098,3.483,5.305,4.232 l79.475,26.974c12.693,4.764,19.401,15.634,16.318,26.474c-1.423,5.006-4.711,9.158-9.257,11.691 c-4.507,2.511-9.717,3.132-14.683,1.758l-89.593-28.392c-5.268-1.669-10.886,1.247-12.554,6.512 c-1.669,5.265,1.247,10.885,6.512,12.554l89.749,28.441c0.095,0.03,0.19,0.059,0.286,0.086c3.583,1.019,7.231,1.523,10.857,1.523 c6.638,0,13.203-1.691,19.161-5.011c9.213-5.133,15.875-13.547,18.759-23.692c0.23-0.81,0.434-1.62,0.611-2.43l75.083-20.8 c10.844-3.704,25.079-5.039,31.417,9.558C447.978,419.533,430.928,428.96,426.496,431.074z" fill="currentColor" data-original="#000000" style=""/> </g> </g> <g xmlns="http://www.w3.org/2000/svg"> <g> <path d="M359.06,131.543c-0.13-0.64-0.32-1.27-0.58-1.88c-0.25-0.6-0.55-1.18-0.92-1.72c-0.36-0.55-0.78-1.06-1.24-1.52 c-0.46-0.46-0.97-0.88-1.52-1.24c-0.54-0.36-1.12-0.67-1.72-0.92c-0.61-0.25-1.24-0.45-1.87-0.57c-1.29-0.26-2.62-0.26-3.91,0 c-0.64,0.12-1.27,0.32-1.87,0.57c-0.61,0.25-1.19,0.56-1.73,0.92c-0.55,0.36-1.06,0.78-1.52,1.24c-0.46,0.46-0.88,0.97-1.24,1.52 c-0.36,0.54-0.67,1.12-0.92,1.72c-0.25,0.61-0.45,1.24-0.57,1.88c-0.13,0.64-0.2,1.3-0.2,1.95c0,0.65,0.07,1.31,0.2,1.95 c0.12,0.64,0.32,1.27,0.57,1.87c0.25,0.61,0.56,1.19,0.92,1.73c0.36,0.55,0.78,1.06,1.24,1.52c0.46,0.46,0.97,0.88,1.52,1.24 c0.54,0.36,1.12,0.67,1.73,0.92c0.6,0.25,1.23,0.44,1.87,0.57s1.3,0.2,1.95,0.2c0.65,0,1.31-0.07,1.96-0.2 c0.63-0.13,1.26-0.32,1.87-0.57c0.6-0.25,1.18-0.56,1.72-0.92c0.55-0.36,1.06-0.78,1.52-1.24c0.46-0.46,0.88-0.97,1.24-1.52 c0.37-0.54,0.67-1.12,0.92-1.73c0.26-0.6,0.45-1.23,0.58-1.87c0.13-0.64,0.19-1.3,0.19-1.95 C359.25,132.843,359.19,132.183,359.06,131.543z" fill="currentColor" data-original="#000000" style=""/> </g> </g> <g xmlns="http://www.w3.org/2000/svg"> <g> <path d="M502,33.891h-59.457c-5.523,0-10,4.477-10,10v8.634H404.66c-5.523,0-10,4.477-10,10v2.878 c-16.254-1.419-21.6-4.501-36.527-13.109c-11.48-6.62-28.831-16.625-60.078-30.674c-0.145-0.066-0.291-0.127-0.44-0.185 c-10.171-4.002-36.828-11.876-65.299,1.027l-40.24,14.408L158.157,2.952c-3.905-3.905-10.237-3.905-14.142,0L32.657,114.309 c-3.602,3.603-4.293,9.85,0,14.143l190.287,190.287c3.045,3.046,10.175,3.967,14.143,0l101.665-101.664 c2.643,0.228,5.386,0.351,8.229,0.351c26.126,0,49.236-17.922,62.457-37.456H502c5.523,0,10-4.477,10-10V43.891 C512,38.368,507.523,33.891,502,33.891z M151.085,24.165l22.792,22.792c-6.775,4.19-14.608,6.432-22.792,6.432 c-8.185,0-16.017-2.241-22.792-6.432L151.085,24.165z M76.663,144.173L53.871,121.38l22.792-22.792 c4.19,6.775,6.432,14.608,6.432,22.792C83.095,129.564,80.854,137.397,76.663,144.173z M230.016,297.525l-22.788-22.788 c13.913-8.586,31.661-8.586,45.575,0L230.016,297.525z M267.211,260.331c-22.098-16.03-52.292-16.03-74.39,0L91.07,158.579 c7.809-10.74,12.025-23.641,12.025-37.199c0-13.559-4.215-26.459-12.025-37.199l22.817-22.816 c10.74,7.809,23.64,12.025,37.199,12.025c13.559,0,26.459-4.216,37.199-12.025l21.629,21.629 c-4.667,0.689-9.218,2.227-13.462,4.592c-7.168,3.994-12.792,9.975-16.294,17.211c-11.28,2.089-21.723,7.55-29.915,15.741 c-22.225,22.226-22.225,58.389,0.001,80.615c11.112,11.112,25.709,16.669,40.307,16.669c14.597,0,29.195-5.556,40.308-16.669 c7.23-7.23,12.295-16.116,14.832-25.8l33.764,11.459c-3.801,17.608,0.092,36.132,10.593,50.682L267.211,260.331z M206.413,162.018 c0.088,0.032,0.176,0.064,0.265,0.094l19.996,6.787c-1.51,6.815-4.927,13.081-9.957,18.112c-14.428,14.426-37.904,14.428-52.33,0 c-14.428-14.427-14.428-37.902,0-52.33c3.48-3.482,7.587-6.203,12.062-8.048C178.295,141.995,189.356,155.688,206.413,162.018z M304.457,223.084c-3.86-6.29-6.044-13.469-6.389-20.796c4.79,3.463,10.644,6.856,17.636,9.549L304.457,223.084z M394.659,165.983 c-9.478,15.538-27.86,31.441-47.678,31.441c-3.708,0-7.183-0.264-10.432-0.734c-0.013-0.002-0.026-0.004-0.039-0.006 c-21.596-3.137-33.213-15.411-37.042-20.271c-0.204-0.3-1.073-1.437-1.202-1.626c-1.165-2.082-3.075-3.756-5.511-4.583 l-79.508-26.985c-12.688-4.762-19.395-15.627-16.321-26.463c0.002-0.007,0.004-0.014,0.006-0.021 c0.003-0.008,0.005-0.017,0.007-0.025c1.429-4.99,4.711-9.129,9.247-11.656c4.506-2.511,9.715-3.134,14.683-1.757l89.593,28.391 c5.266,1.671,10.886-1.247,12.554-6.512c1.668-5.265-1.247-10.885-6.512-12.554l-71.255-22.58l-0.622-0.622 c-0.006-0.006-0.012-0.013-0.019-0.019l-36.89-36.89l31.708-11.354c0.107-0.039,0.239-0.088,0.345-0.131 c0.027-0.011,0.079-0.031,0.105-0.042c0.136-0.055,0.27-0.113,0.403-0.174c21.436-9.852,41.812-3.955,49.799-0.849 c30.183,13.581,46.293,22.87,58.063,29.657c16.364,9.437,24.249,13.984,46.518,15.823V165.983z M432.543,159.968H414.66V72.525 h17.883V159.968z M492,159.968h-39.457V53.891H492V159.968z" fill="currentColor" data-original="#000000" style=""/> </g> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> </g></svg>';
														break;
														case '2':
														echo '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" version="1.1" width="15" height="15" x="0" y="0" viewBox="0 0 484 484.5522" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path xmlns="http://www.w3.org/2000/svg" d="m477.980469 348.800781-45.105469-16.417969c-4.15625-1.503906-8.742188.644532-10.246094 4.800782l-2.738281 7.511718-52.253906-19.054687c-1.3125-.492187-2.734375-.613281-4.113281-.359375l-108.71875 19.199219c-9.855469 1.753906-18.320313 8.011719-22.898438 16.910156l-49.871094-18.191406c-7.964844-2.929688-16.777344-2.539063-24.453125 1.082031-9.753906 4.550781-16.570312 13.683594-18.160156 24.328125-1.992187 15.40625 7.132813 30.089844 21.832031 35.125l164.277344 59.792969c.875.324218 1.804688.492187 2.738281.488281.871094 0 1.734375-.144531 2.558594-.421875l45.878906-15.488281 4.882813 1.773437-2.738282 7.519532c-1.503906 4.15625.644532 8.746093 4.800782 10.25l45.113281 16.414062c.871094.324219 1.796875.492188 2.726563.488281 3.363281.003907 6.371093-2.101562 7.519531-5.261719l43.777343-120.289062c1.472657-4.144531-.675781-8.699219-4.808593-10.199219zm-103.738281 83.269531-45.878907 15.488282-161.640625-58.839844c-7.476562-2.488281-12.246094-9.816406-11.488281-17.664062.675781-4.78125 3.472656-9 7.613281-11.488282 4.140625-2.484375 9.179688-2.964844 13.714844-1.308594l51.90625 18.886719c.027344 1.476563.144531 2.949219.359375 4.40625 3.136719 17.351563 19.667969 28.9375 37.046875 25.960938l90.066406-15.878907-2.785156-15.761718-90.023438 15.882812c-8.667968 1.472656-16.917968-4.277344-18.535156-12.921875-.332031-1.824219-.320312-3.699219.039063-5.519531.058593-.265625.105469-.53125.136719-.800781.105468-.683594.289062-1.351563.550781-1.992188 1.964843-5.371093 6.636719-9.289062 12.265625-10.296875l106.589844-18.796875 50.242187 18.277344-27.363281 75.199219-7.519532-2.726563c-1.703124-.632812-3.570312-.671875-5.296874-.105469zm52.433593 34.25-30.070312-10.945312 38.300781-105.246094 30.074219 10.941406zm0 0" fill="currentColor" data-original="#000000" style="" class=""/><path xmlns="http://www.w3.org/2000/svg" d="m186.621094 129.046875c2.582031 9.453125 7.34375 18.171875 13.902344 25.449219-.121094.640625-.207032 1.285156-.246094 1.9375v43.566406c0 13.253906 10.742187 24 24 24v80c-.019532 3.046875 1.699218 5.839844 4.421875 7.199219l16 8c2.253906 1.125 4.902343 1.125 7.152343 0l16-8c2.726563-1.359375 4.441407-4.152344 4.425782-7.199219v-80c13.253906 0 24-10.746094 24-24v-43.566406c-.042969-.699219-.132813-1.394532-.265625-2.082032 5.34375-5.878906 9.507812-12.730468 12.265625-20.183593 11.8125 1.984375 23.636718-3.441407 29.839844-13.6875 7.605468-12.582031 5.523437-28.75-5.023438-38.992188l-65.105469-65.089843c-10.476562-10.53125-24.734375-16.4375005-39.59375-16.398438h-84.117187c-1.085938-.00390625-2.15625.21875-3.152344.648438l-54.449219 23.351562h-6.398437v-16c0-4.417969-3.582032-8-8-8h-64c-4.417969 0-8 3.582031-8 8v128c0 4.417969 3.582031 8 8 8h64c4.417968 0 8-3.582031 8-8v-16h1.167968c5.726563 19.199219 31.453126 32 54.832032 32 19.394531.398438 37.921875-8.046875 50.34375-22.953125zm-122.34375-1.046875h-48v-112h48zm192 171.054688-8 4-8-4v-75.054688h16zm24-99.054688c0 4.417969-3.582032 8-8 8h-48c-4.417969 0-8-3.582031-8-8v-32.65625c5.378906 3.132812 11.195312 5.453125 17.253906 6.878906 2.765625 6.730469 9.699219 10.769532 16.914062 9.855469 7.21875-.910156 12.929688-6.546875 13.933594-13.753906 1.003906-7.203125-2.949218-14.1875-9.640625-17.039063-6.695312-2.847656-14.46875-.859375-18.964843 4.859375-4.511719-1.183593-8.828126-3.023437-12.800782-5.464843 7.710938-4.675782 16.34375-7.636719 25.304688-8.679688 11.484375 1.613281 22.4375 5.871094 32 12.433594zm5.957031-58.617188c-11.4375-7.355468-24.433594-11.9375-37.957031-13.382812-13.5 1.4375-26.476563 6.011719-37.898438 13.351562-4.878906-6.210937-8.109375-13.554687-9.390625-21.351562h39.289063c11.71875.117188 22.515625-6.34375 27.949218-16.726562l22.402344 22.398437c.894532.835937 1.839844 1.613281 2.832032 2.328125-1.648438 4.832031-4.089844 9.355469-7.226563 13.382812zm-14.335937-57.070312c-.746094-6.546875-3.519532-12.699219-7.925782-17.601562 18.09375 6.285156 30.722656 22.722656 32.128906 41.824218zm-95.621094 27.6875c0 12.113281-19.816406 24-40 24s-40-11.886719-40-24c0-4.417969-3.582032-8-8-8h-8v-64h8c1.082031.003906 2.15625-.21875 3.152344-.648438l54.445312-23.351562h82.480469c10.625-.039062 20.828125 4.179688 28.320312 11.710938l65.089844 65.089843c5.261719 4.914063 6.445313 12.804688 2.855469 19.046875-2.671875 4.230469-7.34375 6.769532-12.34375 6.710938-.128906 0-.25 0-.378906 0 .242187-2.175782.367187-4.367188.378906-6.558594-.039063-35.328125-28.671875-63.960938-64-64-10.75.015625-21.320313 2.769531-30.714844 8h-65.285156v16h88c8.835937 0 16 7.164062 16 16s-7.164063 16-16 16h-56c-4.417969 0-8 3.582031-8 8zm0 0" fill="currentColor" data-original="#000000" style="" class=""/></g></svg>';
														 break;
														 case '3':
														 echo '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" version="1.1" width="15" height="15" x="0" y="0" viewBox="0 0 512 512.001" style="enable-background:new 0 0 512 512" xml:space="preserve"><g><path xmlns="http://www.w3.org/2000/svg" d="m50 451.992188c-5.523438 0-10 4.476562-10 10v.007812c0 5.519531 4.476562 9.996094 10 9.996094s10-4.480469 10-10.003906c0-5.523438-4.476562-10-10-10zm0 0" fill="currentColor" data-original="#000000" style=""/><path xmlns="http://www.w3.org/2000/svg" d="m502 0h-80c-5.523438 0-10 4.476562-10 10v10.4375l-13.34375-.082031c-.019531 0-.042969 0-.0625 0-5.492188 0-9.964844 4.433593-10 9.933593-.035156 5.523438 4.414062 10.03125 9.9375 10.066407l13.46875.082031v103.75c-26.183594 16.492188-49.816406 6.996094-74.761719-3.050781-16.4375-6.621094-33.441406-13.464844-50.40625-11.335938-5.351562.671875-19.796875 2.769531-35.085937 4.988281-14.488282 2.101563-29.472656 4.277344-34.625 4.925782-2.621094.328125-5.234375-.402344-7.359375-2.054688-2.167969-1.691406-3.550781-4.117187-3.886719-6.835937-.21875-1.769531-.800781-6.476563 11.730469-12.292969 26.527343-12.300781 54.796875-22.832031 77.5625-28.890625 5.335937-1.421875 8.511719-6.898437 7.089843-12.238281-1.417968-5.335938-6.894531-8.507813-12.234374-7.089844-23.835938 6.34375-53.300782 17.308594-80.832032 30.078125-9.578125 4.441406-15.464844 9.609375-18.933594 14.820313l-100.257812 27.339843c-10.546875 2.652344-15.957031-1.546875-17.507812-6.363281-1.523438-4.742188.316406-10.855469 7.859374-13.832031 7.847657-2.988281 26.578126-11.234375 50.28125-21.664063 31.414063-13.824218 70.503907-31.03125 101.675782-43.675781 37.042968-15.027344 48.332031-17.292969 86.257812-17.15625h.03125c5.507813 0 9.980469-4.457031 10-9.96875.015625-5.523437-4.449218-10.015625-9.972656-10.03125-40.453125-.136719-54.488281 2.664063-93.832031 18.625-31.445313 12.753906-70.683594 30.023437-102.214844 43.898437-22.566406 9.933594-42.058594 18.511719-49.394531 21.300782-.03125.011718-.0625.023437-.09375.035156-18.683594 7.328125-24.019532 24.960938-19.636719 38.589844 4.316406 13.429687 19.160156 25.292968 41.546875 19.609375.058594-.015625.113281-.027344.171875-.046875l91.527344-24.957032c1.625 6.539063 5.367187 12.316407 10.777343 16.527344 6.347657 4.941406 14.210938 7.113282 22.136719 6.117188 5.34375-.671875 19.75-2.765625 35.003907-4.976563 14.527343-2.109375 29.542968-4.289062 34.707031-4.9375 11.816406-1.484375 25.722656 4.113281 40.441406 10.042969 15.597656 6.28125 33.367187 13.441406 52.597656 13.4375 9.546875 0 19.457031-1.78125 29.636719-6.296875v3.171875c0 5.523438 4.476562 10 10 10h80c5.523438 0 10-4.476562 10-10v-160c0-5.523438-4.476562-10-10-10zm-10 160h-60v-129.425781-.007813s0-.007812 0-.011718v-10.554688h60zm0 0" fill="currentColor" data-original="#000000" style=""/><path xmlns="http://www.w3.org/2000/svg" d="m462 60.007812c5.523438 0 10-4.476562 10-10v-.007812c0-5.519531-4.476562-9.996094-10-9.996094s-10 4.480469-10 10.003906c0 5.523438 4.476562 10 10 10zm0 0" fill="currentColor" data-original="#000000" style=""/><path xmlns="http://www.w3.org/2000/svg" d="m186 326c23.730469 0 44.730469-11.882812 57.394531-30h36.945313c2.652344 0 5.195312-1.054688 7.070312-2.929688l17.070313-17.070312h11.71875l17.070312 17.070312c1.875 1.875 4.417969 2.929688 7.070313 2.929688h15.660156c2.652344 0 5.195312-1.054688 7.070312-2.929688l30-30c1.875-1.875 2.929688-4.417968 2.929688-7.070312v-30c0-5.519531-4.476562-10-10-10h-142.601562c-12.667969-18.117188-33.664063-30-57.398438-30-38.597656 0-70 31.402344-70 70s31.402344 70 70 70zm190-90v15.859375l-24.140625 24.140625h-7.375l-17.074219-17.070312c-1.875-1.875-4.417968-2.929688-7.070312-2.929688h-20c-2.652344 0-5.195313 1.054688-7.070313 2.929688l-17.070312 17.070312h-23.125c1.894531-6.339844 2.925781-13.050781 2.925781-20s-1.03125-13.660156-2.925781-20zm-190-30c27.570312 0 50 22.429688 50 50s-22.429688 50-50 50-50-22.429688-50-50 22.429688-50 50-50zm0 0" fill="currentColor" data-original="#000000" style=""/><path xmlns="http://www.w3.org/2000/svg" d="m166 266c5.523438 0 10-4.480469 10-10.003906 0-5.523438-4.476562-10-10-10s-10 4.476562-10 10v.007812c0 5.523438 4.476562 9.996094 10 9.996094zm0 0" fill="currentColor" data-original="#000000" style=""/><path xmlns="http://www.w3.org/2000/svg" d="m358.59375 40.105469h.003906c5.523438 0 9.996094-4.480469 9.996094-10 0-5.523438-4.480469-10-10-10-5.523438 0-10 4.476562-10 10 0 5.519531 4.476562 10 10 10zm0 0" fill="currentColor" data-original="#000000" style=""/><path xmlns="http://www.w3.org/2000/svg" d="m417 350.082031c-.058594.015625-.113281.027344-.171875.046875l-91.527344 24.957032c-1.625-6.539063-5.367187-12.316407-10.777343-16.527344-6.347657-4.941406-14.210938-7.113282-22.136719-6.117188-5.34375.671875-19.75 2.765625-35.003907 4.976563-14.527343 2.109375-29.542968 4.289062-34.707031 4.9375-11.8125 1.480469-25.722656-4.113281-40.441406-10.042969-23.34375-9.398438-51.558594-20.757812-82.234375-7.152344v-3.15625c0-5.523437-4.476562-10-10-10h-80c-5.523438 0-10 4.476563-10 10v159.996094c0 5.523438 4.476562 10 10 10h80c5.523438 0 10-4.476562 10-10v-10.4375l13.34375.082031h.0625c5.492188 0 9.964844-4.433593 10-9.9375.035156-5.519531-4.414062-10.027343-9.9375-10.0625l-13.46875-.082031v-103.75c26.183594-16.492188 49.816406-6.996094 74.761719 3.046875 16.441406 6.625 33.449219 13.46875 50.40625 11.335937 5.355469-.671874 19.796875-2.765624 35.085937-4.984374 14.488282-2.105469 29.472656-4.277344 34.625-4.925782 2.621094-.328125 5.234375.398438 7.359375 2.054688 2.171875 1.691406 3.550781 4.117187 3.886719 6.835937.21875 1.769531.804688 6.476563-11.730469 12.289063-26.527343 12.304687-54.792969 22.835937-77.558593 28.894531-5.335938 1.421875-8.511719 6.898437-7.09375 12.234375 1.421874 5.339844 6.902343 8.507812 12.234374 7.09375 23.835938-6.34375 53.300782-17.308594 80.835938-30.078125 9.574219-4.441406 15.460938-9.609375 18.933594-14.820313l100.253906-27.339843c10.542969-2.65625 15.957031 1.546875 17.507812 6.363281 1.523438 4.742188-.316406 10.855469-7.855468 13.832031-7.84375 2.988281-26.582032 11.234375-50.289063 21.667969-31.410156 13.824219-70.5 31.027344-101.671875 43.671875-37.042968 15.027344-48.355468 17.300781-86.257812 17.15625-.007813 0-.019532 0-.03125 0-5.507813 0-9.980469 4.457031-10 9.96875-.015625 5.523437 4.449218 10.015625 9.972656 10.03125.816406.003906 1.621094.003906 2.417969.003906 38.617187 0 52.867187-2.988281 91.414062-18.628906 31.441407-12.753906 70.683594-30.023437 102.210938-43.898437 22.570312-9.933594 42.0625-18.511719 49.394531-21.300782.03125-.011718.0625-.023437.097656-.035156 18.683594-7.328125 24.019532-24.960938 19.636719-38.589844-4.316406-13.425781-19.160156-25.289062-41.546875-19.609375zm-397 141.917969v-140h60v129.4375.011719 10.550781zm0 0" fill="currentColor" data-original="#000000" style=""/><path xmlns="http://www.w3.org/2000/svg" d="m153.410156 471.894531h-.007812c-5.523438 0-9.996094 4.480469-9.996094 10 0 5.523438 4.480469 10 10.003906 10 5.523438 0 10-4.476562 10-10 0-5.519531-4.476562-10-10-10zm0 0" fill="currentColor" data-original="#000000" style=""/></g></svg>';
														  break;
													}
													?>
													
													<?php echo $v;?></label>
													<?php } ?>  
													</div>

													</div>
													<?php echo $form->hiddenField($model,$id);?><div class="clearfix"></div>
													<?php echo $form->error($model, $id);?>
													</div>
													</div>
													</div> 

													<div class="clearfix"></div>
													<div class="clearfix"></div>
													<?php $id = 'property_type'; ?> 
													<div class="form-group  " style="width:100%;">
													<div class="row">
													<div class="col-sm-12">
													<?php  	echo $form->labelEx($model , $id);  ?>
													<div>
												<div class="radio-toolbar property-typ1">
													<?php $property_type_Array = $model->property_type_Array();
													foreach($property_type_Array as $k=>$v){ 
														$checked ='';if($k==$model->$id){ $checked = 'checked' ;}
														?> 
													<input type="radio" id="<?php echo $id;?>_<?php echo $k;?>" <?php echo $checked;?> onchange="setCheckox('<?php echo $id;?>',this)" name="<?php echo $id;?>" value="<?php echo $k;?>"  >
													<label for="<?php echo $id;?>_<?php echo $k;?>">
													<?php
													switch($k){
														case '1':
														echo '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" version="1.1" width="512" height="512" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve"><g> <g xmlns="http://www.w3.org/2000/svg" transform="translate(1 1)"> <g> <g> <path d="M502.467,493.933h-34.661c0.364-2.804,0.528-5.667,0.528-8.533c0-24.086-13.861-44.588-34.133-54.082V144.067 c0-5.12-3.413-8.533-8.533-8.533h-128v-128c0-5.12-3.413-8.533-8.533-8.533h-230.4C53.613-1,50.2,2.413,50.2,7.533v486.4H7.533 c-5.12,0-8.533,3.413-8.533,8.533S2.413,511,7.533,511h51.2h25.6h204.8H457.24h45.227c5.12,0,8.533-3.413,8.533-8.533 S507.587,493.933,502.467,493.933z M417.133,426.269c-2.785-0.389-5.631-0.603-8.533-0.603c-6.442,0-12.761,1.097-18.731,3.148 c-1.487-1.982-3.884-3.148-6.869-3.148c-5.12,0-8.533,3.413-8.533,8.533v2.615c-3.234,2.33-6.241,4.988-8.97,7.943 c-0.431,0.456-0.855,0.918-1.27,1.388c-7.071-8.839-16.179-15.233-26.477-18.346c-1.479-1.357-3.518-2.134-5.95-2.134 c-0.951,0-1.843,0.119-2.666,0.344c-1.927-0.225-3.884-0.344-5.867-0.344c-5.348,0-11.37,0.694-16.249,2.675 c-0.604,0.204-1.204,0.414-1.798,0.639c-5.897-4.794-12.794-8.245-20.062-10.144c-0.077-0.021-0.156-0.036-0.232-0.057 c-0.634-0.163-1.27-0.318-1.909-0.457c-0.518-0.114-1.042-0.213-1.565-0.311c-0.227-0.042-0.454-0.087-0.682-0.126 c-0.549-0.095-1.1-0.179-1.655-0.256c-0.248-0.035-0.496-0.066-0.745-0.097c-0.509-0.063-1.02-0.122-1.534-0.169 c-0.375-0.035-0.751-0.061-1.127-0.088c-0.402-0.028-0.803-0.061-1.208-0.08c-0.811-0.039-1.622-0.063-2.434-0.063 c-0.628,0-1.251,0.013-1.871,0.036c-0.406,0.014-0.811,0.039-1.216,0.062c-0.162,0.01-0.326,0.017-0.488,0.028 c-7.774,0.516-15.412,2.71-22.026,6.596V152.6h42.667h128V426.269z M67.267,16.067H280.6v119.467h-42.667 c-5.12,0-8.533,3.413-8.533,8.533v265.387c-4.361-4.361-9.388-8.05-14.861-10.937c-0.483-0.258-0.971-0.508-1.461-0.752 c-0.193-0.095-0.384-0.194-0.578-0.287c-6.09-2.954-12.717-4.892-19.642-5.617c-0.097-0.01-0.195-0.018-0.293-0.028 c-0.804-0.08-1.612-0.143-2.424-0.19c-0.215-0.013-0.43-0.026-0.646-0.037c-0.917-0.043-1.837-0.072-2.762-0.072 c-12.7,0-24.466,4.177-34.133,11.197v-2.663c0-5.12-3.413-8.533-8.533-8.533c-5.12,0-8.533,3.413-8.533,8.533v17.067 c0,1.28,0.213,2.453,0.613,3.493c-4.19,6.905-7.077,14.689-8.293,22.961c-9.824,1.123-18.807,4.658-26.453,9.943v-2.263 c0-5.12-3.413-8.533-8.533-8.533c-5.12,0-8.533,3.413-8.533,8.533v17.067c0,0.996,0.133,1.925,0.379,2.779 c-4.231,6.843-7.11,14.586-8.296,22.82h-9.149V16.067z M131.65,459.977c0.169-0.015,0.34-0.025,0.51-0.038 c0.45-0.035,0.9-0.069,1.354-0.09c0.669-0.03,1.342-0.05,2.02-0.05c5.12,0,8.533-3.413,8.533-8.533 c0-23.893,18.773-42.667,42.667-42.667c21.333,0,39.253,15.36,41.813,36.693c0.577,2.308,1.947,4.21,3.821,5.474 c0.118,0.083,0.239,0.161,0.362,0.238c0.132,0.081,0.263,0.163,0.4,0.237c0.315,0.174,0.643,0.333,0.985,0.47 c0.013,0.005,0.025,0.01,0.038,0.016c0.391,0.156,0.799,0.287,1.22,0.392c0.001,0,0.001,0,0.002,0.001 c0.508,0.169,1.085,0.234,1.695,0.215c2.805,0.041,5.414-1.493,6.837-3.626c0-0.001,0.001-0.001,0.002-0.002c0,0,0,0,0,0 l0.853-0.853c6.827-8.533,16.213-13.653,27.307-13.653c5.762,0,11.521,1.614,16.69,4.632 c-10.179,9.571-15.951,22.048-16.622,35.398c-0.045,0.873-0.068,1.753-0.068,2.637c0,5.934,0.987,11.621,2.94,17.067H93.72 C97.714,475.562,112.924,461.678,131.65,459.977z M295.154,493.933c-3.26-5.514-5.167-12.033-5.167-17.92 c0-9.436,3.72-17.937,10.114-24.151c1.222-1.133,2.525-2.179,3.901-3.126c1.333,0.01,2.674-0.268,3.905-0.883 c18.773-10.24,40.96-0.853,47.787,17.92c0.853,2.56,3.413,5.12,7.68,5.12c0.81,0,1.706-0.258,2.606-0.716 c2.141-0.351,3.834-1.923,5.074-4.404c3.307-7.027,8.427-12.637,14.659-16.57c1.345-0.375,2.5-1.039,3.419-1.94 c5.861-2.946,12.505-4.53,19.469-4.53c23.893,0,42.667,18.773,42.667,42.667c0,2.56,0,5.973-0.853,8.533H295.154z" fill="currentColor" data-original="#000000" style=""/> <path d="M280.6,220.867c-5.12,0-8.533,3.413-8.533,8.533v17.067c0,5.12,3.413,8.533,8.533,8.533s8.533-3.413,8.533-8.533V229.4 C289.133,224.28,285.72,220.867,280.6,220.867z" fill="currentColor" data-original="#000000" style=""/> <path d="M280.6,374.467c-5.12,0-8.533,3.413-8.533,8.533v17.067c0,5.12,3.413,8.533,8.533,8.533s8.533-3.413,8.533-8.533V383 C289.133,377.88,285.72,374.467,280.6,374.467z" fill="currentColor" data-original="#000000" style=""/> <path d="M280.6,272.067c-5.12,0-8.533,3.413-8.533,8.533v17.067c0,5.12,3.413,8.533,8.533,8.533s8.533-3.413,8.533-8.533V280.6 C289.133,275.48,285.72,272.067,280.6,272.067z" fill="currentColor" data-original="#000000" style=""/> <path d="M280.6,323.267c-5.12,0-8.533,3.413-8.533,8.533v17.067c0,5.12,3.413,8.533,8.533,8.533s8.533-3.413,8.533-8.533V331.8 C289.133,326.68,285.72,323.267,280.6,323.267z" fill="currentColor" data-original="#000000" style=""/> <path d="M280.6,169.667c-5.12,0-8.533,3.413-8.533,8.533v17.067c0,5.12,3.413,8.533,8.533,8.533s8.533-3.413,8.533-8.533V178.2 C289.133,173.08,285.72,169.667,280.6,169.667z" fill="currentColor" data-original="#000000" style=""/> <path d="M331.8,255c5.12,0,8.533-3.413,8.533-8.533V229.4c0-5.12-3.413-8.533-8.533-8.533c-5.12,0-8.533,3.413-8.533,8.533 v17.067C323.267,251.587,326.68,255,331.8,255z" fill="currentColor" data-original="#000000" style=""/> <path d="M331.8,203.8c5.12,0,8.533-3.413,8.533-8.533V178.2c0-5.12-3.413-8.533-8.533-8.533c-5.12,0-8.533,3.413-8.533,8.533 v17.067C323.267,200.387,326.68,203.8,331.8,203.8z" fill="currentColor" data-original="#000000" style=""/> <path d="M331.8,306.2c5.12,0,8.533-3.413,8.533-8.533V280.6c0-5.12-3.413-8.533-8.533-8.533c-5.12,0-8.533,3.413-8.533,8.533 v17.067C323.267,302.787,326.68,306.2,331.8,306.2z" fill="currentColor" data-original="#000000" style=""/> <path d="M331.8,357.4c5.12,0,8.533-3.413,8.533-8.533V331.8c0-5.12-3.413-8.533-8.533-8.533c-5.12,0-8.533,3.413-8.533,8.533 v17.067C323.267,353.987,326.68,357.4,331.8,357.4z" fill="currentColor" data-original="#000000" style=""/> <path d="M331.8,408.6c5.12,0,8.533-3.413,8.533-8.533V383c0-5.12-3.413-8.533-8.533-8.533c-5.12,0-8.533,3.413-8.533,8.533 v17.067C323.267,405.187,326.68,408.6,331.8,408.6z" fill="currentColor" data-original="#000000" style=""/> <path d="M383,306.2c5.12,0,8.533-3.413,8.533-8.533V280.6c0-5.12-3.413-8.533-8.533-8.533s-8.533,3.413-8.533,8.533v17.067 C374.467,302.787,377.88,306.2,383,306.2z" fill="currentColor" data-original="#000000" style=""/> <path d="M383,255c5.12,0,8.533-3.413,8.533-8.533V229.4c0-5.12-3.413-8.533-8.533-8.533s-8.533,3.413-8.533,8.533v17.067 C374.467,251.587,377.88,255,383,255z" fill="currentColor" data-original="#000000" style=""/> <path d="M383,408.6c5.12,0,8.533-3.413,8.533-8.533V383c0-5.12-3.413-8.533-8.533-8.533s-8.533,3.413-8.533,8.533v17.067 C374.467,405.187,377.88,408.6,383,408.6z" fill="currentColor" data-original="#000000" style=""/> <path d="M383,357.4c5.12,0,8.533-3.413,8.533-8.533V331.8c0-5.12-3.413-8.533-8.533-8.533s-8.533,3.413-8.533,8.533v17.067 C374.467,353.987,377.88,357.4,383,357.4z" fill="currentColor" data-original="#000000" style=""/> <path d="M383,203.8c5.12,0,8.533-3.413,8.533-8.533V178.2c0-5.12-3.413-8.533-8.533-8.533s-8.533,3.413-8.533,8.533v17.067 C374.467,200.387,377.88,203.8,383,203.8z" fill="currentColor" data-original="#000000" style=""/> <path d="M92.867,323.267c5.12,0,8.533-3.413,8.533-8.533v-17.067c0-5.12-3.413-8.533-8.533-8.533 c-5.12,0-8.533,3.413-8.533,8.533v17.067C84.333,319.853,87.747,323.267,92.867,323.267z" fill="currentColor" data-original="#000000" style=""/> <path d="M92.867,374.467c5.12,0,8.533-3.413,8.533-8.533v-17.067c0-5.12-3.413-8.533-8.533-8.533 c-5.12,0-8.533,3.413-8.533,8.533v17.067C84.333,371.053,87.747,374.467,92.867,374.467z" fill="currentColor" data-original="#000000" style=""/> <path d="M92.867,425.667c5.12,0,8.533-3.413,8.533-8.533v-17.067c0-5.12-3.413-8.533-8.533-8.533 c-5.12,0-8.533,3.413-8.533,8.533v17.067C84.333,422.253,87.747,425.667,92.867,425.667z" fill="currentColor" data-original="#000000" style=""/> <path d="M92.867,67.267c5.12,0,8.533-3.413,8.533-8.533V41.667c0-5.12-3.413-8.533-8.533-8.533c-5.12,0-8.533,3.413-8.533,8.533 v17.067C84.333,63.853,87.747,67.267,92.867,67.267z" fill="currentColor" data-original="#000000" style=""/> <path d="M92.867,118.467c5.12,0,8.533-3.413,8.533-8.533V92.867c0-5.12-3.413-8.533-8.533-8.533c-5.12,0-8.533,3.413-8.533,8.533 v17.067C84.333,115.053,87.747,118.467,92.867,118.467z" fill="currentColor" data-original="#000000" style=""/> <path d="M92.867,169.667c5.12,0,8.533-3.413,8.533-8.533v-17.067c0-5.12-3.413-8.533-8.533-8.533 c-5.12,0-8.533,3.413-8.533,8.533v17.067C84.333,166.253,87.747,169.667,92.867,169.667z" fill="currentColor" data-original="#000000" style=""/> <path d="M92.867,220.867c5.12,0,8.533-3.413,8.533-8.533v-17.067c0-5.12-3.413-8.533-8.533-8.533 c-5.12,0-8.533,3.413-8.533,8.533v17.067C84.333,217.453,87.747,220.867,92.867,220.867z" fill="currentColor" data-original="#000000" style=""/> <path d="M92.867,272.067c5.12,0,8.533-3.413,8.533-8.533v-17.067c0-5.12-3.413-8.533-8.533-8.533 c-5.12,0-8.533,3.413-8.533,8.533v17.067C84.333,268.653,87.747,272.067,92.867,272.067z" fill="currentColor" data-original="#000000" style=""/> <path d="M144.067,118.467c5.12,0,8.533-3.413,8.533-8.533V92.867c0-5.12-3.413-8.533-8.533-8.533 c-5.12,0-8.533,3.413-8.533,8.533v17.067C135.533,115.053,138.947,118.467,144.067,118.467z" fill="currentColor" data-original="#000000" style=""/> <path d="M144.067,67.267c5.12,0,8.533-3.413,8.533-8.533V41.667c0-5.12-3.413-8.533-8.533-8.533c-5.12,0-8.533,3.413-8.533,8.533 v17.067C135.533,63.853,138.947,67.267,144.067,67.267z" fill="currentColor" data-original="#000000" style=""/> <path d="M144.067,220.867c5.12,0,8.533-3.413,8.533-8.533v-17.067c0-5.12-3.413-8.533-8.533-8.533 c-5.12,0-8.533,3.413-8.533,8.533v17.067C135.533,217.453,138.947,220.867,144.067,220.867z" fill="currentColor" data-original="#000000" style=""/> <path d="M144.067,169.667c5.12,0,8.533-3.413,8.533-8.533v-17.067c0-5.12-3.413-8.533-8.533-8.533 c-5.12,0-8.533,3.413-8.533,8.533v17.067C135.533,166.253,138.947,169.667,144.067,169.667z" fill="currentColor" data-original="#000000" style=""/> <path d="M144.067,272.067c5.12,0,8.533-3.413,8.533-8.533v-17.067c0-5.12-3.413-8.533-8.533-8.533 c-5.12,0-8.533,3.413-8.533,8.533v17.067C135.533,268.653,138.947,272.067,144.067,272.067z" fill="currentColor" data-original="#000000" style=""/> <path d="M144.067,323.267c5.12,0,8.533-3.413,8.533-8.533v-17.067c0-5.12-3.413-8.533-8.533-8.533 c-5.12,0-8.533,3.413-8.533,8.533v17.067C135.533,319.853,138.947,323.267,144.067,323.267z" fill="currentColor" data-original="#000000" style=""/> <path d="M144.067,374.467c5.12,0,8.533-3.413,8.533-8.533v-17.067c0-5.12-3.413-8.533-8.533-8.533 c-5.12,0-8.533,3.413-8.533,8.533v17.067C135.533,371.053,138.947,374.467,144.067,374.467z" fill="currentColor" data-original="#000000" style=""/> <path d="M195.267,169.667c5.12,0,8.533-3.413,8.533-8.533v-17.067c0-5.12-3.413-8.533-8.533-8.533s-8.533,3.413-8.533,8.533 v17.067C186.733,166.253,190.147,169.667,195.267,169.667z" fill="currentColor" data-original="#000000" style=""/> <path d="M195.267,118.467c5.12,0,8.533-3.413,8.533-8.533V92.867c0-5.12-3.413-8.533-8.533-8.533s-8.533,3.413-8.533,8.533 v17.067C186.733,115.053,190.147,118.467,195.267,118.467z" fill="currentColor" data-original="#000000" style=""/> <path d="M195.267,67.267c5.12,0,8.533-3.413,8.533-8.533V41.667c0-5.12-3.413-8.533-8.533-8.533s-8.533,3.413-8.533,8.533v17.067 C186.733,63.853,190.147,67.267,195.267,67.267z" fill="currentColor" data-original="#000000" style=""/> <path d="M195.267,374.467c5.12,0,8.533-3.413,8.533-8.533v-17.067c0-5.12-3.413-8.533-8.533-8.533s-8.533,3.413-8.533,8.533 v17.067C186.733,371.053,190.147,374.467,195.267,374.467z" fill="currentColor" data-original="#000000" style=""/> <path d="M195.267,323.267c5.12,0,8.533-3.413,8.533-8.533v-17.067c0-5.12-3.413-8.533-8.533-8.533s-8.533,3.413-8.533,8.533 v17.067C186.733,319.853,190.147,323.267,195.267,323.267z" fill="currentColor" data-original="#000000" style=""/> <path d="M195.267,272.067c5.12,0,8.533-3.413,8.533-8.533v-17.067c0-5.12-3.413-8.533-8.533-8.533s-8.533,3.413-8.533,8.533 v17.067C186.733,268.653,190.147,272.067,195.267,272.067z" fill="currentColor" data-original="#000000" style=""/> <path d="M195.267,220.867c5.12,0,8.533-3.413,8.533-8.533v-17.067c0-5.12-3.413-8.533-8.533-8.533s-8.533,3.413-8.533,8.533 v17.067C186.733,217.453,190.147,220.867,195.267,220.867z" fill="currentColor" data-original="#000000" style=""/> <path d="M246.467,118.467c5.12,0,8.533-3.413,8.533-8.533V92.867c0-5.12-3.413-8.533-8.533-8.533s-8.533,3.413-8.533,8.533 v17.067C237.933,115.053,241.347,118.467,246.467,118.467z" fill="currentColor" data-original="#000000" style=""/> <path d="M246.467,67.267c5.12,0,8.533-3.413,8.533-8.533V41.667c0-5.12-3.413-8.533-8.533-8.533s-8.533,3.413-8.533,8.533v17.067 C237.933,63.853,241.347,67.267,246.467,67.267z" fill="currentColor" data-original="#000000" style=""/> </g> </g> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> </g></svg>';
														break;
														case '2':
														echo '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" version="1.1" width="512" height="512" x="0" y="0" viewBox="0 0 456 456" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path xmlns="http://www.w3.org/2000/svg" d="m321 256.261719-89.132812-88.808594-96.867188 96.546875v189.582031h58v-64.175781c0-19.328125 15.671875-35 35-35s35 15.671875 35 35v64.175781h58zm-93 32.96875c-17.121094 0-31-13.878907-31-31 0-17.121094 13.878906-31 31-31s31 13.878906 31 31c-.019531 17.113281-13.886719 30.980469-31 31zm0 0" fill="currentColor" data-original="#000000" style="" class=""/><path xmlns="http://www.w3.org/2000/svg" d="m249 389.40625c0-11.597656-9.402344-21-21-21s-21 9.402344-21 21v64.175781h42zm0 0" fill="currentColor" data-original="#000000" style="" class=""/><path xmlns="http://www.w3.org/2000/svg" d="m121 323.582031h-121v130h121zm-71 112h-29v-14h29zm0-36h-29v-14h29zm0-36h-29v-14h29zm50 72h-29v-14h29zm0-36h-29v-14h29zm0-36h-29v-14h29zm0 0" fill="currentColor" data-original="#000000" style="" class=""/><path xmlns="http://www.w3.org/2000/svg" d="m225.644531 18.1875c2.730469-2.734375 7.164063-2.734375 9.898438 0l76.492187 76.496094 6.667969-6.570313-88.109375-88.113281-93.300781 93.300781 6.667969 6.570313zm0 0" fill="currentColor" data-original="#000000" style="" class=""/><path xmlns="http://www.w3.org/2000/svg" d="m245 258.230469c0 9.390625-7.609375 17-17 17s-17-7.609375-17-17c0-9.386719 7.609375-17 17-17s17 7.613281 17 17zm0 0" fill="currentColor" data-original="#000000" style="" class=""/><path xmlns="http://www.w3.org/2000/svg" d="m226.917969 152.605469c2.734375-2.734375 7.167969-2.734375 9.898437 0l116.511719 116.511719 11.765625-11.761719-133.226562-133.222657-140.960938 140.960938 11.765625 11.761719zm0 0" fill="currentColor" data-original="#000000" style="" class=""/><path xmlns="http://www.w3.org/2000/svg" d="m335 453.582031h121v-130h-121zm71-104h29v14h-29zm0 36h29v14h-29zm0 36h29v14h-29zm-50-72h29v14h-29zm0 36h29v14h-29zm0 36h29v14h-29zm0 0" fill="currentColor" data-original="#000000" style="" class=""/><path xmlns="http://www.w3.org/2000/svg" d="m176 87.292969v72.570312l50.835938-50.582031c2.832031-2.730469 7.316406-2.730469 10.148437 0l43.015625 42.847656v-70.019531l-49.40625-49.074219zm0 0" fill="currentColor" data-original="#000000" style="" class=""/></g></svg>'; 
														break;
													}
													?>
													
													<?php echo $v;?></label>
													<?php } ?>  
													</div>

													</div>
													<?php echo $form->hiddenField($model,$id);?>
													<div class="clearfix"></div>
													<?php echo $form->error($model, $id);?>
													</div>
													</div>
													</div> 

													<div class="clearfix"></div>
													
													
													  <div class="clearfix"></div>
                                        	<div class="form-group  ">

						    <div class="row">
	<div class="col-sm-12">
													<?php  	echo $form->labelEx($model ,'description');  ?>
													</div>
						 
							<div class="col-sm-12">

							<?php  	echo $form->textArea($model , 'description' ,  $model->getHtmlOptions('description',array('class'=>'input-text form-control LJB','style'=>'height: 150px !important;min-height: unset !important;max-width: 450px !important'  )));  ?>

							<?php echo $form->error($model, 'description');?>
						 

							</div>

							</div>
		</div> 
                                        <div class="clearfix"></div>
                                        
														  

													<div class="clearfix"></div>
													<h2>About Yourself </h2>
													<div class="clearfix"></div>
												 	
													
													
													
                                        	<div class="form-group  ">

						    <div class="row">

						 
							<div class="col-sm-12">

							<?php  	echo $form->textField($model , 'f_name' ,  $model->getHtmlOptions('first_name',array('class'=>'input-text form-control LJB','placeholder'=>'Full Name *' )));  ?>

							<?php echo $form->error($model, 'f_name');?>
						 

							</div>

							</div>
		</div> 
                                        <div class="clearfix"></div>
                                        	<div class="form-group  ">

						    <div class="row">

						 
							<div class="col-sm-12">

							<?php  	echo $form->textField($model , 'email' ,  $model->getHtmlOptions('email',array('class'=>'input-text form-control LJB','placeholder'=>'Email *' )));  ?>

							<?php echo $form->error($model, 'email');?>
						 

							</div>

							</div>
		</div> 
                                        <div class="clearfix"></div>
                                      
                                        	<div class="clearfix"></div>
		<div class="form-group  ">

						    <div class="row">


							<div class="col-sm-12">
<style>.iti.iti--allow-dropdown input { margin-right:0px !important; }.iti{ width:100%; }</style>
							<?php  	echo $form->textField($model , 'phone_false' ,  $model->getHtmlOptions('phone_false',array('class'=>'input-text form-control LJB','placeholder'=>'', 'oninput'=>"this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"  )));  ?>

							<?php echo $form->error($model, 'phone_false');?>
							

							</div>

							</div>
		</div>
		 <div class="clearfix"></div>
		 
		                   <div class="clearfix"></div>
		                   <div style="clear:both;"></div>
            
                       
		                 <div class="clearfix"></div>
								 
                              <div class="cols24">
                             
                                
								 	 <div id="msg_alert"></div>
								 	 
								 	 
								 	 
								 	  <div class="clearfix"></div>
  	 	 
								 	 	<div class="clearfix"></div>
								 	 		<div class="form-group  spl-12 agr"  >

						    <div class="row">

							<div class="col-sm-12">
					<div class="checkboxes">
						<label class="container_check" for="<?php echo $model->modelName;?>_agree">Agree to the <a href="<?php echo Yii::app()->createUrl('terms');?>" target="_blank" class="link_color">  Terms and Conditions</a> and the <a href="<?php echo Yii::app()->createUrl('privacy');?>" target="_blank" class="link_color">  Privacy Policy</a>.
						<?php  echo $form->checkBox($model , 'agree',  $model->getHtmlOptions('agree',array('uncheckValue'=>'', 'value'=>'1' )) );  ?> 
						  <span class="checkmark"></span>
						</label>
						<?php echo $form->error($model, 'agree');?>
					</div>
					</div>
					</div>
					</div>
					
					<div class="clearfix"></div>
					 <div class="clearfix"></div>
 	<div class="pop_boxone">
						<?php
						$min_error_count  = 1 ; 
					  
									$min_error_count  = 2 ; 
									?> 
									<div class="form-group">
									<div class="clearfix"></div>
									 <script>
						

  </script>
			 
			
									<div class="clearfix"></div>
									<?php echo $form->hiddenField($model, '_recaptcha' );?>
									<?php echo $form->error($model, '_recaptcha',array('style'=>'top:0px !important;'));?>
									 </div>	
									<div class="clearfix"></div>
										</div>	
	
<div class="clearfix"></div>
 
					<div class="clearfix"></div>
					
	<div class="form-group spl-n-right  margin-bottom-5">

						    <div class="row">
 
							<div class="col-sm-12">
	  
							<div class="form-group  ">

						    <div class="row">

						 
							<div class="col-sm-7">
		 
							<button  type="submit" class="btn btn-primary btn-block headfont btn-sm-s rounded-btn-n"  id="bb2" style=" clear: both;max-width:90%;margin:auto;" data-html="<?php echo $mainTex;?>"><?php echo $mainTex;?></button>
	   <p class="formLegalDisclaimer positionRelative h8 typeLowlight mtn">
                                      <?php // echo Yii::t('trans', 'By clicking on \'Check Availablity\', I agree to the {p} {t} and {pp}' ,array('{p}'=>$this->project_name,'{t}'=>'<a class="linkUnderline linkLowlight" href="/terms" target="_blank">'. 'Terms & Conditions' .'</a>','{pp}'=>'<a class="linkUnderline linkLowlight" href="/privacy" target="_blank">'. 'Privacy Policy' .'</a>'));?> 
                                  
                                    </p>
		
							</div>
		</div> 
							</div><!-- end #signin-form -->
						
	
							</div>
		</div> 

	<div class="clearfix"></div>
	<div class="clearfix"></div>

  
					<div class="clearfix"></div>
				</div>
		 	
                              
                              </div>
                          <?php $this->endWidget(); ?>
                        </div>
                     </div>
                  </div>
               </div>
			   <div class="clearfx"></div>
         
 <div style="clear:both"></div>
 
	
 
		<script>
    var input = document.querySelector("#<?php echo $model->modelName;?>_phone_false");
    window.intlTelInput(input, {
      // allowDropdown: false,
      // autoHideDialCode: false,
      // autoPlaceholder: "off",
      // dropdownContainer: document.body,
      // excludeCountries: ["us"],
      // formatOnDisplay: false,
      // geoIpLookup: function(callback) {
      //   $.get("http://ipinfo.io", function() {}, "jsonp").always(function(resp) {
      //     var countryCode = (resp && resp.country) ? resp.country : "";
      //     callback(countryCode);
      //   });
      // },
        hiddenInput: "phone",
       initialCountry: "<?php echo COUNTRY_CODE;?>",
      // localizedCountries: { 'de': 'Deutschland' },
      // nationalMode: false,
      // onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
       placeholderNumberType: "MOBILE",
      // preferredCountries: ['cn', 'jp'],
        separateDialCode: true,
      utilsScript: "<?php echo Yii::app()->apps->getBaseUrl('assets/js/build/js/utils.js');?>",
    });
    $(function(){
			onloadCallback()
			
			})
  </script>
   <style>
     .pwdopsdiv { display:none ; } .pwdstrengthstr , .pwdstrength { height:auto; }
       
   </style>
	 

	</div>
	 
	<div class="col-sm-5">
	<div style="text-align:center;">
		<div style="width:100px; display:inline-block; ;overflow: hidden;">
	 <img src="<?php echo $activeModel->getFilePath($activeModel->logo);?>" alt="<?php echo $activeModel->bank_name;?>"  style="width:100px;margin:auto;" >
	 </div>
	 </div>
	 <div>
		 <div style="margin-top:40px;">
	 <?php echo $activeModel->terms;?>
	 </div>
	 </div>
	 
	 
	 </div>
	
	
	
	</div>
  
    </section>
   
  </div>
  
</div>

					  </div>
					 
			</section>
			</div>
			 </div>
		</div>
			  
		 </div> 
		<!-- Contact Form / End -->

	</div>

</div>
<div id="inline-badge"></div>
<!-- Container / End -->



 
