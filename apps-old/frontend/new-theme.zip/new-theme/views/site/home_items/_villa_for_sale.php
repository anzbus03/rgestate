   <div class="row margin-bottom-40  "   >
                  
                     <div class="col-md-6 seperate_mar2 padding-left-0"  >
                        		  <h3 class="headline  margin-bottom-15  col-md-12 no-margin-left  "><?php echo Yii::t('trans',$general_head,array('{o}'=>$this->tag->getTag('villas-for-sale','Villas for sale '),'{c}' =>$section_name));?> </h3>
					
                     </div>
                     <div class="clearfix"></div><div class="ak_loader2"></div>
                     <div class="clearfix"></div>
                     <div class="col-md-12 seperate_mar"  >
                        <div class="_ba2wq3 werew slider-property1">
                           <!-- Listing Item -->
                           <?php
                           $json_array = array();
                           foreach($villas_for_sale as $k=>$v){ 
	 
							 
							$s_id ="villa_item".$v->id ; 
							$json_array = array();
						    ?>  
						     
                           <div class=" mul_sliderh <?php echo $s_class_n;?>  " id="<?php echo $s_id;?>"  style="" >
                           <div class="arws"></div> 
                           <div class="kkNHOn"><a href="<?php echo $v->detailUrl;?>" style="position: absolute;top: 0;bottom: 0;left: 0;right: 0;z-index: 115"></a> 
                                 <div class="listing-item">   <div class="tagsListContainer"  ><ul class="tagList tags listInlineBulleted man h7 typeEmphasize"><?php echo $v->getTagList('F');?></ul></div>
                                     
                                    	<div class="single-item-hover"></div>
								<div class='single-item' >
									<?php $bg = false;  echo $v->generateImage($apps,$h=380,$w=570,$s_id,$bg);?> 
								</div>
							 
								<?php
									if(!empty($v->ad_images_g)){
								//	echo "<script>$(document).ready(function(){ caroselSingle('".$s_id."',{$bg});});</script>";
									}
									?>
                                       
                                   
                                 </div>
                                  	 		<div class="residential-card__content-wrapper" role="presentation">
									   <div class="residential-card__content" role="presentation">
										  <div>
											 <div class="residential-card__price rui-truncate" role="presentation"> <?php echo $v->listRow1();?></div>
										  </div>
									      <div>
											  <?php echo $v->listRow3();?>
										  </div>
									     <?php echo $v->listRow2();?>
										</div>
									</div>
                              
									   </div>  
                              
                           </div>
                           <?php } ?> 
                          
                        </div>
                         
                     </div>
                             <div class="_ttoj70"><a href="<?php echo $this->app->createUrl('villas-for-sale');?><?php echo $href_url;?>" class="_5923kg"   style="border-color: rgb(224, 224, 224); text-decoration-color: rgb(70, 4, 121);"><span class="_l3bsjs sle"  >Show all villas for sale</span><span class="_8kak1d sle"  ><svg viewBox="0 0 18 18" role="presentation" aria-hidden="true" focusable="false" style="height: 10px; width: 10px; fill: currentcolor;"><path d="m4.29 1.71a1 1 0 1 1 1.42-1.41l8 8a1 1 0 0 1 0 1.41l-8 8a1 1 0 1 1 -1.42-1.41l7.29-7.29z" fill-rule="evenodd"></path></svg></span></a></div>
              
                  </div>
                 
