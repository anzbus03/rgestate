<div class="container margin-top-0" id="">
                  <div class="row margin-bottom-40">
                     <div class="col-md-12">
                        <h3 class="headline  margin-bottom-15  col-md-12 no-margin-left  ">
							 <?php echo $this->tag->getTag('ap_news_and_advise', 'News and Advise'  );?> 
	 
						</h3>
                     </div>
                     <div class="col-md-12 seperate_mar loader-initiate-div">

 <div class="_6htn2u">
	<ul class="_6i6u00" style="margin-left: -8px; margin-right: -8px;">
		 <?php
         foreach($latest as $k=>$v){ 
								  preg_match('/< *img[^>]*src *= *["\']?([^"\']*)/i', $v->content, $imges);
								  
								 
		
							  ?> 
		<li aria-hidden="false"    class="_1w7e1y2" style="border-width: 0px 8px; max-width: 16.66666666666667%; flex: 0 0 16.66666666666667%;">
			<div >
				<div class="_9kj686" data-key="0">
					<a href="<?php echo $this->app->createUrl($v->slug.'/blog');?>" class="_xvt7x" aria-busy="false">
						<div class="_13ky0r6y" style="padding-top: 125%; background: rgb(72, 72, 72) none repeat scroll 0% 0%;margin-bottom: 12px;">
							<div class="_1szwzht">
								<div class="_hxt6u1e" style="padding-top: 125%;">
									<div class="_4626ulj">
										<img class="_91slf2a" style="object-fit: cover;" alt="" decoding="async" src="<?php echo @$imges['1'];?>">
							 			</div>
								</div>
							 
								<div class="_96n9kn hide">
									<div class="_1j7uypzo"><?php echo $v->title;?></div>
								</div>
							</div>
						</div>
						<div><div><div class="_1s5t6bf8"  ><?php echo $v->title;?></div> </div></div>
					</a>
				</div>
				
			</div>
		</li>
		<?php } ?> 
	 
	</ul>
 
</div> <style>
 ._6htn2u {
    position: relative !important;
    z-index: 0 !important;
}._6i6u00 {
    scrollbar-width: none !important;
    display: flex !important;
    list-style: outside none none !important;
    overflow-x: auto !important;
    padding-left: 0px !important;
    margin-bottom: 0px !important;
    margin-top: 0px !important;
    min-width: 100% !important;
    scroll-snap-type: x mandatory !important;
}._1w7e1y2 {
    border-style: solid !important;
    border-color: transparent !important;
    scroll-snap-align: start !important;
}._6i6u00 {
    list-style: outside none none !important;
}._9kj686 {
    width: 100% !important;
    margin-right: 6px !important;
    margin-bottom: 4px !important;
}._xvt7x {
    display: block !important;
    width: 100% !important;
    background-color: transparent !important;
    overflow: hidden !important;
}._13ky0r6y {
    contain: strict !important;
    position: relative !important;
    width: 100% !important;
    z-index: 0 !important;
    border-radius: 3px !important;
    overflow: hidden !important;
}._1szwzht {
    position: absolute !important;
    inset: 0px !important;
    height: 100% !important;
    width: 100% !important;
}._hxt6u1e {
    position: relative !important;
    background-position: 50% 50% !important;
    background-repeat: no-repeat !important;
}._wyr5tw {
    background-image: linear-gradient(-180deg, rgba(0, 0, 0, 0) 3%, rgb(0, 0, 0) 100%) !important;
    opacity: 0.6 !important;
    position: absolute !important;
    height: 60% !important;
    width: 100% !important;
    left: 0px !important;
    bottom: 0px !important;
}._96n9kn {
    position: absolute !important;
    bottom: 0px !important;
    left: 0px !important;
    right: 0px !important;
    padding-bottom: 32px !important;
    padding-left: 24px !important;
    padding-right: 24px !important;
}._1j7uypzo {
    margin: 0px !important;
    overflow-wrap: break-word !important;
    font-family: Circular, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif !important;
    font-size: 18px !important;
    font-weight: 400 !important;
    line-height: 1.44444em !important;
    color: rgb(255, 255, 255) !important;
    text-align: center !important;
}
._4626ulj {    left: 0;
    right: 0;
    top: 0;
    bottom: 0;}
    ._1s5t6bf8 {
    overflow-wrap: break-word !important;
    font-family: 'Circular', -apple-system, BlinkMacSystemFont, Roboto, "Helvetica Neue", sans-serif !important;
    font-size: 16px !important;
    font-weight: 800 !important;
    line-height: 1.375em !important;
    text-overflow: ellipsis !important;
    max-height: 4.125em !important;
    -webkit-line-clamp: 3 !important;
    display: -webkit-box !important;
    -webkit-box-orient: vertical !important;
    margin: 0px !important;
    overflow: hidden !important;
    color:rgb(72, 72, 72);;
}
 </style>
	 <div class="_ttoj70"><a href="<?php echo $this->app->createUrl('bloglist/index');?><?php echo $href_url;?>" class="_5923kg"   style="border-color: rgb(224, 224, 224); text-decoration-color: rgb(70, 4, 121);"><span class="_l3bsjs rnt"  ><?php echo $this->tag->getTag('ap_show_all_blog','Show all blog');?></span><span class="_8kak1d rnt"  ><svg viewBox="0 0 18 18" role="presentation" aria-hidden="true" focusable="false" style="height: 10px; width: 10px; fill: currentcolor;"><path d="m4.29 1.71a1 1 0 1 1 1.42-1.41l8 8a1 1 0 0 1 0 1.41l-8 8a1 1 0 1 1 -1.42-1.41l7.29-7.29z" fill-rule="evenodd"></path></svg></span></a></div>
           
				</div>
			
		</div>
		     
</div>
                
