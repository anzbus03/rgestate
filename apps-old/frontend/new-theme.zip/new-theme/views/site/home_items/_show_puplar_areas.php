<div class="container margin-top-0" id="">
                  <div class="row margin-bottom-40">
                     <div class="col-md-12">
                        <h3 class="headline  margin-bottom-15  col-md-12 no-margin-left  ">
							 <?php echo $this->tag->getTag('ap_ajman_popular_areas', 'Ajman Popular Areas'  );?> 
	 
						</h3>
                     </div>
                     <div class="col-md-12 seperate_mar loader-initiate-div">

 <div class="_6htn2u">
	<ul class="_6i6u00" style="margin-left: -8px; margin-right: -8px;" id="slicker_area">
		 <?php
		  $marker = '10X10.png';$opacity=30;
         foreach($popular_ajman as $k=>$v){ 
							 	  
								$image = !empty($v->image) ?  $v->image  : 'default_loc.jpg'   ;  
	$imges =	Yii::app()->easyImage->thumbSrcOf(
		Yii::getpathOfAlias('webroot')  .'/uploads/banner/'.$image,		 
		array(
	 	'watermark' => array('watermark' =>'watermark/'.$marker , 'opacity' => $opacity ), 
		'sharpen' => 20,  'background' => '#E7ED67', 'type' => 'jpg',  'quality' => 100
		) 
		);
							  ?> 
		<li aria-hidden="false"    class="_1w7e1y22" style="border-width: 0px 8px; max-width: 16.66666666666667%; flex: 0 0 16.66666666666667%;">
			<div >
				<div class="_9kj686" data-key="0">
					<a href="<?php echo Yii::App()->createUrl('listing/index',array('poplar_area'=>$v->id));?>"" class="_xvt7x" aria-busy="false">
						<div class="_13ky0r6y" style="padding-top: 125%; background: rgb(72, 72, 72) none repeat scroll 0% 0%;margin-bottom: 12px;">
							<div class="_1szwzht">
								<div class="_hxt6u1e" style="padding-top: 125%;">
									<div class="_4626ulj">
										<img class="_91slf2a" style="object-fit: cover;" alt="" decoding="async" src="<?php echo  $imges ;?>">
							 			</div>
								</div>
								 
								<div class="_96n9kn hide">
									<div class="_1j7uypzo"><?php echo $v->FullTitle;?></div>
								</div>
							</div>
						</div>
						<div><div><div class="_1s5t6bf8"  ><?php echo $v->FullTitle;?></div> </div></div>
						<div class="seperatePikcer"><a href="<?php echo Yii::App()->createUrl('listing/index/sec/property-for-sale',array('poplar_area'=>$v->id));?>"  class="hover-u" hover-u><?php echo $this->tag->getTag('ap_for_sale','For Sale');?></a> | <a href="<?php echo Yii::App()->createUrl('listing/index/sec/property-for-sale',array('poplar_area'=>$v->id));?>" class="hover-u"><?php echo $this->tag->getTag('ap_for_rent','For Rent');?></a></div>
					</a>
				</div>
				
			</div>
		</li>
		<?php } ?> 
	 
	</ul>
 
</div>        
				</div>
			
		</div>
		     
</div>
 <script>
	$(function(){
 
		 	$('#slicker_area').slick({
			infinite: false,
			slidesToShow: 6,
			slidesToScroll: 1,rtl: is_rtlc,
			dots: false,
			arrows: true,
			responsive: [{
				breakpoint: 992,
				settings: {
					slidesToShow: 5,
					slidesToScroll: 1
				}
			}, {
				breakpoint: 769,
				settings: {
					slidesToShow: 3,
					slidesToScroll: 1
				}
			}, {
				breakpoint: 580,
				settings: {
					slidesToShow: 2,
					slidesToScroll: 1
				}
			}]
		});
})
</script>
                 
