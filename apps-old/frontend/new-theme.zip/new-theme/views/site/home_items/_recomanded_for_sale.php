<div class="clearfix"></div>
                 <div class="row margin-bottom-0 margin-top-40  top-after-head">
                     <div class="col-md-12   padding-left-0 margin-bottom-30 bottom-after-head">
                        <h3 class="headline  margin-bottom-0  col-md-12 no-margin-left text-center mob-text-left new-show-all-h3 ">  <?php echo Yii::t('app',  $this->tag->getTag('new_projects','New Projects') ,array('{country}'=>COUNTRY_NAME)) ;?>  	</h3>
									<div class="_ttoj70  new-show-all-link"><a href="<?php echo $this->app->createUrl('listing/index/sec/new-development');?>" class="_5923kg"  onclick="easyload(this,event,'mainContainerClass')"  style="border-color: rgb(224, 224, 224); text-decoration-color: rgb(70, 4, 121);"><span class="_l3bsjs sle"  ><?php echo $this->tag->getTag('show_all','Show all');?></span><span class="_8kak1d sle"  ><svg viewBox="0 0 18 18" role="presentation" aria-hidden="true" focusable="false" style="height: 10px; width: 10px; fill: currentcolor;"><path d="m4.29 1.71a1 1 0 1 1 1.42-1.41l8 8a1 1 0 0 1 0 1.41l-8 8a1 1 0 1 1 -1.42-1.41l7.29-7.29z" fill-rule="evenodd"></path></svg></span></a></div>
      <div class="clearfix"></div>
                     </div>
                  <div class="clearfix"></div> 
                     <div class="col-md-12 seperate_mar  margin-bottom-0  ">

<ul class="  projects  margin-bottom-0 featslider2 " id="projectSlider" >
   <?php
    $marker = '30X30.png';$opacity=30;
    $from = $this->tag->getTag('from','from');$view_details = $this->tag->getTag('view_details','View Details');
	if(!empty($featured_developers)){					  
   foreach($featured_developers as $k=>$v){
	?>					
   <li aria-hidden="false"  class="_1hfjk81 project  margin-bottom-0 col-xl-6 col-lg-6 col-md-6" >
	    <a href="<?php echo $v->detailUrl;?>"  onclick="easyload(this,event,'mainContainerClass')">
    		    <figure class="project-effect  llod" style="border-radius:4px;">
								<img data-src="<?php echo $v->getSingleImage(382);?>" class="img-fluid lozad" style="min-height:150px;" >
                 <figcaption>
                     <?php /* 
   <div class="project-info  margin-bottom-0">
       
       <?php
       if(!empty($v->CompanyImage)){ ?> 
      <div class="logo"> <img src="<?php echo $v->CompanyImage;?>" alt="<?php echo $v->CompanyName;?>"> </div>
      <?php } ?> 
      <div class="dev-info">
         <h2 class="title"><?php echo $v->adTitle;?></h2>
         <h3 class="dev"><?php echo rtrim($v->locationTitle,', ');?></h3>
         <div class="price">  From <?php echo $v->PriceTitleSpanL;?>  </div>
      </div>
      <div class="clear"></div>
   </div>
   */
   ?>
   <div class="hidden-info">
	  
      <div class="btn-details button button-secondary">
         <?php echo $view_details;?>
         <span class="_8kak1d rnt"  >
            <svg viewBox="0 0 18 18" role="presentation" aria-hidden="true" focusable="false" style="height: 10px; width: 10px; fill: #fff;">
               <path d="m4.29 1.71a1 1 0 1 1 1.42-1.41l8 8a1 1 0 0 1 0 1.41l-8 8a1 1 0 1 1 -1.42-1.41l7.29-7.29z" fill-rule="evenodd"></path>
            </svg>
         </span>
      </div>
   </div>
</figcaption>								
                </figure>
                  <div class="project-info-mob margin-bottom-0">
      <div class="logo"> <img src="<?php echo $v->CompanyImage;?>" alt="<?php echo $v->CompanyName;?>"> </div>
      <div class="dev-info">
         
         <h2 class="title"><?php echo $v->AdTitle2;?></h2>
           <h3 class="dev"><?php echo rtrim($v->locationTitle,', ');?></h3>
          <div class="price"><?php echo $from;?> <?php echo $v->PriceTitleSpanL;?>  </div>
          
         <div class="clear"></div>
        
      </div>
      <div class="clear"></div>
   </div>
   <div class="price-m-info">
        <div class="price"><?php echo $from;?> <?php echo $v->PriceTitleSpanL;?>  </div>
   </div>
           </a>
    </li>
   <?php }  
}
    ?> 

</ul>

				</div>  
				     <div class="a-view-more-home-div"><a href="<?php echo $this->app->createUrl('listing/index/sec/new-development');?>" onclick="easyload(this,event,'mainContainerClass')" class="a-view-more-home"  ><span class=""><?php echo $this->tag->getTag('view_more_for_new_projects','View more for new projects');?></span><span class="_8kak1d margin-left-5"><svg viewBox="0 0 18 18" role="presentation" aria-hidden="true" focusable="false" style="height: 10px; width: 10px; fill: currentcolor;"><path d="m4.29 1.71a1 1 0 1 1 1.42-1.41l8 8a1 1 0 0 1 0 1.41l-8 8a1 1 0 1 1 -1.42-1.41l7.29-7.29z" fill-rule="evenodd"></path></svg></span></a> </div>
                     
	       <?php  if($b_4){ echo '<div class="" style="margin-bottom: 20px;margin-top:20px;">'. $b_4.'<div class="clearfix"></div></div>';; } ?>
		</div>
		
 
 <div class="clearfix"></div>              
 
