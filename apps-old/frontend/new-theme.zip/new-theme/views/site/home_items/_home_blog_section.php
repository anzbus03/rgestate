<?php 
if(!empty($latest)){ ?> <div class="clearfix"></div>
<div class="container margin-top-0 blg-sec" id="">
                  <div class="row margin-bottom-0 margin-top-40  top-after-head">
                  
                     
                     <div class="col-md-12  padding-left-0 margin-bottom-30 bottom-after-head">
                        <h3 class="headline  margin-bottom-0  col-md-12 margin-left-0 text-center  mob-text-left padding-left-0  new-show-all-h3">  <?php echo $this->tag->getTag('news_and_advise','News and Advise');?> </h3>
						<div class="_ttoj70  new-show-all-link"><a href="<?php echo Yii::app()->options->get('system.common.blog_link','#nogo');?>"   class="_5923kg" style="border-color: rgb(224, 224, 224); text-decoration-color: rgb(70, 4, 121);"><span class="_l3bsjs rnt"><?php echo $this->tag->getTag('show_all','Show all');?></span><span class="_8kak1d rnt"><svg viewBox="0 0 18 18" role="presentation" aria-hidden="true" focusable="false" style="height: 10px; width: 10px; fill: currentcolor;"><path d="m4.29 1.71a1 1 0 1 1 1.42-1.41l8 8a1 1 0 0 1 0 1.41l-8 8a1 1 0 1 1 -1.42-1.41l7.29-7.29z" fill-rule="evenodd"></path></svg></span></a></div>
               <div class="clearfix"></div>
                     </div>
                     <div class="col-md-12 seperate_mar loader-initiate-div open">

 <div class="_6htn2u">
	<ul class="_6i6u00" style="" id="frsBlogSlider">
		 <?php
		 foreach($latest as $v){
			  preg_match('/< *img[^>]*src *= *["\']?([^"\']*)/i', $v->content, $imges);
									 
									 
			  ?>
		<li aria-hidden="false" class="_1w7e1y2" style="border-width: 0px 8px; max-width: 16.66666666666667%; flex: 0 0 16.66666666666667%;">
			<div>
				<div class="_9kj686" data-key="0">
					<a href="<?php echo $this->app->createUrl($v->slug.'/blog');?>"     class="_xvt7x" aria-busy="false">
						<div class="_13ky0r6y" style="padding-top: 125%; background: rgb(72, 72, 72) none repeat scroll 0% 0%;margin-bottom: 12px;">
							<div class="_1szwzht">
								<div class="_hxt6u1e" style="padding-top: 125%;">
									<div class="_4626ulj">
										<img class="_91slf2a lozad" style="object-fit: cover;" alt="<?php echo $v->title;?>" decoding="async"    data-src="<?php echo $v->generateImage(@$imges['1']);?>">
							 			</div>
								</div>
							 
								<div class="_96n9kn hide">
									<div class="_1j7uypzo"><?php echo $v->title;?></div>
								</div>
							</div>
						</div>
						<div><div><div class="_1s5t6bf8"><?php echo $v->title;?></div> </div></div>
					</a>
				</div>
				
			</div>
		</li>
		<?php } ?> 
	</ul>
 
</div>
<script>    homeBlog();    </script>
           
				</div>
			
		</div>
		     
</div>
 <?php } ?> 
