<div class="clearfix"></div>
   <div class="row margin-bottom-0 margin-top-40  top-after-head  grid"   >
                 
                     
                     <div class="col-md-12   padding-left-0 margin-bottom-30 bottom-after-head">
                        <h3 class="headline  margin-bottom-0  col-md-12 margin-left-0 text-center  mob-text-left padding-left-0  new-show-all-h3"><?php echo $this->tag->getTag('new_listing_for_sale','New listings for sale');?></h3>
						<div class="_ttoj70  new-show-all-link"><a href="<?php echo $this->app->createUrl('listing/index',array('sec'=>SALE_SLUG));?>" onclick="easyload(this,event,'mainContainerClass')" class="_5923kg" style="border-color: rgb(224, 224, 224); text-decoration-color: rgb(70, 4, 121);"><span class="_l3bsjs rnt"><?php echo $this->tag->getTag('show_all','Show all');?></span><span class="_8kak1d rnt"><svg viewBox="0 0 18 18" role="presentation" aria-hidden="true" focusable="false" style="height: 10px; width: 10px; fill: currentcolor;"><path d="m4.29 1.71a1 1 0 1 1 1.42-1.41l8 8a1 1 0 0 1 0 1.41l-8 8a1 1 0 1 1 -1.42-1.41l7.29-7.29z" fill-rule="evenodd"></path></svg></span></a></div>
               <div class="clearfix"></div>
                     </div>  
    
                    
                     <div class="clearfix"></div> 
                     <div class="clearfix"></div>
                     <div class="col-md-12 seperate_mar"  >
                        <div class="_ba2wq3 werews home-layt row "  >
                           <!-- Listing Item -->
                           <?php
                           $json_array = array();$bg = true;
                           foreach($new_homes as $k=>$v){  
							   $s_id ="sale_item".$v->id ;	$company_image = $v->CompanyImage2;
						    ?>  
						    
						    		    	<div    class="col-sm-4 lst-prop  propli  mul_sliderh smsec_<?php echo $v->section_id;?>" id="<?php echo $s_id;?>"  data-price="<?php echo $v->price;?>">
							
						
							<div class="arws"></div> 
							 <div class="listing-item"> 
										
										<div class="tagsListContainer"  >
										<ul class="tagList tags listInlineBulleted man h7 typeEmphasize"><?php echo $v->getTagList('F');?></ul>
										</div>
                                     
                                    	<div class="single-item-hover"></div>
										<div class='single-item' href="<?php echo $v->detailUrl;?>" onclick="easyload2(this,event,'mainContainerClass')" >
											<?php  echo $v->generateImage2($apps,$h=380,$w=570,$s_id,$bg);?> 
										</div>
											  <div    class="list-36view">
                                        <?php  if($v->view_360){  ?><span class="spn-r-round view-360"></span><?php } ?> 
                                        <?php  if($v->view_video){  ?><span class="spn-r-round view-vid"></span><?php } ?> 
                                        <?php  if($v->view_floor){  ?><span class="spn-r-round view-floor"></span><?php } ?> 
										</div>
                                       
                                   <?php
										if($v->property_status=='1'){  echo '<span class="p_staus">'.$v->SoldStatus.'</span>';} ?>
										<span class="pull-right sm-d-date2 margin-left-5"><?php echo $v->ShowDateFrontend;?></span>
                                 </div>
                            
                                 	
            <div class="wrapper" style="position:relative;">	<a href="<?php echo $v->detailUrl;?>" onclick="easyload2(this,event,'mainContainerClass')" class="lsproplink"> </a> 
				<div class="price"><?php echo $v->listRowPrice();?><span class="forgrid pull-right"><?php echo  $v->SectionCategoryFullTitle;?></span></div>
              <div class="smartad_infoarea <?php echo  !empty($company_image) ? 'has-cm-image pull-left' : '';?>">
                <h2 class="smartad_title smartad_title-link"><a href="<?php echo $v->detailUrl;?>"  onclick="easyload2(this,event,'details-page-container')"><?php echo  $v->AdTitle2;?></a></h2>
                
                <div class="smartad_detail">
                   
                    <?php echo $v->listRowFeatures();?>
                    </div>
                <div class="smartad_location-area">
                  <div class="smartad_location"><span class="svg">
                    <svg viewBox="0 0 1792 1792" class="smartad_locationicon">
                      <use xlink:href="#svg-location"></use>
                    </svg>
                    </span><span class="smartad_locationtext"><?php echo $v->listRowLocation();?></span>
                       
                    </div>
                </div>
              </div>
             <?php
               if(!empty($company_image)){
				   ?>
				   <div class="company_image_li pull-right"><img src="<?php echo $company_image;?>" /></div>
				   <?
			   }
			   ?>
             <div class="clearfix"></div>
            </div>
               <?php echo $v->footerLinkNew();?>
          </div>
           
			              <?php } ?> 
                          
                        </div>
                         
                     </div>
                     <div class="clearfix"></div>
                     <div class="a-view-more-home-div"><a href="<?php echo $this->app->createUrl('listing/index',array('sec'=>SALE_SLUG));?>" onclick="easyload(this,event,'mainContainerClass')" class="a-view-more-home"  ><span class=""><?php echo $this->tag->getTag('view_more_for_sale','View more for sale');?></span><span class="_8kak1d margin-left-5"><svg viewBox="0 0 18 18" role="presentation" aria-hidden="true" focusable="false" style="height: 10px; width: 10px; fill: currentcolor;"><path d="m4.29 1.71a1 1 0 1 1 1.42-1.41l8 8a1 1 0 0 1 0 1.41l-8 8a1 1 0 1 1 -1.42-1.41l7.29-7.29z" fill-rule="evenodd"></path></svg></span></a> </div>
                 </div>
                  
                 <?php  if($b_2){ echo '<div  class="margin-top-40"  >'. $b_2.'<div class="clearfix"></div></div>';; } ?> 
