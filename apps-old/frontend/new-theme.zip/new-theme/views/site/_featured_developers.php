<?php
if(!empty($featred_agencies)){ ?>
 <div class="clearfix"></div>
<div class="container     padding-bottom-0"  >
   <div class="wrap no-at-mob-p margin-bottom-0 margin-top-40  top-after-head">
     <div class="col-md-12  padding-left-0 margin-bottom-30 bottom-after-head">
                        <h3 class="headline  margin-bottom-0  col-md-12 margin-left-0 text-center  mob-text-left padding-left-0  new-show-all-h3"><?php echo $this->tag->getTag('featured_agencies','Featured Agencies');?></h3>
						<div class="_ttoj70  new-show-all-link"><a href="<?php echo Yii::app()->createUrl('user_listing/index');?>" onclick="easyload(this,event,'mainContainerClass')" class="_5923kg" style="border-color: rgb(224, 224, 224); text-decoration-color: rgb(70, 4, 121);"><span class="_l3bsjs rnt"><?php echo $this->tag->getTag('show_all','Show all');?></span><span class="_8kak1d rnt"><svg viewBox="0 0 18 18" role="presentation" aria-hidden="true" focusable="false" style="height: 10px; width: 10px; fill: currentcolor;"><path d="m4.29 1.71a1 1 0 1 1 1.42-1.41l8 8a1 1 0 0 1 0 1.41l-8 8a1 1 0 1 1 -1.42-1.41l7.29-7.29z" fill-rule="evenodd"></path></svg></span></a></div>
						<div class="clearfix"></div>
                     </div>  
       <div class="clear"></div>
      
      <div class="rs featured-agencies-list"  >
            <div class="col-sm-12 padding-right-0  ">
         <div class="container row" id="frsSlider"   >
			<?php
	    	$opend = false; $count = 0 ; $premium = 0; 
			foreach($featred_agencies as $k=>$v){ 
						if($v->premium=='1'){
								echo '<div class="a8819b63 featureds" aria-label="Featured agency'.$k.'">';   
								$premium++; 
								echo '<a href="'. Yii::app()->createUrl('user_listing/detail_developer',array('slug'=>$v->slug)) .'"   class="_2af66cb5 premium margin-top-0 " > <img alt="'.$v->CompanyName.'"        data-src="'. $v->CompanyLogo.'" class="  lozad"   ></a>'; 
								echo '</div>';  
						}
						else{
						//if($count%3 == '0'  ){ $count = 0 ;$opend = true;  echo '';  }
						//$count ++; 
            
						 echo '<div class="a8819b63 featureds" aria-label="Featured agency'.$k.'"><a href="'. $v->agentDetailUrl .'"  onclick=easyload(this,event,"mainContainerClass")  class="_2af66cb5 margin-top-0 " style="position:relative;" > <span class="llod"><img alt="'.$v->CompanyName.'"        data-src="'. $v->CompanyLogo.'" class="  lozad"   ></span></a></div>'; 
						// if($count==3 and $opend ){ $opend = false; echo '';  }
						  
						}
              } 
              if(  $opend ){   echo '</div>';  }
              ?> 
         </div>
         <div class="clearfix"></div>
             </div>
      <div class="clearfix"></div>
      </div>
    </div>
   <div class="agencies-bg"></div>
</div>
<?php } ?> 
