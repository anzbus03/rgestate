<style>
@media only screen and (min-width: 1024px) {
.slider-form .top-search {    margin-top: 0;    margin-bottom: 15px;    display: flex;    align-items: center;    white-space: nowrap;} 
}
</style>
<?php
if (Yii::app()->request->isAjaxRequest) {
	?>
	<script>$('body').attr("id","site");$('#pageHeader').addClass('boxshdw');</script>
	<title><?php  echo  $pageTitle ;  ?></title>
	<meta name="description" content="<?php echo !empty($pageMetaDescription) ? $pageMetaDescription :  Yii::t('app',$this->generateCommon('home_meta_description'),array('{country}'=>COUNTRY_NAME,'{project_name}'=>$this->project_name));?>">
	<meta name="keywords" content="<?php echo Yii::t('app',$this->generateCommon('home_meta_keywords'),array('{country}'=>COUNTRY_NAME,'{project_name}'=>$this->project_name));?>">
	<meta property="fb:app_id" content="<?php echo $this->options->get('system.common.facebook_app_id');?>">
	<meta property="og:site_name" content="<?php echo $this->options->get('system.common.site_name');?>"> 
	<?php 
}
$this->widget('frontend.components.web.widgets.home_banner.HomeBannerWidget');$default_country_name = 'Pakistan'; ?>
<script>var is_home=true; </script>
       <div class="container home_container d-hm" style="height:65px;">
             
            
         </div>
        
<div class ="">
	       
    
           
		<div class="clearfix"></div>
       <div>
       <?php  if($b_1){ echo '<div class="m-after-sect" style="margin-bottom: 0px;margin-top:50px;">'. $b_1.'<div class="clearfix"></div></div>';; } ?> 
       </div>
     
    <?php
    if(!empty($new_homes)){
       
		?>
    <section class="feature-property-home6 homespan" style="padding-bottom: 20px;">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 spl">
            <div class="main-title mb30">
              <h2 class="pull-left"><?php echo $widget['109'];?></h2>
                      <div class="_ttoj70 new-show-all-link hide"><a href="<?php echo $this->app->createUrl('listing/index',array('sec'=>SALE_SLUG));?>?sort=date-desc" class="_5923kg" onclick="easyload(this,event,&quot;mainContainerClass&quot;)" style="border-color:#e0e0e0;text-decoration-color:#460479"><span class="sle _l3bsjs"><?php echo $this->tag->getTag('show_all','Show all');?></span><span class="sle _8kak1d"><svg viewBox="0 0 18 18" aria-hidden="true" focusable="false" role="presentation" style="height:10px;width:10px;fill:currentcolor"><path d="m4.29 1.71a1 1 0 1 1 1.42-1.41l8 8a1 1 0 0 1 0 1.41l-8 8a1 1 0 1 1 -1.42-1.41l7.29-7.29z" fill-rule="evenodd"></path></svg></span></a></div>
			<div class="clearfix"></div>
            </div>
          </div>
        </div>
        <div class="row">
            <style>
                .prop_detailss li.bathit{ display:none;}
                html .feat_property.home7.style4 .tag.hde-descp li {    color: #fff !important;    line-height: 1.3;    font-size: 13px;    padding: 5px 10px !important;   }
                .tag.hde-descp li:first-child{ border-top-right-radius:0px !important;border-bottom-right-radius:0px !important;}
                 .tag.hde-descp li:last-child{ border-top-left-radius:0px !important;border-bottom-left-radius:0px !important;}
            </style>
			<?php
			foreach($new_homes as $k=>$v){
		  
			?>
            <div class="col-md-6 col-lg-2">
                
            <div class="feat_property home7 style4">
				<a href="<?php echo $v->detailUrl;?>" style="position:absolute;left:0;top:0;bottom:0px;right:0px;z-index:1"></a>
              <div class="thumb">
                  
                  <ul></ul>
               
                <img class="img-whp" src="<?php echo $v->getAd_image_singlenew("150");?>"  alt="<?php echo $v->ad_title;?>"  title="<?php echo $v->ad_title;?>"  > 
                 
              
                <div class="thmb_cntnt">
					 <ul class="tag mb0 hde-descp"><li><?php echo  $v->SecNewTitle2;?></li><li><?php echo $v->ListingTypeCategory;?></li></ul>
                     
                
                </div>
              </div>
              <div class="details">
                <div class="tc_content"> <a class="fp_price" href="#"><?php echo $v->listRowPriceNew();?></a>
                  <p class="add"> <span class="flaticon-placeholder"></span><?php echo $v->listRowLocation();?></p>
                  <p> <?php echo  $v->AdTitle2;?></p>
                  <ul class="prop_detailss">
                   <?php echo $v->listRowFeaturesNew();?>
                  </ul>
                  <?php echo $v->footerLinkNew2();?>
                </div>
              </div>
            </div>
          </div>
			<?php } ?> 
        </div>
      </div>
    </section>
    <?php } ?>     
    
    
    
     <div class="section page-section section-no-padding">
      <section id="property-city" class="property-city pb0 pt0">
        <div class="container">
          <div class="row">
            <div class="col-lg-12 offset-lg-12">
              <div class="main-title text-center mb30">
                <?php echo $widget['108'];?>
              </div>
            </div>
          </div>
                <style>
                .sec-items-2 .brddr{
                    border: 1px solid #eee;height: 100%;display: flex;align-items: center;justify-content: center;border-radius:12px;
                }
                .sec-items-2.brddr :hover {
                     border: 1px solid var(--secondary-color);
                }
                 .sec-items-2 .brddr h4
                {
                    color: #333;font-weight: 600;margin-bottom: 5px;font-size: 16px;
                }.sec-items-2 .brddr:hover h4{
                     color:var(--secondary-color);
                }
                .full-vuew{ position:absolute;left:0px;right:0px;top:0px;bottom:0px;}
            </style>
          
          
          <div class="row features_row">
            <div class="col-sm-6 col-lg-3 col-xl-3 p0">
              <div class="why_chose_us home6">
                  <a href="<?php echo $this->app->createUrl('listing/index',array('sec'=>SALE_SLUG));?>" class="full-vuew"></a>
                <div class="icon"> <img src="<?php echo $this->app->apps->getBaseUrl('new_assets/images/icon1.png');?>"> </div>
                <div class="details">
                   <?php echo $widget['104'];?>
                   <a href="<?php echo $this->app->createUrl('listing/index',array('sec'=>SALE_SLUG));?>" class="sc-1oeu0fy-0"><?php echo $this->tag->getTag('view_all_properties_for_sale','View all properties for sale');?> <img src="<?php echo $this->app->apps->getBaseUrl('new_assets/images/arrow.png');?>"> </a> </div>
              </div>
            </div>
            <div class="col-sm-6 col-lg-3 col-xl-3 p0">
              <div class="why_chose_us home6">
                  <a href="<?php echo $this->app->createUrl('listing/index',array('sec'=>RENT_SLUG));?>" class="full-vuew"></a>
                <div class="icon"> <img src="<?php echo $this->app->apps->getBaseUrl('new_assets/images/icon2.png');?>"> </div>
                <div class="details">
                   <?php echo $widget['105'];?>
                  <a href="<?php echo $this->app->createUrl('listing/index',array('sec'=>RENT_SLUG));?>" class="sc-1oeu0fy-0"><?php echo $this->tag->getTag('view_all_rental_properties','View all rental properties');?> <img src="<?php echo $this->app->apps->getBaseUrl('new_assets/images/arrow.png');?>"> </a> </div>
              </div>
            </div>
            <div class="col-sm-6 col-lg-3 col-xl-3 p0">
              <div class="why_chose_us home6">
                  <a href="<?php echo $this->app->createUrl('listing/index',array('sec'=>'preleased'));?>" class="full-vuew"></a>
                <div class="icon"> <img src="<?php echo $this->app->apps->getBaseUrl('new_assets/images/icon3.png');?>"> </div>
                <div class="details">
                   <?php echo $widget['113'];?>
                  <a href="<?php echo $this->app->createUrl('listing/index',array('sec'=>'preleased'));?>" class="sc-1oeu0fy-0"><?php echo $widget['114'];?> <img src="<?php echo $this->app->apps->getBaseUrl('new_assets/images/arrow.png');?>"> </a> </div>
              </div>
            </div>
            <div class="col-sm-6 col-lg-3 col-xl-3 p0">
              <div class="why_chose_us home6">
                  <a href="<?php echo $this->app->createUrl('business_listing/index',array('sec'=>'business-for-sale'));?>" class="full-vuew"></a>
                <div class="icon"> <img src="<?php echo $this->app->apps->getBaseUrl('new_assets/images/icon41.png');?>"> </div>
                <div class="details">
                   <?php echo $widget['115'];?>
                  <a href="<?php echo $this->app->createUrl('business_listing/index',array('sec'=>'business-for-sale'));?>" class="sc-1oeu0fy-0"><?php echo $widget['116'];?> <img src="<?php echo $this->app->apps->getBaseUrl('new_assets/images/arrow.png');?>"> </a> </div>
              </div>
            </div>
        </div>
      </section>
      <style>
          .properti_city a {
   
  z-index: 111111; 
}@media only screen and (max-width: 768px) {
  .spl-feat {
    flex-direction: column;
  }.properti_city.single-dic {
    height: 125.4px;
    margin-bottom: 10px;
}html .customer-logos .divi-logo {
   
    max-width: 50px;
    float: left;
}
}
      </style>
      <?php 
        $learn_more = $this->tag->getTag('view_listings','View Listings');?>
      <section id="property-city" class="property-city  pb0" style="padding-top: 0px;padding-bottom: 0px;">
        <div class="container">
          <div class="row">
            <div class="col-lg-12 spl offset-lg-12">
              <div class="main-title text-center mb30">
                <h2><?php echo $widget['110'];?></h2>
              </div>
            </div>
          </div>
          <div class="row mob-d-flex spl-feat">
            <div class="col-sm-2 col-md-2 col-lg-2 col-xl propdfff">
             <?php $i= 0; ?>
              <div class="properti_city single-dic">
                  <a href="<?php echo $this->app->createUrl('listing/index',array('sec'=>'property-for-sale','state'=>$fav_communities[$i]->slug,'type_of'=>'commercial'));?>"></a>
                <div class="thumb"><img class="img-fluid w100" src="<?php echo $this->app->apps->getBaseUrl('uploads/default/'.$fav_communities[$i]->icon);?>" alt="pc7.jpg"></div>
                <div class="overlayyy">
                  <div class="details">
                    <h4><?php echo $fav_communities[$i]->state_name;?></h4>
                    <p><?php echo  $learn_more;?></p>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-3 col-md-3 col-lg-3 col-xl propdfff">
                <?php $i= 1; ?>
              <div class="col-sm-12 col-md-12 col-lg-12 col-xl" style="padding: 0px;">
                <div class="properti_city">
                      <a href="<?php echo $this->app->createUrl('listing/index',array('sec'=>'property-for-sale','state'=>$fav_communities[$i]->slug,'type_of'=>'commercial'));?>"></a>
               
                  <div class="thumb"><img class="img-fluid w100" src="<?php echo $this->app->apps->getBaseUrl('uploads/default/'.$fav_communities[$i]->icon);?>" alt="pc8.jpg"></div>
                  <div class="overlayyy">
                    <div class="details">
                      <h4><?php echo $fav_communities[$i]->state_name;?></h4>
                      <p><?php echo  $learn_more;?></p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-sm-12 col-md-12 col-lg-12 col-xl" style="padding: 0px;">
                   <?php $i= 2; ?>
                <div class="properti_city">
                        <a href="<?php echo $this->app->createUrl('listing/index',array('sec'=>'property-for-sale' ,'state'=>$fav_communities[$i]->slug,'type_of'=>'commercial'));?>"></a>
               
                  <div class="thumb"><img class="img-fluid w100" src="<?php echo $this->app->apps->getBaseUrl('uploads/default/'.$fav_communities[$i]->icon);?>" alt="pc8.jpg"></div>
                  <div class="overlayyy">
                    <div class="details">
                      <h4><?php echo $fav_communities[$i]->state_name;?></h4>
                      <p><?php echo  $learn_more;?></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-2 col-md-2 col-lg-2 col-xl propdfff no-pad-right-mob">
                 <?php $i= 3; ?>
              <div class="properti_city single-dic">
                 <a href="<?php echo $this->app->createUrl('listing/index',array('sec'=>'property-for-sale' ,'state'=>$fav_communities[$i]->slug,'type_of'=>'commercial'));?>"></a>
               
                <div class="thumb"><img class="img-fluid w100" src="<?php echo $this->app->apps->getBaseUrl('uploads/default/'.$fav_communities[$i]->icon);?>" alt="pc9.jpg"></div>
                <div class="overlayyy">
                  <div class="details">
                    <h4><?php echo $fav_communities[$i]->state_name;?></h4>
                    <p><?php echo  $learn_more;?></p>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-3 col-md-3 col-lg-3 col-xl propdfff mob-hide">
              <div class="col-sm-12 col-md-12 col-lg-12 col-xl" style="padding: 0px;">
                  <?php $i= 4; ?>
                <div class="properti_city">
                  <a href="<?php echo $this->app->createUrl('listing/index',array('sec'=>'property-for-sale' ,'state'=>$fav_communities[$i]->slug,'type_of'=>'commercial'));?>"></a>
               
                  <div class="thumb"><img class="img-fluid w100" src="<?php echo $this->app->apps->getBaseUrl('uploads/default/'.$fav_communities[$i]->icon);?>" alt="pc8.jpg"></div>
                  <div class="overlayyy">
                    <div class="details">
                      <h4><?php echo $fav_communities[$i]->state_name;?></h4>
                      <p><?php echo  $learn_more;?></p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-sm-12 col-md-12 col-lg-12 col-xl" style="padding: 0px;">
                <div class="properti_city">
                    <?php $i= 5; ?>
                    <a href="<?php echo $this->app->createUrl('listing/index',array('sec'=>'property-for-sale' ,'state'=>$fav_communities[$i]->slug,'type_of'=>'commercial'));?>"></a>
               
                  <div class="thumb"><img class="img-fluid w100" src="<?php echo $this->app->apps->getBaseUrl('uploads/default/'.$fav_communities[$i]->icon);?>" alt="pc8.jpg"></div>
                  <div class="overlayyy">
                    <div class="details">
                      <h4><?php echo $fav_communities[$i]->state_name;?></h4>
                      <p><?php echo  $learn_more;?></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-2 col-md-2 col-lg-2 col-xl propdfff mob-hide">
              <div class="properti_city single-dic">
                  <?php $i= 6; ?>
                  <a href="<?php echo $this->app->createUrl('listing/index',array('sec'=>'property-for-sale' ,'state'=>$fav_communities[$i]->slug,'type_of'=>'commercial'));?>"></a>
               
                <div class="thumb"><img class="img-fluid w100" src="<?php echo $this->app->apps->getBaseUrl('uploads/default/'.$fav_communities[$i]->icon);?>" alt="pc11.jpg"></div>
                <div class="overlayyy">
                  <div class="details">
                    <h4><?php echo $fav_communities[$i]->state_name;?></h4>
                    <p><?php echo  $learn_more;?></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
               <div class="row mob-d-flex spl-feat">
            
            <?php 
            for($i=7;$i<=10;$i++){ ?> 
            
            <div class="col-sm-3 col-md-3 col-lg-3 col-xl propdfff">
         
              <div class="properti_city  ">
                  <a href="<?php echo $this->app->createUrl('listing/index',array('sec'=>'property-for-sale','state'=>$fav_communities[$i]->slug,'type_of'=>'commercial'));?>"></a>
                <div class="thumb"><img class="img-fluid w100" src="<?php echo $this->app->apps->getBaseUrl('uploads/default/'.$fav_communities[$i]->icon);?>" alt="pc7.jpg"></div>
                <div class="overlayyy">
                  <div class="details">
                    <h4><?php echo $fav_communities[$i]->state_name;?></h4>
                    <p><?php echo  $learn_more;?></p>
                  </div>
                </div>
              </div>
            </div>
            <?php } ?> 
            </div>
          
        </div>
      </section>
      <?php 
if(!empty($latest)){ ?>
      <div class="section section-blog" style="padding: 40px 0;">
		  
		  <?php } ?>
		  
        <div class="container">
          <div class="row">
            <div class="col-lg-12 offset-lg-12">
              <div class="main-title text-center mb30">
                <h2><?php echo $widget['111'];?></h2>
              </div>
            </div>
            <div class="row">
              <div class="col col-sm-12">
                <div class="row row-news row-news-portrait">
					 <?php
		 foreach($latest as $v){
			  preg_match('/< *img[^>]*src *= *["\']?([^"\']*)/i', $v->content, $imges);
									 
									 
			  ?>
                  <div class="col col-sm-3">
                    <div class="card-news card-news-alt card-link taphover">
                      <div class="card-image" style="position:relative;">
                          <a href="<?php echo $this->app->createUrl('bloglist/details',array('slug'=>$v->slug));?>" style="position:absolute;left:0px;right:0px;top:0px;bottom:0px;z-index:1"></a>
                        <div class="full-block card-image-inner transition" style="background-image: url(<?php echo $v->generateImage(@$imges['1']);?>);"></div>
                      </div>
                      <div class="card-content">
                        <h3> <a href="<?php echo $this->app->createUrl('bloglist/details',array('slug'=>$v->slug));?>"><?php echo $v->title;?></a> </h3>
                      </div>
                    </div>
                  </div>
               
               <?php } ?> 
               </div>
              </div>
            </div>
          </div>
        </div>
      </div>
        <div class="section section-darkk section-selling" style="background-image: url(<?php echo $img;?>); padding-bottom: 40px;padding-top: 60px;margin-bottom: 60px; ">
        <div class="full-block page-banner-image skrollable skrollable-between" data-bottom-top="transform:translate3d(0px,0px,0px)" data-top-bottom="transform:translate3d(200px,0px,0px)" data-smooth-scrolling="off" style="background-image: url('<?php echo $img;?>'); transform: translate3d(121.889px, 0px, 0px);"></div>
        <div class="full-blockss overlayy"></div>
        <div class="container abount">
            <style>
              .abount   .fancy-title {  padding: 0px; } .abount p { text-align:justify;}
            </style>
        <?php echo Yii::t('app',$widget['107']);?>
         </div>
      </div> 
<style>
/* Slider */
section.customer-logos.slider.slick-initialized.slick-slider {
    background: transparent;
}
.slick-slide {
    margin: 0px 20px;
}

.slick-slide img {
    width: 100%;
}

.slick-slider
{
    position: relative;
    display: block;
    box-sizing: border-box;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
            user-select: none;
    -webkit-touch-callout: none;
    -khtml-user-select: none;
    -ms-touch-action: pan-y;
        touch-action: pan-y;
    -webkit-tap-highlight-color: transparent;
}

.slick-list
{
    position: relative;
    display: block;
    overflow: hidden;
    margin: 0;
    padding: 0;
}
.slick-list:focus
{
    outline: none;
}
.slick-list.dragging
{
    cursor: pointer;
    cursor: hand;
}

.slick-slider .slick-track,
.slick-slider .slick-list
{
    -webkit-transform: translate3d(0, 0, 0);
       -moz-transform: translate3d(0, 0, 0);
        -ms-transform: translate3d(0, 0, 0);
         -o-transform: translate3d(0, 0, 0);
            transform: translate3d(0, 0, 0);
}

.slick-track
{
    position: relative;
    top: 0;
    left: 0;
    display: block;
}
.slick-track:before,
.slick-track:after
{
    display: table;
    content: '';
}
.slick-track:after
{
    clear: both;
}
.slick-loading .slick-track
{
    visibility: hidden;
}

.slick-slide
{
    display: none;
    float: left;
    height: 100%;
    min-height: 1px;
}
[dir='rtl'] .slick-slide
{
    float: right;
}
.slick-slide img
{
    display: block;
}
.slick-slide.slick-loading img
{
    display: none;
}
.slick-slide.dragging img
{
    pointer-events: none;
}
.slick-initialized .slick-slide
{
    display: block;
}
.slick-loading .slick-slide
{
    visibility: hidden;
}
.slick-vertical .slick-slide
{
    display: block;
    height: auto;
    border: 1px solid transparent;
}
.slick-arrow.slick-hidden {
    display: none;
}
.customer-logos::before{ content:unset; }
.p-log-img {
    height: 50px;
    width: 100%;
    border: 1px solid #eee;
    border-radius: 8px;
}
.customer-logos.row { margin-left:-4px;margin-right:-4px;}.p-log-img img { width:100%;height:100%;object-fit:contain;object-psition:center;}
.customer-logos .divi-logo { padding-left:4px;padding-right:4px; margin-bottom:8px; max-width: 5.5%;;}
</style>
<div class="container">
 

              <div class="main-title text-center mb30">
                <?php echo $widget['117'];?>
              </div>

   <section class="customer-logos slider1 margin-bottom-40  padding-top-0 row">
      <?php 
		foreach ($partners as $partner) {
		?>
			<div class="col-sm-2 divi-logo"><div class="p-log-img"> <img data-src="<?php echo Yii::App()->apps->getBaseUrl('uploads/partners/'.$partner["image"]) ?>" class="lozad"></div></div>
		<?php } ?>
   </section>
</div>
  
    
    <?php $this->renderPartial('_footer_links');?>
     
    
      </div>
    
    
     
         
<div class="clearfix"></div>


 <div class="clearfix"></div>
 
<div class="clearfix"></div>
</div>


 <script> var featuredCount="2",total_show="4"; featureddevelopers(),featuredSliderhome(featuredCount,total_show),lozad().observe(), caroselSingle3(), activateVoxShadow2();
if(screen.width < 720){
$('#js-typeahead-user_v2,#js-typeahead-user_v21').attr('placeholder','<?php echo $this->tag->getTag('enter_city,_neighborhood','Enter City, Neighborhood');?>')
}

$(document).ready(function(){
    /*
    $('.customer-logos').slick({
        slidesToShow: 6,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1500,
        arrows: false,
        rtl:isRtl,
        dots: false,
        pauseOnHover: false,
        responsive: [{
            breakpoint: 768,
            settings: {
                slidesToShow: 4
            }
        }, {
            breakpoint: 520,
            settings: {
                slidesToShow: 3
            }
        }]
    });
    */
});
</script>
<?php 
$this->renderPartial('//listing/_arab_avenue_filter'); 
?> 



