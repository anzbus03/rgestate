<style> html {  overflow-x: auto !important; } </style>
<?php
	   $referer = $this->app->request->urlReferrer ;
	  
	   if( strpos( $referer, '/properties' ) !== false ) {
			$return_url = $_SERVER['HTTP_REFERER'];
		} 
		else{
			 if(in_array($model->section_id,array('new-development','property-for-sale','property-for-rent'))){
				  $return_url =  $this->app->createUrl($model->sec_slug).'/state/'.$model->state_slug;;
			 }
			 else{
				  $return_url =  $this->app->createUrl('listing/index').'/sec/'.$model->sec_slug.'/state/'.$model->state_slug;
			 }
		}
	  ?>
<div class="backgroundLowlight positionRelative" id="subNavContainer">
   <div class="pts lrgHidden mdHidden"></div>
   <div class="cols24 centerHorizontal pvxs" id="subNavContent">
      <div class="miniCol10 smlCol16 lrgCol19 pan">
         <div class="typeLowlight h7 man typeTruncate">
            <span class="typeEmphasize prm">
               <a href="<?php echo  $return_url; ?>" class="linkLowlight">
                  <span class="breadCrumbArrow mrs">
                     <svg id="iconLeftOpen" fill="currentColor" width="6px" height="10px" viewBox="0 0 6 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                        <g fill-rule="evenodd">
                           <g transform="translate(-4.000000, -1.000000)">
                              <g transform="translate(3.000000, 0.612500)">
                                 <path d="M3.503,10 C3.37,10 3.243,9.947 3.149,9.853 L-1.853,4.853 C-2.049,4.658 -2.049,4.342 -1.853,4.147 C-1.658,3.951 -1.342,3.951 -1.146,4.147 L3.503,8.793 L8.147,4.147 C8.342,3.951 8.658,3.951 8.854,4.147 C9.049,4.342 9.049,4.658 8.854,4.853 L3.857,9.853 C3.763,9.947 3.636,10 3.503,10" transform="translate(4.000000, 7.000000) rotate(-270.000000) translate(-4.000000, -7.000000) "></path>
                              </g>
                           </g>
                        </g>
                     </svg>
                  </span>
                  Back to Search
               </a>
            </span>
            <span class="miniHidden">(</span>
            <span class="miniHidden">
               <?php echo $model->section_name;?>
               <span class="breadCrumbArrow mhs">
                  <svg id="iconRightOpen" fill="currentColor" width="6px" height="10px" viewBox="0 0 6 11" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                     <g fill-rule="evenodd">
                        <g transform="translate(-5.000000, -2.000000)">
                           <g transform="translate(4.000000, 1.000000)">
                              <path d="M3.503,9 C3.37,9 3.243,8.947 3.149,8.853 L-1.853,3.853 C-2.049,3.658 -2.049,3.342 -1.853,3.147 C-1.658,2.951 -1.342,2.951 -1.146,3.147 L3.503,7.793 L8.147,3.147 C8.342,2.951 8.658,2.951 8.854,3.147 C9.049,3.342 9.049,3.658 8.854,3.853 L3.857,8.853 C3.763,8.947 3.636,9 3.503,9" transform="translate(4.000000, 6.000000) rotate(-90.000000) translate(-4.000000, -6.000000) "></path>
                           </g>
                        </g>
                     </g>
                  </svg>
               </span>
            </span>
            <span class="miniHidden">
               <a href="<?php echo $this->app->createUrl('listing/index').'/sec/'.$model->sec_slug.'/state/'.$model->state_slug;?>" class="linkLowlight"><?php echo $model->state_name;?></a>
               <span class="breadCrumbArrow mhs">
                  <svg id="iconRightOpen" fill="currentColor" width="6px" height="10px" viewBox="0 0 6 11" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                     <g fill-rule="evenodd">
                        <g transform="translate(-5.000000, -2.000000)">
                           <g transform="translate(4.000000, 1.000000)">
                              <path d="M3.503,9 C3.37,9 3.243,8.947 3.149,8.853 L-1.853,3.853 C-2.049,3.658 -2.049,3.342 -1.853,3.147 C-1.658,2.951 -1.342,2.951 -1.146,3.147 L3.503,7.793 L8.147,3.147 C8.342,2.951 8.658,2.951 8.854,3.147 C9.049,3.342 9.049,3.658 8.854,3.853 L3.857,8.853 C3.763,8.947 3.636,9 3.503,9" transform="translate(4.000000, 6.000000) rotate(-90.000000) translate(-4.000000, -6.000000) "></path>
                           </g>
                        </g>
                     </g>
                  </svg>
               </span>
            </span>
            <span class="miniHidden">
               
               <?php 
               if(!empty($model->community_name)){  ?> 
				   <a href="<?php echo $this->app->createUrl('listing/index').'/sec/'.$model->sec_slug.'/state/'.$model->state_slug.'/community/'.$model->community_id;?>" class="linkLowlight"><?php echo $model->community_name;?></a>
               <span class="breadCrumbArrow mhs">
                  <svg id="iconRightOpen" fill="currentColor" width="6px" height="10px" viewBox="0 0 6 11" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                     <g fill-rule="evenodd">
                        <g transform="translate(-5.000000, -2.000000)">
                           <g transform="translate(4.000000, 1.000000)">
                              <path d="M3.503,9 C3.37,9 3.243,8.947 3.149,8.853 L-1.853,3.853 C-2.049,3.658 -2.049,3.342 -1.853,3.147 C-1.658,2.951 -1.342,2.951 -1.146,3.147 L3.503,7.793 L8.147,3.147 C8.342,2.951 8.658,2.951 8.854,3.147 C9.049,3.342 9.049,3.658 8.854,3.853 L3.857,8.853 C3.763,8.947 3.636,9 3.503,9" transform="translate(4.000000, 6.000000) rotate(-90.000000) translate(-4.000000, -6.000000) "></path>
                           </g>
                        </g>
                     </g>
                  </svg>
               </span>
               <?php } ?>
            </span>
            <?php 
            if(!empty($model->category_name)){  ?> 
            <span class="miniHidden"><?php echo $model->category_name;?></span> <?php } ?>
            <span class="miniHidden">)</span>
         </div>
      </div>
      <div class="miniCol14 smlCol8 lrgCol5 pan">
         <div class="floatRight pvxs">
            <span data-role="coShoppingContainer">
               <span data-reactroot="">
                  <span class="mrxs">
                     <div style="display: inherit;"><button data-test-id="PDPSaveButton" id="fav_button_<?php echo $model->id;?>"  class="phl btn btnSml btnDefault phmXxsVisible <?php echo !empty($model->fav) ?  'active' : '';?> "  onclick="<?php if($this->app->user->getId()){ echo 'savetofavourite(this)'; }else{ echo 'OpenSignUp(this)';}?>" data-function="save_favourite" data-id="<?php echo $model->primaryKey;?>"  data-after="saved_fave"  ><?php if(!empty($model->fav) ){ echo '<i class="iconHeart" ></i>'; } else{ echo '<i class="iconHeartEmpty" ></i>';} ?><span class="">Save</span>   </button>
                     </div>
                  </span>
                  <span><button id="PDPShareButton" class="iconMail phl btn btnSml btnDefault phmXxsVisible" onclick="$('#share_widget').toggle();" ><span class="">Share</span>
                  </button>
                  <div style="position:relative;">
                  <div class="a2a_kit a2a_kit_size_32 a2a_floating_style a2a_vertical_style"  id="share_widget" style="right: 0px; top: 0px; line-height: 32px; position: absolute; background: #fff; text-align: center; margin: auto; box-shadow: 0 2px 2px 0 rgba(0,0,0,0.16),0 0 0 1px rgba(0,0,0,0.08);;display:none;">
    <a class="a2a_button_google_plus"></a>
    <a class="a2a_button_facebook"></a>
    <a class="a2a_button_twitter"></a>
    
</div>
</div>
<script async src="https://static.addtoany.com/menu/page.js"></script>

 
                  </span>
               </span>
            </span>
         </div>
      </div>
   </div>
   <div class="pts lrgHidden mdHidden"></div>
</div>
<div id="propertySummary" class="positionRelative zIndexExpandingAd backgroundBasic cols24 summaryContainer">
   <div class="centerHorizontal cols24 summaryContent">
      <div class="row man positionRelative pamXxsVisible pvlSmlVisible phlMdVisible pvm phn">
         <div class="xsCol24 smlCol24 mdCol16 lrgCol16 phn">
            <div>
               <h1 class="h3 defaultLineHeight" style="display: inline;">
                  <div class="pan man defaultLineHeight" data-role="address">
                     <?php echo $model->ad_title;?>
                  </div>
                  <span class="h6 typeWeightNormal pts typeLowlight paXxsHidden maXxsHidden" data-role="cityState">
                 <?php echo $model->LocationTitle;?>
                  </span>
               </h1>
               
            </div>
            <ul class="listInlineBulleted man pts ptXxsHidden pbsXxsVisible">
                <?php
				if(!empty($model->bedrooms)){ ?> 
               <li><?php echo $model->bedrooms;?> beds</li>
               <?php } ?> 
                 <?php
				if(!empty($model->bathrooms)){ ?>
               <li class="type"><?php echo $model->bathrooms;?> bath</li>
               <?php } ?>
                <?php
				if(!empty($model->builtup_area)){ ?>
               <li><?php echo $model->BuiltUpAreaTitle;?>  </li>
               <?php } ?> 
            </ul>
         </div>
         <div class="xsCol24 smlCol24 mdCol8 lrgCol8 pan ptxsXxsVisible ptlSmlVisible">
            <div class="man">
               <div class="miniHidden xxsHidden">
                  <div class="typeLowlight typeEmphasize mvn h6">
                     <span class="typeCaps"><?php echo $model->section_name;?></span>
                  </div>
               </div>
               <div class="mvn">
                  <span class="h3" data-role="price">
                  <?php echo $model->PriceTitleSpan;?>
                  </span>
                  <?php /*
                  <i class="h3 iconDown"></i>
                  <span id="priceChangeTooltip">
                     <span data-reactroot="" style="position: relative; display: inline-block;">
                        <span style="display: inline-block;">
                           <p class="typeStrikethrough">375,000</p>
                        </span>
                     </span>
                  </span>
                  * */ ?> 
               </div>
              
            </div>
         </div>
         <?php 
         if(!empty($model->user_image)){ 
		  $image = $this->app->apps->getBaseUrl('uploads/images/'.$model->user_image);?>
         <div id="providerLogo" class="man ptm"><img src="<?php echo $this->app->apps->getBaseUrl('timthumb.php');?>?src=<?php   echo  $image   ;?>&h=50&w=120&zc=1"></div>
         <?php } ?>
      </div>
   </div>
</div>
 
<div class="span_back_009">
   <div class="container" style="padding: 0px;">
      <div class="row margin-bottom-50">
         <div class="col-md-12">
            <!-- Slider -->
           <?php 
            $images = $model->all_images();
            if($images){ ?>
            <div class="property-slider default spanwth">
				<?php 
				foreach($images as $image){
					$image_url = $this->app->apps->getBaseUrl('timthumb.php').'?src='.$this->app->apps->getBaseUrl('uploads/images/'.$image->image_name).'&h=553&w=864&zc=1' ;	
			
				?>
               <a href="<?php echo $image_url;?>" data-background-image="<?php echo $image_url;?>" class="item mfp-gallery"></a> 
               <?php } ?>
            </div>
            <?php } ?> 
           <?php $this->renderPartial('_right_contact_form');?>
            <!-- Slider Thumbs -->
			 <?php 
			 ;
			if(!empty($images) and sizeOf($images)>1 ){ ?>
			<div class="property-slider-nav">
			<?php 
			foreach($images as $image){
				$image_url = $this->app->apps->getBaseUrl('timthumb.php').'?src='.$this->app->apps->getBaseUrl('uploads/images/'.$image->image_name).'&h=122&w=184&zc=1' ;	
			
			?>
			 <div class="item"><img src="<?php echo $image_url;?>" alt=""></div>   
			<?php } ?>
			</div>
			<?php } ?> 
         </div>
      </div>
   </div>
</div>
<div class="container">
   <div class="row">
      <div class="col-lg-9" style="padding-left: 0px;">
         <div class="miniCol24 xsCol24 smlCol24 mhn phn spantopmar50">
            <h3 class="h3 mtn">Property Details</h3>
            <div class="bbs mbl homeDetailsHeading">
               <span class="h5 prm backgroundBasic">Overview</span>
            </div>
		
		<?php $this->renderPartial('_common_details');?>
		
		<?php
        if(!empty($floor )){ ?>
           <div class="bbs mbl homeDetailsHeading">
               <span class="h5 prm backgroundBasic">Floor Plan</span>
            </div>
            <div  class="mbl pbm">
				 	<ul class="man">
                 	<?php
						foreach($floor as $k=>$v){ ?> 
                      
                            <li>
								<?php
								$file = $this->app->apps->getBaseUrl('uploads/floor_plan/'.$v->floor_file);
								?>
                                <h4><div style="width:calc(100%- 100px);float:left"></div><?php echo $v->floor_title;?><div style="width:100px;float:right"><a href="<?php echo $file;?>" target="_blank">View</a></a></div></h4>
                            </li>
                       
                        <?php } ?>
                         </ul> 
            </div>
            <?php } ?> 
            
           <div class="bbs mbl homeDetailsHeading">
               <span class="h5 prm backgroundBasic">Map</span>
            </div>
            <div id="descriptionContainer" class="mbl pbm">
                 <?php $this->renderPartial('_detail_map_view');?>
            </div>
         </div>
      </div>
     
      <div class="col-lg-3 spantopmar50" style="padding-right: 0px;">
		<?php
		$banner = Banner::model()->detail_baaner();
		if($banner){ ?>
			<a href="<?php echo $banner->link_url;?>" target="_blank">
			<img src="<?php echo $this->app->apps->getBaseUrl('uploads/banner/'.$banner->image);?>" style="width:<?php echo $banner->banner_width ;?>px" />
			</a> 
		<?php } ?>
		  </div>
      <div class="clearfix"></div>

      <div class="clearfix"></div>
      <?php $this->renderPartial('_contact_form_bottom');?>
      <div id="map_locator">
      <?php $this->renderPartial('_safe_neighbours');?>
      <?php $this->renderPartial('_new_listing');?>
      </div>
  </div>
</div>

