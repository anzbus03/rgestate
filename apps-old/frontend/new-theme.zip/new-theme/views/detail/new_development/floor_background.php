<div id="floor-plans" class="mid-level-padding" data-type="background" data-speed="10">
    <div class="container">
        <div class="row">
            <div class="col-xs-12  wow fadeInRight  ">
                <h2 class="text-center">Floor Plans</h2>
                <div id="owl-slider" class="owl-carousel owl-theme">
                    <div class="item text-center">
                        
                        <p class="p-margin"><b>Rawda apartments are tailored to fit your needs.</b> <br>Every single architectural design is carefully planned for you to enjoy everything about your new home.</p>
                        <div class="left-section"><a class="btn button" href="#">View More</a> </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>

</div>

