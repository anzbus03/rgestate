                <?php $this->renderPartial('//forms/_success_html_insurance');?>
                <link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->apps->getBaseUrl('assets/css/jui-bs/jquery-ui-1.10.3.custom.css');?>" />
                 
             
               <script src="https://code.jquery.com/ui/1.11.2/jquery-ui.min.js"></script>
                <style>
             #cn_property{padding:0!important;overflow:hidden}html input.input-text.form-control,html select.input-text.form-control,input.pwdfield{border:1px solid #dfe0e3;border-radius:3px;color:#72727d;font:13px arial;height:24px;padding:1px 0;width:100%; }html textarea.input-text.form-control{border:1px solid #dfe0e3;line-height:1.4;padding:10px 8px;color:#72727d;font:13px arial}.sign-in-form label{margin-bottom:0}.sign-in-form .btn.btn-primary{background-color:var(--logo-color);box-shadow:unset;border:0;font-family:Lato,Helvetica,Arial,sans-serif;font-size:14px;color:#fff;line-height:40px;border-radius:5px}.btn-sm-s{max-width:100%!important;line-height:35px!important;padding:0}.col-sm-5 label{color:#72727d!important;line-height:1;text-align:right}html .container_check input:checked~.checkmark{background-color:#90ee90;border:1px solid transparent}.container_check input:checked~.checkmark{background-color:#dc143c;border:1px solid transparent}.container_check .checkmark{position:absolute;top:0;left:0;height:20px;width:20px;-webkit-border-radius:3px;-moz-border-radius:3px;-ms-border-radius:3px;border-radius:3px;-moz-transition:all .3s ease-in-out;-o-transition:all .3s ease-in-out;-webkit-transition:all .3s ease-in-out;-ms-transition:all .3s ease-in-out;transition:all .3s ease-in-out}.container_check input:checked~.checkmark::after{display:block}.container_check .checkmark::after{content:"";position:absolute;display:none;left:7px;top:3px;width:5px;height:10px;border:solid #fff;border-top-width:medium;border-right-width:medium;border-bottom-width:medium;border-left-width:medium;border-top-width:medium;border-right-width:medium;border-bottom-width:medium;border-left-width:medium;border-width:0 2px 2px 0;-webkit-transform:rotate(45deg);-ms-transform:rotate(45deg);transform:rotate(45deg)}#frm_ctnt .errorMessage{font-size:12px;color:#e13009!important;padding:2px 0 0;top:unset!important}.grecaptcha-badge{z-index:999911119999!important}
                .success-modal .info .title {
    font-weight: var(--weight-800);
    margin: 0;
    line-height: 1.42857143;
    color: #333;
    font-weight: 600 !important;
    font-size: 18px;
} .form-control.LJB {
    border-color: #ddd;
    appearance: none;
    border-radius: 16px;
    border-style: solid;
    border-width: 2px;
    line-height: 36px;
    min-height: 48px;
    width: 100%;
    text-indent: 18px;
    font-size: 16px !important;
}
html textarea.input-text.form-control {
border-color: #ddd;
appearance: none;
border-radius: 16px;
border-style: solid;
border-width: 2px;
line-height: 36px;
min-height: 48px;
width: 100%;
text-indent: 18px;
font-size: 16px !important;
}.radio-toolbar input[type="radio"] {
  display: none;
}

.radio-toolbar label {
  display: inline-block;
  background-color: #fff;
  border:1px solid #7f7f7f;
  border-radius:5px; 
  padding:  5px 15px;
   
  font-size: 16px;
  cursor: pointer;
  color: var(--black-color);
  height: 60px;
display: flex;
justify-content: flex-start;
align-items: center;
background-color: #fff;
color: #7f7f7f;
font-size: 14px;
cursor: pointer;
line-height: 1.43;
transition: all .3s ease-in-out;
margin-bottom:10px !important;
width:calc(50% - 20px);
box-shadow: 0 1px 3px 0 rgba(0,0,0,.06);border: 1px solid #dfe0e3;
}.radio-toolbar.smalln label { width:width:calc(33.3333%- 30px);; text-align:center; } 
.radio-toolbar label svg { width:42px;  height:42px; margin-right:5px;}
.radio-toolbar input[type="radio"]:checked+label {
  background-color:var(--secondary-color); color:#fff !important; 
}
.radio-toolbar label span { width:calc(100% - 42px); line-height:1.2;}
.radio-toolbar label {
    
    float: left;
    margin-right: 10px;
    line-height:1.5;
}.property-typ1 { max-width:150px;}
.tabset > input:checked + label{ background-color:var(--secondary-color) !important;color:#fff !important;  }
.tabset > input:checked + label a{  color:#fff !important;  }
.tab-panel {
    
    border-top: 1px solid var(--secondary-color);
}
.tab-panels .col-sm-5{width:100%;min-width:100%;order:1; }
.tab-panels  .col-sm-7{width:100%; min-width:100%;order:2; }
.tab-panels  #ListingUsers_password input,.tab-panels  #signUpForm .form-control.LJB,.tab-panels  #signin-form input.form-control.LJB,.tab-panels  #signin-form select.form-control.LJB{
	max-width:100%; 
	}
	label.head { font-weight:600;    font-weight: 600;
    margin-bottom: 7px !important;}
	#Lonsdale_s_date ,#Lonsdale_e_date  {
		border-color: #ddd;
    appearance: none;
    border-radius: 16px;
    border-style: solid;
    border-width: 2px;
    line-height: 36px;
    min-height: 48px;
    width: 100%;
    text-indent: 18px;
    font-size: 16px!important;  height: 39px;   min-height: 39px;
	}
 
 .sign-in-form label {
    line-height: 1.5;
}hr{ margin-top:0px;    margin-bottom: 15px;
    border-color: #999;; }
 .inp-amunt-cls{ max-width:180px !important;}

  .radio-toolbar input[type="radio"]:checked+label { 
    color: #fff !important; 
}.radio-toolbar label{ height:36px;}
 .slp-order-dflex { display:flex; flex-direction:column;} .slp-order-dflex .col-sm-5{ margin-bottom:30px; }
 @media only screen and (min-width: 1024px) {
 	 label[for="Lonsdale_phone"], label[for="Lonsdale_fax"]{ display:none;  top: -3px;    position: absolute;    z-index: 1;    left: 22px;    bottom: 10px; }
  
.iti__flag {
    background: url('https://www.arabavenue.com/assets/img/call.png') !important;
    width: 24px !important;
    height: 24px !important;
    border: 0px !important;
    box-shadow: unset !important;
}.iti__flag {  background: url('https://www.arabavenue.com/assets/img/call.png') !important; }.fax .iti__flag {  background: url('https://www.arabavenue.com/assets/img/fax2.png') !important; } 
}
                </style>
                 <script>
                     function ajaxSubmitHappenlistn(e,t,i,a){i?alert("error"):$.ajax({type:"POST",url:a,data:e.serialize(),success:function(e){var t;e=JSON.parse(e);$("#requestBtn").length>0&&(void 0!==(t=$("#requestBtn").attr("data-html"))&&($("#requestBtn").attr("disabled",!1),$("#requestBtn").html(t)));$("#bb2").length>0&&(void 0!==(t=$("#bb2").attr("data-html"))&&($("#bb2").attr("disabled",!1),$("#bb2").html(t)));"1"==e.status?($("#topThirdPlacementLeadFormContainer").hide(),	 $("html, body").animate({    scrollTop: $("#WERWER").offset().top}, 1000), $(".rms-data-h").addClass("hide"),$(".success-modal").addClass("visible"),Moveit.put(popGroup,{start:"0%",end:"0%",visibility:0}),Moveit.put(tick,{start:"0%",end:"0%",visibility:0}),Moveit.put(tick2,{start:"0%",end:"0%",visibility:0}),Moveit.put(circle,{start:"0%",end:"0%",visibility:0}),Moveit.animate(circle,{visibility:1,start:"0%",end:"100%",duration:1,delay:0,timing:"ease-out"}),Moveit.animate(tick,{visibility:1,start:"0%",end:"100%",duration:.2,delay:.5,timing:"ease-out"}),Moveit.animate(tick2,{visibility:1,start:"0%",end:"80%",duration:.2,delay:.7,timing:"ease-out"}),Moveit.animate(popGroup,{visibility:1,start:"20%",end:"60%",duration:.2,delay:1,timing:"ease-in"}).animate(popGroup,{visibility:1,start:"100%",end:"100%",duration:.2,delay:1.2,timing:"ease-in-out"})):($("#msg_alert").html(e.msg).show(),setTimeout(function(){$("#msg_alert").hide()},7e3))}})}
                     
                 </script>
               <div id="topThirdPlacementLeadFormContainer" class="pan plm rms-data-h">
               <div class="backgroundBasic sign-in-form   " id="topPanelLeadFormContainer">
                     <div data-reactroot="" class="pvn clearfix">
                        <div class="false"  >
							      
						   <?php
						   $model = new Lonsdale();
						   $mainTex = $this->tag->getTag('get_a_quote', 'GET A QUOTE' ); 
						      $Validating = $this->tag->getTag('validating','Validating..');
	$please_wait = $this->tag->getTag('please_wait','Please wait..');
							$form = $this->beginWidget('CActiveForm', array(
							'id'=>'signin-form',
							'action'=>Yii::app()->createUrl('forms/validateInsurance2'),
							'enableAjaxValidation'=>true,
							'clientOptions'=>array(
							'validateOnSubmit'=>true,'validateOnChange'=>false,
							'beforeValidate' => 'js:function(form) {

							form.find("#bb2").html("'.$Validating .'");
							return true;
							}',
							'afterValidate' => 'js:function(form, data, hasError) { 
							if(hasError) {
									  $("html, body").animate({
        scrollTop: form.find(".errorMessage:visible:first").offset().top-50
    }, 2000);
							form.find("#bb2").html("'.$mainTex.'");
							return false;
							}
							else
							{
							form.find("#bb2").val("'. $please_wait.'"); 
				
							ajaxSubmitHappenlistn(form, data, hasError,"'.Yii::app()->createUrl('forms/SendInsurance2').'"); 
						
							}
							}',
							),
							'htmlOptions'=>array('class'=>'form leadContact right_leadContact phs recapt','style'=>'margin-top: 5px;' ),
							));
							?>
                            <style>
                            img.ag{max-width:110px!important;max-height:50px!important;margin-bottom:0;margin-left:auto;text-align:center;margin-right:auto;display:block}.ptn.man.kw-agent-info__agentItem___2iGT_.h7{font-weight:700;line-height:20px;display:flex}.ptn.man.kw-agent-info__agentItem___2iGT_.h7 span{margin-right:10px;font-weight:400;display:inline-block;max-width:90px;overflow:hidden;white-space:nowrap;min-width:90px;font-size:11px}
                            .ptn.man.kw-agent-info__agentItem___2iGT_.h7 { line-height:25px;}
                            </style>
                           
                              
													<div class="clearfix"></div>
													 <div class="clearfix"></div>
												 
												 	<div class="clearfix"></div>
												 	
								<div class="row">
									<div class="col-sm-8">
											<div class="form-group  ">

		<div class="row">


		<div class="col-sm-12">
													<?php  	
													$model->bank_id = $activeModel->primaryKey;
											 
												  	echo $form->hiddenField($model , 'bank_id');  ?>
		<?php  	echo $form->textField($model , 'f_name' ,  $model->getHtmlOptions('f_name',array('class'=>'input-text form-control LJB')));  ?>

		<?php echo $form->error($model, 'f_name');?>


		</div>

		</div>
		</div> 
		<div class="clearfix"></div>

		<div class="form-group  ">
		<div class="row">
		<div class="col-sm-12">
		<?php  	
		echo $form->textField($model , 'address' ,  $model->getHtmlOptions('address',array('class'=>'input-text form-control LJB'  )));  ?>
		<?php echo $form->error($model, 'address');?>
		</div>
		</div>
		</div> 

		<div class="clearfix"></div>
		<div class="form-group  ">

		<div class="row">


		<div class="col-sm-12">

		<?php  	echo $form->textField($model , 'cr_no' ,  $model->getHtmlOptions('cr_no',array('class'=>'input-text form-control LJB'  )));  ?>

		<?php echo $form->error($model, 'cr_no');?>


		</div>

		</div>
		</div> 
		<div class="clearfix"></div>
<div class="clearfix"></div>
		<div class="form-group  ">

		<div class="row">


		<div class="col-sm-12">

		<?php  	echo $form->textField($model , 't_o_b' ,  $model->getHtmlOptions('t_o_b',array('class'=>'input-text form-control LJB'  )));  ?>

		<?php echo $form->error($model, 't_o_b');?>


		</div>

		</div>
		</div> 
									</div>
									<div class="col-sm-4">
									
									
														<div>
									
									
														<label for="Lonsdale_s_date"><?php echo $this->tag->getTag('period_of_insurance','Period of Insurance');?></label>
														<div class="row">
															<div class="col-sm-6">
														<?php
														$model->s_date = !empty($model->s_date) ? date('d-m-Y',strtotime($model->s_date)) : ''; 
														$this->widget('zii.widgets.jui.CJuiDatePicker',array(
														'model'     => $model,
														'attribute' => 's_date',
														'language'  => 'en',
														'cssFile'   => null,
														'options'   => array(
														'showAnim'      => 'fold',
														'dateFormat'    => 'dd-mm-yy',
														),
														'htmlOptions'=>$model->getHtmlOptions('s_date',array('autocomplete'=>'off')),
														));
														?>
														</div>
														<div class="col-sm-6">
														<?php
														$model->e_date = !empty($model->e_date) ? date('d-m-Y',strtotime($model->e_date)) : ''; 
														$this->widget('zii.widgets.jui.CJuiDatePicker',array(
														'model'     => $model,
														'attribute' => 'e_date',
														'language'  => 'en',
														'cssFile'   => null,
														'options'   => array(
														'showAnim'      => 'fold',
														'dateFormat'    => 'dd-mm-yy',
														),
														'htmlOptions'=>$model->getHtmlOptions('e_date',array('autocomplete'=>'off')),
														));
														?>
														</div>
														</div>
														<?php echo $form->error($model, 's_date');?>
														
														<div class="clearfix"></div>
														<small class="pull-right"><?php echo $this->tag->getTag('(both_days_inclusive)','(Both days inclusive)');?></small>
														</div>
														<div class="clearfix"></div>
														<div class="row margin-top-35">
															<div class="col-sm-12">
																 <?php echo $form->labelEx($model, 'phone');?>
																<div class="form-group  ">

						    <div class="row">


							<div class="col-sm-12 phndd" dir="ltr">
<style>.iti.iti--allow-dropdown input { margin-right:0px !important; }.iti{ width:100%; }html[dir="rtl"] .phndd { max-width:460px;float:right}</style>
							<?php  	echo $form->textField($model , 'phone_false' ,  $model->getHtmlOptions('phone_false',array('class'=>'input-text form-control LJB','placeholder'=>'', 'oninput'=>"this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"  )));  ?>

							<?php echo $form->error($model, 'phone_false');?>
							

							</div>

							

							</div>
		</div>
															
															</div>
															<div class="col-sm-12 fax">
																 <?php echo $form->labelEx($model, 'fax');?>
																<div class="form-group  ">

						    <div class="row">


						<div class="col-sm-12 phndd" dir="ltr">
<style>.iti.iti--allow-dropdown input { margin-right:0px !important; }.iti{ width:100%; }html[dir="rtl"] .phndd { max-width:460px;float:right}</style>
							<?php  	echo $form->textField($model , 'fax_false' ,  $model->getHtmlOptions('fax_false',array('class'=>'input-text form-control LJB','placeholder'=>'', 'oninput'=>"this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"  )));  ?>

							<?php echo $form->error($model, 'fax_false');?>
							

							</div>

							</div>
		</div>
															
															</div>
															
														</div>
														
									</div>	
																		
													
								 
								</div>	
								
								<hr />
									<div class="row">
											<div class="col-sm-8">
												<div class="form-group  ">
													<div class="row">
														<div class="col-sm-12">
														<?php  	echo $form->textField($model , 'location' ,  $model->getHtmlOptions('location',array('class'=>'input-text form-control LJB')));  ?>
														<?php echo $form->error($model, 'location');?>
														</div>
													</div>
												</div> 
											</div>
									</div>         
                                <div class="clearfix"></div>
								<hr />
									<div class="row">
											<div class="col-sm-8">
												<div class="form-group  ">
													<div class="row">
														<div class="col-sm-12">
														<?php  	echo $form->textField($model , 'd_of_p' ,  $model->getHtmlOptions('d_of_p',array('class'=>'input-text form-control LJB')));  ?>
														<?php echo $form->error($model, 'd_of_p');?>
														</div>
													</div>
												</div> 
											</div>
									</div>         
                                <div class="clearfix"></div>
								<hr />
									<div class="row">
											<div class="col-sm-12">
												<div class="form-group  ">
													
													<div class="row">
														<div class="col-sm-6">
														 <?php echo $form->labelEx($model, 's_i');?>
														</div>
														<div class="col-sm-6">
														<?php  	echo $form->textField($model , 's_i' ,  $model->getHtmlOptions('s_i',array('class'=>'inp-amunt-cls input-text form-control LJB','placeholder'=>'')));  ?>
														<?php echo $form->error($model, 's_i');?>
														</div>
													</div>
											
												</div> 
											</div>
											<div class="col-sm-12">
												<div class="form-group  ">
													
													<div class="row">
														<div class="col-sm-6">
														 <?php echo $form->labelEx($model, 'plant');?>
														</div>
														<div class="col-sm-6">
														<?php  	echo $form->textField($model , 'plant' ,  $model->getHtmlOptions('plant',array('class'=>'inp-amunt-cls input-text form-control LJB','placeholder'=>'')));  ?>
														<?php echo $form->error($model, 'plant');?>
														</div>
													</div>
											
												</div> 
											</div>
											<div class="col-sm-12">
												<div class="form-group  ">
													
													<div class="row">
														<div class="col-sm-6">
														 <?php echo $form->labelEx($model, 'stock_material');?>
														</div>
														<div class="col-sm-6">
														<?php  	echo $form->textField($model , 'stock_material' ,  $model->getHtmlOptions('stock_material',array('class'=>'inp-amunt-cls input-text form-control LJB','placeholder'=>'')));  ?>
														<?php echo $form->error($model, 'stock_material');?>
														</div>
													</div>
											
												</div> 
											</div>
									
														<div class="col-sm-12">
												<div class="form-group  ">
													
													<div class="row">
														<div class="col-sm-6">
														 <?php echo $form->labelEx($model, 'rent_value');?>
														</div>
														<div class="col-sm-6">
															<div class="row">
																<div class="col-sm-6">
																<?php  	echo $form->textField($model , 'rent_value' ,  $model->getHtmlOptions('rent_value',array('class'=>'input-text form-control LJB','placeholder'=>'')));  ?>
																<?php echo $form->error($model, 'rent_value');?>
																</div>
																<div class="col-sm-6">
																	<div class="row">
																		<div class="col-sm-12">
																		<?php  	echo $form->textField($model , 'rent_pay_month' ,  $model->getHtmlOptions('rent_pay_month',array('class'=>'input-text form-control LJB' )));  ?>
																		<?php echo $form->error($model, 'rent_pay_month');?>
																		</div>
																	 
																</div>
																</div>
														</div>
														
														</div>
													</div>
											
												</div> 
											</div>
									
									<div class="col-sm-12">
												<div class="form-group  ">
													
													<div class="row">
														<div class="col-sm-6">
														 <?php echo $form->labelEx($model, 'other_property');?>
														</div>
														<div class="col-sm-6">
														<?php  	echo $form->textField($model , 'other_property' ,  $model->getHtmlOptions('other_property',array('class'=>'inp-amunt-cls input-text form-control LJB','placeholder'=>'')));  ?>
														<?php echo $form->error($model, 'other_property');?>
														</div>
													</div>
											
												</div> 
											</div>
									
									<div class="col-sm-12">
												<div class="form-group  ">
													
													<div class="row">
														<div class="col-sm-6">
														 <?php echo $form->labelEx($model, 'total_sr');?>
														</div>
														<div class="col-sm-6">
														<?php  	echo $form->textField($model , 'total_sr' ,  $model->getHtmlOptions('total_sr',array('class'=>'inp-amunt-cls input-text form-control LJB','placeholder'=>'')));  ?>
														<?php echo $form->error($model, 'total_sr');?>
														</div>
													</div>
											
												</div> 
											</div>
									
									</div>         
                                <hr />
                                <div class="row">
                                	<div class="col-sm-12">
												<div class="form-group  ">
													
													<div class="row">
														<div class="col-sm-6">
														 <?php echo $form->labelEx($model, 'insured_represent');?>
														</div>
														<div class="col-sm-6">		<?php $id = 'insured_represent'; ?> 
																<div class="radio-toolbar smalln property-typ1">
																	
													<?php $property_type_Array = array('Y'=>$this->tag->getTag('yes','Yes'), 'N'=>$this->tag->getTag('no','No'));
													foreach($property_type_Array as $k=>$v){ 
														$checked ='';if($k==$model->$id){ $checked = 'checked' ;}
														?> 
													<input type="radio" id="<?php echo $id;?>_<?php echo $k;?>" <?php echo $checked;?> onchange="setCheckox('<?php echo $id;?>',this)" name="<?php echo $id;?>" value="<?php echo $k;?>"  >
													<label for="<?php echo $id;?>_<?php echo $k;?>">
													 
													
													<?php echo $v;?></label>
													<?php } ?>  
													</div>
														<div class="clearfix"></div>
															
															<?php echo $form->hiddenField($model,$id);?>
															
													 <?php echo $form->error($model, 'insured_represent');?>
														</div>
													</div>
											
												</div> 
											</div>
										
                                
                                	<div class="col-sm-12">
												<div class="form-group  ">
													
													<div class="row">
														<div class="col-sm-6">
														 <?php echo $form->labelEx($model, 'n_rplaced');?>
														</div>
														<div class="col-sm-6">
														<?php  	echo $form->textField($model , 'n_rplaced' ,  $model->getHtmlOptions('n_rplaced',array('class'=>'inp-amunt-cls input-text form-control LJB','placeholder'=>'')));  ?>
														<?php echo $form->error($model, 'n_rplaced');?>
														</div>
													</div>
											
												</div> 
											</div>
                                	<div class="col-sm-12">
												<div class="form-group  ">
													
													<div class="row">
														<div class="col-sm-6">
														 <?php echo $form->labelEx($model, 'd_v');?>
														</div>
														<div class="col-sm-6">
														<?php  	echo $form->textField($model , 'd_v' ,  $model->getHtmlOptions('d_v',array('class'=>'inp-amunt-cls input-text form-control LJB','placeholder'=>'')));  ?>
														<?php echo $form->error($model, 'd_v');?>
														</div>
													</div>
											
												</div> 
											</div>
										<div class="col-sm-12"><?php echo $this->tag->getTag('(new_replacement_value_is_not_','(New Replacement Value is not Applicable to Stock)');?></div>
                                
                                
                                </div>
                                 <hr />
                                 <div class="row">
									 <div class="col-sm-12">
                                 <label class="head"><?php echo $this->tag->getTag('give_the_building_construction','Give the Building Construction Details');?></label>
                                 </div>
                                 <div class="col-sm-6">
												<div class="form-group  ">
													<div class="row">
														<div class="col-sm-12">
														<?php  	echo $form->textField($model , 'i_w' ,  $model->getHtmlOptions('i_w',array('class'=>'input-text form-control LJB')));  ?>
														<?php echo $form->error($model, 'i_w');?>
														</div>
													</div>
												</div> 
                                 </div>
                                 <div class="col-sm-6">
												<div class="form-group  ">
													<div class="row">
														<div class="col-sm-12">
														<?php  	echo $form->textField($model , 'e_w' ,  $model->getHtmlOptions('e_w',array('class'=>'input-text form-control LJB')));  ?>
														<?php echo $form->error($model, 'e_w');?>
														</div>
													</div>
												</div> 
                                 
                                 </div>
                                 <div class="clearfix"></div>
                                 <div class="col-sm-6">
											<div class="form-group  ">
													<div class="row">
														<div class="col-sm-12">
														<?php  	echo $form->textField($model , 'storeys' ,  $model->getHtmlOptions('storeys',array('class'=>'input-text form-control LJB')));  ?>
														<?php echo $form->error($model, 'storeys');?>
														</div>
													</div>
												</div> 
                                 
                                 </div>
                                 <div class="col-sm-6">
                                 <div class="form-group  ">
													<div class="row">
														<div class="col-sm-12">
														<?php  	echo $form->textField($model , 'roof' ,  $model->getHtmlOptions('roof',array('class'=>'input-text form-control LJB')));  ?>
														<?php echo $form->error($model, 'roof');?>
														</div>
													</div>
												</div> 
                                 
                                 </div>
                                 <div class="clearfix"></div>
                                 
                                  <div class="col-sm-6">
												<div class="form-group  ">
													<div class="row">
														<div class="col-sm-12">
														<?php  	echo $form->textField($model , 'basement' ,  $model->getHtmlOptions('basement',array('class'=>'input-text form-control LJB')));  ?>
														<?php echo $form->error($model, 'basement');?>
														</div>
													</div>
												</div> 
                                 
                                 </div>
                                 
                                  <div class="col-sm-6">
												<div class="form-group  ">
													<div class="row">
														<div class="col-sm-12">
														<?php  	echo $form->textField($model , 'floors' ,  $model->getHtmlOptions('floors',array('class'=>'input-text form-control LJB')));  ?>
														<?php echo $form->error($model, 'floors');?>
														</div>
													</div>
												</div> 
                                 
                                 </div>
                                 
                                 <div class="clearfix"></div>
                                 
                                 </div>
                                 
                                   <hr />
                                 <div class="row">
											<div class="col-sm-12">
											<label class="head"><?php echo $this->tag->getTag('describe_the_nature_of_your_st','Describe the Nature of Your Stock in the');?></label>
											</div>
										 <div class="form-group  ">
														<div class="col-sm-6">
														 <?php echo $form->labelEx($model, 'p_e_b');?>
														</div>
														<div class="col-sm-6">
															<div class="row">
																<div class="col-sm-6">
																<?php  	echo $form->textField($model , 'p_e_b' ,  $model->getHtmlOptions('p_e_b',array('class'=>'input-text form-control LJB','placeholder'=>'')));  ?>
																<?php echo $form->error($model, 'p_e_b');?>
																</div>
													 	</div>
														
														</div>
													<div class="clearfix"></div>
												</div>		
														<div class="clearfix"></div>
															 <div class="form-group  ">
												 <div class="col-sm-6">
														 <?php echo $form->labelEx($model, 'b_if');?>
														</div>
														<div class="col-sm-6">
															<div class="row">
																<div class="col-sm-6">
																<?php  	echo $form->textField($model , 'b_if' ,  $model->getHtmlOptions('b_if',array('class'=>'input-text form-control LJB','placeholder'=>'')));  ?>
																<?php echo $form->error($model, 'b_if');?>
																</div>
													 	</div>
														
														</div>
														<div class="clearfix"></div>
													</div>	
                                 
                                 </div>
                                  <hr />
                                <div class="clearfix"></div>
                                
                                
                                   <div class="row">	
											<div class="col-sm-12">
														<div class="form-group  ">
															
															<div class="row">
																<div class="col-sm-6">
																 <?php echo $form->labelEx($model, 'fighting');?>
																</div>
																<div class="col-sm-6">
																<?php  	echo $form->textField($model , 'fighting' ,  $model->getHtmlOptions('fighting',array('class'=>'input-text form-control LJB','placeholder'=>'')));  ?>
																<?php echo $form->error($model, 'fighting');?>
																</div>
															</div>
													
														</div> 
													</div>
									</div>
                                  <hr />
                                <div class="clearfix"></div>
                                
                                   <div class="row">	
											<div class="col-sm-12">
														<div class="form-group  ">
															
															<div class="row">
																<div class="col-sm-6">
																 <?php echo $form->labelEx($model, 'distance_fire');?>
																</div>
																<div class="col-sm-6">
																<?php  	echo $form->textField($model , 'distance_fire' ,  $model->getHtmlOptions('distance_fire',array('class'=>'input-text form-control LJB','placeholder'=>'')));  ?>
																<?php echo $form->error($model, 'distance_fire');?>
																</div>
															</div>
													
														</div> 
													</div>
									</div>
                                  <hr />
                                <div class="clearfix"></div>
                                <div class="clearfix"></div>
                                
                                   <div class="row">	
											<div class="col-sm-12">
														<div class="form-group  ">
															
															<div class="row">
																<div class="col-sm-6">
																 <?php echo $form->labelEx($model, 'unoccupied');?>
																</div>
																<div class="col-sm-6">
																	<?php $id = 'unoccupied'; ?> 
																<div class="radio-toolbar smalln property-typ1">
																	
													<?php $property_type_Array = array('Y'=>$this->tag->getTag('yes','Yes'), 'N'=>$this->tag->getTag('no','No'));
													foreach($property_type_Array as $k=>$v){ 
														$checked ='';if($k==$model->$id){ $checked = 'checked' ;}
														?> 
													<input type="radio" id="<?php echo $id;?>_<?php echo $k;?>" <?php echo $checked;?> onchange="setCheckox('<?php echo $id;?>',this)" name="<?php echo $id;?>" value="<?php echo $k;?>"  >
													<label for="<?php echo $id;?>_<?php echo $k;?>">
													 
													
													<?php echo $v;?></label>
													<?php } ?>  
													</div>

															<div class="clearfix"></div>
															
															<?php echo $form->hiddenField($model,$id);?>
																<?php echo $form->error($model, 'unoccupied');?>
																</div>
															</div>
													
														</div> 
													</div>
									</div>
                                  <hr />
                                <div class="clearfix"></div>
                                <div class="clearfix"></div>
                                
                                   <div class="row">	
											<div class="col-sm-12">
														<div class="form-group  ">
															
															<div class="row">
																<div class="col-sm-6">
																 <?php echo $form->labelEx($model, 'sole_occupation');?>
																</div>
																<div class="col-sm-6">
																<?php  	echo $form->textField($model , 'sole_occupation' ,  $model->getHtmlOptions('sole_occupation',array('class'=>'input-text form-control LJB','placeholder'=>'')));  ?>
																<?php echo $form->error($model, 'sole_occupation');?>
																</div>
															</div>
													
														</div> 
													</div>
									</div>
                                  <hr />
                                <div class="clearfix"></div>
                                <div class="clearfix"></div>
                                
                                   <div class="row">	
											<div class="col-sm-12">
														<div class="form-group  ">
															
															<div class="row">
																<div class="col-sm-6">
																 <?php echo $form->labelEx($model, 'any_loss');?>
																</div>
																<div class="col-sm-6">
																<?php  	echo $form->textField($model , 'any_loss' ,  $model->getHtmlOptions('any_loss',array('class'=>'input-text form-control LJB','placeholder'=>'')));  ?>
																<?php echo $form->error($model, 'any_loss');?>
																</div>
															</div>
													
														</div> 
													</div>
									</div>
                                  <hr />
                                <div class="clearfix"></div>
                                <div class="clearfix"></div>
                                
                                   <div class="row">	
											<div class="col-sm-12">
														<div class="form-group  ">
															
															<div class="row">
																<div class="col-sm-6">
																 <?php echo $form->labelEx($model, 'policies');?>
																</div>
																<div class="col-sm-6">
																<?php  	echo $form->textField($model , 'policies' ,  $model->getHtmlOptions('policies',array('class'=>'input-text form-control LJB','placeholder'=>'')));  ?>
																<?php echo $form->error($model, 'policies');?>
																</div>
															</div>
													
														</div> 
													</div>
									</div>
                                  <hr />
                                <div class="clearfix"></div>
                                <div class="clearfix"></div>
                                
                                   <div class="row">	
											<div class="col-sm-12">
														<div class="form-group  ">
															
															<div class="row">
																<div class="col-sm-6">
																 <?php echo $form->labelEx($model, 'proposal');?>
																</div>
																<div class="col-sm-6">
																<?php  	echo $form->textField($model , 'proposal' ,  $model->getHtmlOptions('proposal',array('class'=>'input-text form-control LJB','placeholder'=>'')));  ?>
																<?php echo $form->error($model, 'proposal');?>
																</div>
															</div>
													
														</div> 
													</div>
									</div>
                                  <hr />
                                <div class="clearfix"></div>
	
		 <div class="clearfix"></div>
		 
		                   <div class="clearfix"></div>
		                   <div style="clear:both;"></div>
            
                       
		                 <div class="clearfix"></div>
								 
                              <div class="cols24">
                             
                                
								 	 <div id="msg_alert"></div>
								 	 
								 	 
								 	 
								 	  <div class="clearfix"></div>
  	 	 
								 	 	<div class="clearfix"></div>
								 	 		<div class="form-group  spl-12 agr"  >

						    <div class="row">

							<div class="col-sm-12">
					<div class="checkboxes">
						<label class="container_check" for="<?php echo $model->modelName;?>_agree"><?php echo Yii::t('app',$this->tag->getTag('agree_to_the_{link1}_and_the_{','Agree to the {link1} and the {link2}'),array('{link1}'=>'<a href="'.Yii::app()->createUrl('terms').'" target="_blank" class="link_color">  '.$this->tag->getTag('terms_and_conditions','Terms and Conditions').'</a>','{link2}'=>'<a href="'.Yii::app()->createUrl('privacy').'" target="_blank" class="link_color"> '.$this->tag->getTag('privacy_policy','Privacy Policy').'</a>'));?>.
						<?php  echo $form->checkBox($model , 'agree',  $model->getHtmlOptions('agree',array('uncheckValue'=>'', 'value'=>'1' )) );  ?> 
						  <span class="checkmark"></span>
						</label>
						<?php echo $form->error($model, 'agree');?>
					</div>
					</div>
					</div>
					</div>
					
					<div class="clearfix"></div>
					 <div class="clearfix"></div>
 	<div class="pop_boxone">
						<?php
						$min_error_count  = 1 ; 
					  
									$min_error_count  = 2 ; 
									?> 
									<div class="form-group">
									<div class="clearfix"></div>
									 <script>
						

  </script>
			 
			
									<div class="clearfix"></div>
									<?php echo $form->hiddenField($model, '_recaptcha' );?>
									<?php echo $form->error($model, '_recaptcha',array('style'=>'top:0px !important;'));?>
									 </div>	
									<div class="clearfix"></div>
										</div>	
	
<div class="clearfix"></div>
 
					<div class="clearfix"></div>
					
	<div class="form-group spl-n-right  margin-bottom-5">

						    <div class="row">
 
							<div class="col-sm-12">
	  
							<div class="form-group  ">

						    <div class="row">

						 
							<div class="col-sm-7">
		 
							<button  type="button"  onclick="OpenSignupRequiredNewNologin(this)" class="btn btn-primary btn-block headfont btn-sm-s rounded-btn-n"  id="bb2" style=" clear: both;max-width:90%;margin:auto;width:300px" data-html="<?php echo $mainTex;?>"><?php echo $mainTex;?></button>
	   <p class="formLegalDisclaimer positionRelative h8 typeLowlight mtn">
                                      <?php // echo Yii::t('trans', 'By clicking on \'Check Availablity\', I agree to the {p} {t} and {pp}' ,array('{p}'=>$this->project_name,'{t}'=>'<a class="linkUnderline linkLowlight" href="/terms" target="_blank">'. 'Terms & Conditions' .'</a>','{pp}'=>'<a class="linkUnderline linkLowlight" href="/privacy" target="_blank">'. 'Privacy Policy' .'</a>'));?> 
                                  
                                    </p>
		
							</div>
		</div> 
							</div><!-- end #signin-form -->
						
	
							</div>
		</div> 

	<div class="clearfix"></div>
	<div class="clearfix"></div>

  
					<div class="clearfix"></div>
				</div>
		 	
                              
                              </div>
                          <?php $this->endWidget(); ?>
                        </div>
                     </div>
                  </div>
               </div>
			   <div class="clearfx"></div>
         
 <div style="clear:both"></div>
 
	
 
		<script>
			$(function(){
    var input2 = document.querySelector("#<?php echo $model->modelName;?>_fax_false");
    window.intlTelInput(input2, {
      // allowDropdown: false,
      // autoHideDialCode: false,
      // autoPlaceholder: "off",
      // dropdownContainer: document.body,
      // excludeCountries: ["us"],
      // formatOnDisplay: false,
      // geoIpLookup: function(callback) {
      //   $.get("http://ipinfo.io", function() {}, "jsonp").always(function(resp) {
      //     var countryCode = (resp && resp.country) ? resp.country : "";
      //     callback(countryCode);
      //   });
      // },
        hiddenInput: "fax",
       initialCountry: "<?php echo COUNTRY_CODE;?>",
      // localizedCountries: { 'de': 'Deutschland' },
      // nationalMode: false,
      // onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
       placeholderNumberType: "MOBILE",
      // preferredCountries: ['cn', 'jp'],
        separateDialCode: true,
      utilsScript: "<?php echo Yii::app()->apps->getBaseUrl('assets/js/build/js/utils.js');?>",
    });
			})
		 	$(function(){
    var input = document.querySelector("#<?php echo $model->modelName;?>_phone_false");
    window.intlTelInput(input, {
      // allowDropdown: false,
      // autoHideDialCode: false,
      // autoPlaceholder: "off",
      // dropdownContainer: document.body,
      // excludeCountries: ["us"],
      // formatOnDisplay: false,
      // geoIpLookup: function(callback) {
      //   $.get("http://ipinfo.io", function() {}, "jsonp").always(function(resp) {
      //     var countryCode = (resp && resp.country) ? resp.country : "";
      //     callback(countryCode);
      //   });
      // },
        hiddenInput: "phone",
       initialCountry: "<?php echo COUNTRY_CODE;?>",
      // localizedCountries: { 'de': 'Deutschland' },
      // nationalMode: false,
      // onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
       placeholderNumberType: "MOBILE",
      // preferredCountries: ['cn', 'jp'],
        separateDialCode: true,
      utilsScript: "<?php echo Yii::app()->apps->getBaseUrl('assets/js/build/js/utils.js');?>",
    });
			})
    $(function(){
			onloadCallback()
			
			})
			
			function setCheckox(i,e){
				$('#<?php echo $model->modelName;?>_'+i).val($(e).val());return false;
			}
			
  </script>
   <style>
     .pwdopsdiv { display:none ; } .pwdstrengthstr , .pwdstrength { height:auto; }
       
   </style>
	 
