<aside class="sidebar-widget">
    <div class="hidden" style="display:none;">
    <h3 style="text-align: center;">Download our Media Kit</h3>
						<p style="text-align: center;"><a href="#" class="u-helper--no-js-hide u-btn u-btn--first-action u-btn--animated u-helper--no-margin d-nav__paa-btn" onclick="return xt_click(this,'C','15','Download-Media-Kit-Blog-advertising','S')">Download</a></p>
	</div>				
					
					<nav class="verticalnav"><ul class="verticalnav__list">
					    <li class="verticalnav__item verticalnav__item--active"> <a href="<?php echo Yii::app()->createUrl('advertisement/details',array('slug'=>'home'));?>">Advertise with us</a></li>
					    <li class="verticalnav__item"><a href="https://www.askaan.com/advertise-askaan/terms-and-conditions">Advertising Guidelines</a></li>
					 
					    <li class="verticalnav__item verticalnav__item--is-without-separator"><a href="<?php echo Yii::app()->createUrl('advertisement/contact');?>">Contact</a></li>
					     </ul></nav>
						</aside>
