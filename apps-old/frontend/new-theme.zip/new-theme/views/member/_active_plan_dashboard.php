<?php
	if(!empty($this->member->parent_user) ){
			if(empty($this->parent_member->is_verified)){
			 ?>
			 <div class="  margin-bottom-20">
		<div style="width:50px;height:50px;float:left;"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" version="1.1" width="100%" height="100%" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve"><g> <path xmlns="http://www.w3.org/2000/svg" style="" d="M149.944,101.607l-29.896-29.958c-6.935-6.949-16.16-10.775-25.977-10.775 c-9.817,0-19.042,3.827-25.976,10.775L46.424,93.367c-14.265,14.293-14.265,37.551,0,51.845l29.959,30.021 c2.93,2.936,6.773,4.404,10.618,4.404c3.833,0,7.668-1.461,10.596-4.382c5.864-5.852,46.47-46.591,52.326-52.435 C155.786,116.969,155.796,107.472,149.944,101.607z" fill="#105c6e" data-original="#105c6e"/> <path xmlns="http://www.w3.org/2000/svg" style="" d="M256,3c-8.284,0-15,6.716-15,15v48c0,8.284,6.716,15,15,15c8.284,0,15-6.716,15-15V18 C271,9.716,264.284,3,256,3z" fill="#26879c" data-original="#26879c"/> <path xmlns="http://www.w3.org/2000/svg" style="" d="M293,0h-74c-8.284,0-15,6.716-15,15s6.716,15,15,15h74c8.284,0,15-6.716,15-15S301.284,0,293,0z" fill="#de513c" data-original="#de513c"/> <path xmlns="http://www.w3.org/2000/svg" style="" d="M256,0h-37c-8.284,0-15,6.716-15,15s6.716,15,15,15h37V0z" fill="#fc6249" data-original="#fc6249"/> <path xmlns="http://www.w3.org/2000/svg" style="" d="M418.645,118.615C375.203,75.083,317.441,51.108,256,51.108S136.797,75.083,93.355,118.615 c-43.434,43.524-67.354,101.391-67.354,162.939s23.92,119.415,67.354,162.939C136.797,488.025,194.559,512,256,512 s119.203-23.975,162.645-67.507c43.434-43.524,67.354-101.391,67.354-162.939S462.079,162.139,418.645,118.615z" fill="#de513c" data-original="#de513c"/> <path xmlns="http://www.w3.org/2000/svg" style="" d="M256,51.108c-61.441,0-119.203,23.975-162.645,67.507c-43.434,43.524-67.354,101.391-67.354,162.939 s23.92,119.415,67.354,162.939C136.797,488.025,194.559,512,256,512V51.108z" fill="#fc6249" data-original="#fc6249"/> <path xmlns="http://www.w3.org/2000/svg" style="" d="M256,108.538c-95.218,0-172.684,77.614-172.684,173.015S160.782,454.569,256,454.569 s172.684-77.615,172.684-173.016S351.218,108.538,256,108.538z" fill="#96d1d9" data-original="#96d1d9"/> <path xmlns="http://www.w3.org/2000/svg" style="" d="M256,108.538c-95.218,0-172.684,77.614-172.684,173.015S160.782,454.569,256,454.569V108.538z" fill="#f4f2e6" data-original="#f4f2e6"/> <g xmlns="http://www.w3.org/2000/svg"> <path style="" d="M256,146.007c8.284,0,15-6.716,15-15v-21.808c-4.945-0.428-9.946-0.66-15-0.66 c-5.054,0-10.055,0.232-15,0.66v21.808C241,139.291,247.716,146.007,256,146.007z" fill="#105c6e" data-original="#105c6e"/> <path style="" d="M256,417.101c-8.284,0-15,6.716-15,15v21.808c4.945,0.428,9.946,0.66,15,0.66 c5.054,0,10.055-0.232,15-0.66v-21.808C271,423.817,264.284,417.101,256,417.101z" fill="#105c6e" data-original="#105c6e"/> <path style="" d="M428.028,266.554h-21.481c-8.284,0-15,6.716-15,15s6.716,15,15,15h21.481 c0.426-4.945,0.656-9.946,0.656-15S428.454,271.499,428.028,266.554z" fill="#105c6e" data-original="#105c6e"/> <path style="" d="M120.453,281.554c0-8.284-6.716-15-15-15H83.972c-0.426,4.945-0.656,9.946-0.656,15 s0.23,10.055,0.656,15h21.481C113.737,296.554,120.453,289.838,120.453,281.554z" fill="#105c6e" data-original="#105c6e"/> <path style="" d="M293,272.897h-21.162V212.23c0-8.284-6.716-15-15-15c-8.284,0-15,6.716-15,15v75.667 c0,8.284,6.716,15,15,15H293c8.284,0,15-6.716,15-15S301.284,272.897,293,272.897z" fill="#105c6e" data-original="#105c6e"/> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> </g></svg></div>
		<div style="width:calc(100% - 60px);float:right;"><div class="warning text-danger"><?php echo $this->tag->getTag('info','Info');?>:</div><p  class="text-danger"><?php echo $this->tag->getTag('account_waiting_for_admin_veri','Account Waiting for Admin Verification');?></p></div>
		<div class="clearfix"></div>
		</div>
			 
			 <?php
			}
		}
		else if(empty($this->member->is_verified)){
			 ?>
			 	 <div class="  margin-bottom-20">
		<div style="width:50px;height:50px;float:left;"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" version="1.1" width="100%" height="100%" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve"><g> <path xmlns="http://www.w3.org/2000/svg" style="" d="M149.944,101.607l-29.896-29.958c-6.935-6.949-16.16-10.775-25.977-10.775 c-9.817,0-19.042,3.827-25.976,10.775L46.424,93.367c-14.265,14.293-14.265,37.551,0,51.845l29.959,30.021 c2.93,2.936,6.773,4.404,10.618,4.404c3.833,0,7.668-1.461,10.596-4.382c5.864-5.852,46.47-46.591,52.326-52.435 C155.786,116.969,155.796,107.472,149.944,101.607z" fill="#105c6e" data-original="#105c6e"/> <path xmlns="http://www.w3.org/2000/svg" style="" d="M256,3c-8.284,0-15,6.716-15,15v48c0,8.284,6.716,15,15,15c8.284,0,15-6.716,15-15V18 C271,9.716,264.284,3,256,3z" fill="#26879c" data-original="#26879c"/> <path xmlns="http://www.w3.org/2000/svg" style="" d="M293,0h-74c-8.284,0-15,6.716-15,15s6.716,15,15,15h74c8.284,0,15-6.716,15-15S301.284,0,293,0z" fill="#de513c" data-original="#de513c"/> <path xmlns="http://www.w3.org/2000/svg" style="" d="M256,0h-37c-8.284,0-15,6.716-15,15s6.716,15,15,15h37V0z" fill="#fc6249" data-original="#fc6249"/> <path xmlns="http://www.w3.org/2000/svg" style="" d="M418.645,118.615C375.203,75.083,317.441,51.108,256,51.108S136.797,75.083,93.355,118.615 c-43.434,43.524-67.354,101.391-67.354,162.939s23.92,119.415,67.354,162.939C136.797,488.025,194.559,512,256,512 s119.203-23.975,162.645-67.507c43.434-43.524,67.354-101.391,67.354-162.939S462.079,162.139,418.645,118.615z" fill="#de513c" data-original="#de513c"/> <path xmlns="http://www.w3.org/2000/svg" style="" d="M256,51.108c-61.441,0-119.203,23.975-162.645,67.507c-43.434,43.524-67.354,101.391-67.354,162.939 s23.92,119.415,67.354,162.939C136.797,488.025,194.559,512,256,512V51.108z" fill="#fc6249" data-original="#fc6249"/> <path xmlns="http://www.w3.org/2000/svg" style="" d="M256,108.538c-95.218,0-172.684,77.614-172.684,173.015S160.782,454.569,256,454.569 s172.684-77.615,172.684-173.016S351.218,108.538,256,108.538z" fill="#96d1d9" data-original="#96d1d9"/> <path xmlns="http://www.w3.org/2000/svg" style="" d="M256,108.538c-95.218,0-172.684,77.614-172.684,173.015S160.782,454.569,256,454.569V108.538z" fill="#f4f2e6" data-original="#f4f2e6"/> <g xmlns="http://www.w3.org/2000/svg"> <path style="" d="M256,146.007c8.284,0,15-6.716,15-15v-21.808c-4.945-0.428-9.946-0.66-15-0.66 c-5.054,0-10.055,0.232-15,0.66v21.808C241,139.291,247.716,146.007,256,146.007z" fill="#105c6e" data-original="#105c6e"/> <path style="" d="M256,417.101c-8.284,0-15,6.716-15,15v21.808c4.945,0.428,9.946,0.66,15,0.66 c5.054,0,10.055-0.232,15-0.66v-21.808C271,423.817,264.284,417.101,256,417.101z" fill="#105c6e" data-original="#105c6e"/> <path style="" d="M428.028,266.554h-21.481c-8.284,0-15,6.716-15,15s6.716,15,15,15h21.481 c0.426-4.945,0.656-9.946,0.656-15S428.454,271.499,428.028,266.554z" fill="#105c6e" data-original="#105c6e"/> <path style="" d="M120.453,281.554c0-8.284-6.716-15-15-15H83.972c-0.426,4.945-0.656,9.946-0.656,15 s0.23,10.055,0.656,15h21.481C113.737,296.554,120.453,289.838,120.453,281.554z" fill="#105c6e" data-original="#105c6e"/> <path style="" d="M293,272.897h-21.162V212.23c0-8.284-6.716-15-15-15c-8.284,0-15,6.716-15,15v75.667 c0,8.284,6.716,15,15,15H293c8.284,0,15-6.716,15-15S301.284,272.897,293,272.897z" fill="#105c6e" data-original="#105c6e"/> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> </g></svg></div>
		<div style="width:calc(100% - 60px);float:right;"><div class="warning text-danger"><?php echo $this->tag->getTag('info','Info');?>:</div><p  class="text-danger"><?php echo $this->tag->getTag('account_waiting_for_admin_veri','Account Waiting for Admin Verification');?></p></div>
		<div class="clearfix"></div>
		</div>
			 <?
		}
		
if(Yii::app()->options->get('system.common.show_pack_link','1')=='1' and empty($this->member->parent_user)){ ?>
 <div class="margin-bottom-15 mob-no-m">
	 <div class="row  posingpackge">
 <div class="col-sm-3 ">
	<a href="<?php echo Yii::app()->createUrl('member/addons');?>" class="button7"  >
					<span ><img src="<?php echo Yii::app()->apps->getBaseUrl('assets/img/afav.png');?>"></span>
					<?php echo $this->tag->getTag('subscribe_packages','Subscribe Packages');?>
				</a>
				<a href="<?php echo Yii::app()->createUrl('member/orders');?>" style="display: block;text-decoration: underline;/*! letter-spacing: 1.1px; */font-size: 16px;color:#000"><i class="fa fa-history"></i> <?php echo $this->tag->getTag('order_history','Order History');?></a>
				</div>
				<div class="col-sm-5">
				    
				      <div class="row dasbrd">

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-4 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100  ">
                                <div class="card-body p-0">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary  mb-1">
                                                <?php echo $this->tag->getTag('page_views','Page Views');?></div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo !empty($last_30_Days_pageviews) ? (int)$last_30_Days_pageviews->s_count: '0' ;?> <span class="det-sn"><?php echo $this->tag->getTag('last_30_days','Last 30 days');?></span></div>
                                        </div>
                                   
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-4 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100  ">
                                <div class="card-body p-0">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success  mb-1">
                                                <?php echo $this->tag->getTag('call_clicks','Call Clicks');?></div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo   !empty($last_30_Days_callCount) ? (int)$last_30_Days_callCount->s_count: '0' ;?> <span class="det-sn"><?php echo $this->tag->getTag('last_30_days','Last 30 days');?></span></div>
                                        </div>
                                   
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-4 col-md-6 mb-4">
                            <div class="card border-left-info shadow h-100 ">
                                <div class="card-body p-0">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning   mb-1"><?php echo $this->tag->getTag('email_clicks','Email Clicks');?>
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo   !empty($last_30_Days_mailCount) ? (int)$last_30_Days_mailCount->s_count: '0' ;?> <span class="det-sn"><?php echo $this->tag->getTag('last_30_days','Last 30 days');?></span></div>
                                             
                                        </div>
                                         
                                    </div>
                                </div>
                            </div>
                        </div>
     <!-- Pending Requests Card Example -->
                     </div>
   
				</div>
 </div>
</div>
<?php } ?> 

     <!--impressions-->
     
        <div class="mt-4">
           <?php 
			$model = new PlaceAnAd('serach');
			$model->unsetAttributes();
			$model->user_id  =  Yii::app()->user->getId();
            $this->renderPartial('latest_files',compact('model'));
            ?>
       </div>
   
     <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.0/Chart.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.0/Chart.min.js"></script>

	 
     <div class="row">

                        <!-- Area Chart -->
                        <div class="col-sm-12">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold  "><?php echo $this->tag->gettag('last_90_days_impressions','Last 90 days impressions');?></h6>
                                    
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                    <?php
                                    $date = array();$count = array();
                                    foreach( $impressions_graph as $k=>$v){ $count[ date('d M y',strtotime($v->date))] = $v->s_count  ;   };
                                    
                                    
                                    ?>
                                    <script>
                                    var   xaxis =  <?php echo  json_encode(array_keys($count));?>          
                                    var   yaxis  =  <?php echo  json_encode(array_values($count)); ?> 
                                    </script>
                                    <style>
                                        canvas#myChart{

  width:100% !important;
  height:300px !important;

} canvas#chartwer2{

  width:100% !important;
  height:225px !important;

}canvas { direction: ltr;}
                                        
                                    </style>
                                    <canvas id="myChart"  height="200"></canvas>
<script>
var ctx = document.getElementById('myChart').getContext('2d');
var data = {
  labels:xaxis,
  datasets: [{
    data: yaxis,
    backgroundColor: "#4082c4"
  }]
}
var myChart = new Chart(ctx, {
    type: 'bar',
    data: data,
   options: {
      "hover": {
      "animationDuration": 0
    },
    "animation": {
      "duration": 1,
      "onComplete": function() {
        var chartInstance = this.chart,
          ctx = chartInstance.ctx;

        ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
        ctx.textAlign = 'center';
        ctx.textBaseline = 'bottom';

        this.data.datasets.forEach(function(dataset, i) {
          var meta = chartInstance.controller.getDatasetMeta(i);
          meta.data.forEach(function(bar, index) {
            var data = dataset.data[index];
            ctx.fillText(data, bar._model.x, bar._model.y - 5);
          });
        });
      }
    },
    responsive: true,
    maintainAspectRatio: false,
    legend: {
      "display": false
    },
    tooltips: {
      "enabled": false
    },
    scales: {
      yAxes: [{
        display: false,
        gridLines: {
          display: false
        },
        ticks: {
          max: Math.max(...data.datasets[0].data) + 10,
          display: false,
          beginAtZero: true
        }
      }],
      xAxes: [{
        gridLines: {
          display: false
        },
        ticks: {
          beginAtZero: true
        }
      }]
    }
  }
   
});
</script>
                                </div>
                            </div>
                        </div>

                        <!-- Pie Chart -->
                    </div>
    <div class="row">

                        <!-- Content Column -->
                        
                        <div class="col-lg-4 mb-4">
                            <style>
                                .bg-danger.as2 {    background-color: #f6c23e !important;}
                                .bg-danger.as3{  background-color: #4e73df !important; }
                                 .bg-danger.as4{  background-color: #36b9cc  !important; }
                                  .bg-danger.as5{  background-color: #1cc88a  !important; }
                                  .active-p table td{ height:Auto !important; }
                                  .active-p table td{ text-align:left !important; }
                                 html[dir="rtl"]  .active-p table td{ text-align:right !important; }
                            </style>

                            <!-- Project Card Example -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3 ">
                                    <h6 class="m-0 font-weight-bold  "><?php echo $this->tag->getTag('active_packages','Active Packages');?></h6>
                                </div>
                                <div class="card-body card-body-sep p-0 active-p">
                                    
                                   
                       
								 <table class="table table-hover">
									    <thead>
                        <tr>
                          <th><?php echo $this->tag->getTag('listing_plans','Listing Plans');?></th>
                           
                        </tr>
                      </thead>
                     
                                    <?php
                                  	if(!empty($plans)){
										echo '<tbody>';
										foreach($plans as $k=>$v){
											 
											?>
											<tr>
                          <td><b><?php echo $v->package_name;?></b><label class="pull-right badge <?php echo $v->days_remaining < 10 ? 'badge-danger':'badge-success';?>"><?php echo $v->days_remaining.'  '.$this->tag->getTag('days','Days');?></label><br /> 
                          
                          <?php
                          if($v->max_listing_per_day != ''){   
                          $tot = $v->max_listing_per_day== 0  ? $this->tag->getTag('unlimited','Unlimited') :  (int) $v->max_listing_per_day;
                           echo   $tot  .' '.$this->tag->getTag('listings','Listings');
                           
                           if($v->max_listing_per_day != 0 ){
                           ?> ( <span class="<?php echo $v->available_listings == 0 ? 'text-danger':'text-success';?>"><?php echo $v->available_listings;?> <?php echo $this->tag->getTag('remaining','Remaining');?></span>)<br />
                           
                           <?php }
                           else{
							   echo '<br />';
						   }
                           
                            } ?> 
                           <?php if(!empty($v->no_of_featured)){  echo $v->no_of_featured;?> <?php echo $this->tag->getTag('featured_listing','Featured Listing');?> ( <span class="<?php echo $v->avaliable_featured_listing == 0 ? 'text-danger':'text-success';?>"><?php echo $v->avaliable_featured_listing;?> <?php echo $this->tag->getTag('remaining','Remaining');?> </span>)<?php } ?>
                           </td>
                          </tr>
                           
											<?
										}
										echo '</tbody>';
									}
									else{
										echo '<tr><td class="text-center pl-5 pr-5" style="padding-top:90px;padding-bottom:90px;">
										<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" version="1.1" width="70" height="70" style="display:block;margin:auto;" x="0" y="0" viewBox="0 0 412.533 412.533" style="enable-background:new 0 0 512 512" xml:space="preserve"><g>
<g xmlns="http://www.w3.org/2000/svg">
	<path style="" d="M412.485,203.954h0.041c0-14.323-5.609-27.336-14.729-37.042l0.016-0.016l-79.27-101.819H90.479   L13.493,168.961l0.033,0.033c-7.283,8.616-11.762,19.565-12.534,31.514C0.415,201.629,0,202.84,0,204.19v135.138   c0,4.495,3.642,8.129,8.129,8.129h396.276c4.495,0,8.129-3.633,8.129-8.129V204.19   C412.533,204.109,412.485,204.035,412.485,203.954z M97.844,81.335H311.43l48.389,68.5c-0.512-0.016-1-0.081-1.52-0.081h-97.502   v24.369c0,27.67-29.052,21.687-37.96,21.687h-32.466c-8.909,0-37.96,5.983-37.96-21.687v-24.369H54.9   c-1.016,0-2.008,0.098-3.016,0.146L97.844,81.335z M396.276,331.199H16.265V204.19c0-0.081-0.041-0.154-0.049-0.236h0.723   c0-20.923,17.029-37.944,37.96-37.944h81.253v8.112c0,27.987,21.281,37.944,54.218,37.944h32.466   c32.945,0,54.218-9.957,54.218-37.944v-8.112h81.261c10.461,0,19.948,4.251,26.824,11.12l0.016,0.016   c6.869,6.869,11.112,16.347,11.112,26.808h0.057c0,0.081-0.049,0.154-0.049,0.236C396.276,204.19,396.276,331.199,396.276,331.199z   " fill="currentColor" data-original="#010002"/>
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
</g></svg>
										
										No plans active.</td></tr>';
									}
									echo '</table>';
									?>
                                    
                                    
                                    
                                </div>
                            </div>

                            <!-- Color System -->
                     
                        </div>
                        
                            <div class="col-xl-4 col-lg-5">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold  "><?php echo $this->tag->gettag('properties_count','Properties Count');?></h6>
                                    
                                </div>
                                <!-- Card Body -->
                                <div class="card-body card-body-sep">
                                    <div id="canvas-holder"  > 	<canvas id="chartwer2"  dir="ltr" style="width:280px;height:280px"      /></canvas> </div>							
                                    <div class="media-body "  id="chartjsLegend_exp"    ><div id="js-legend2" dir="ltr" class="chart-legend"></div></div>
                                    
                                    <script>
                                   var config2 = {
        type: 'pie',
        data: {
            datasets: [{
                data: ['<?php echo $active_properties['sale_total'];?>','<?php echo $active_properties['rent_total'];?>','<?php echo $active_properties['active_total'];?>'],
                   backgroundColor: ["#34A853", "#468CEE" , "#FCD404"],
             
                label: 'Dataset 1'
            }],
            labels:['<?php echo $this->tag->getTag('sale','Sale');?>','<?php echo $this->tag->getTag('rent','Rent');?>','<?php echo $this->tag->getTag('active','Active');?>']       },
        options: {
              responsive: true,
    maintainAspectRatio: false,
          legend: {
                position: 'bottom',
              
                 display:false,
                  labels: {
                            usePointStyle: true, maxWidth: 100,
                        }
            },
            title: {
                display: false,
                text: 'Expenses Last 30 days'
            },
            animation: {
                animateScale: true,
                animateRotate: true
            }
        }
    };
                                        var ctxt2 = document.getElementById("chartwer2").getContext("2d");
        myDoughnut = new Chart(ctxt2, config2) ;
			document.getElementById("js-legend2").innerHTML = myDoughnut.generateLegend()
                                        
                                        
                                    </script>
                                 </div>
                            </div>
                        </div>
                    
                        	<?php 
			///	if(!empty($this->mem->ListAgentPermission2) and $this->mem->max_no_users>0 ){
				
				$AgentsCreated =  $this->mem->AgentsCreated;
$max_no_users  = $this->mem->max_no_users;
$remaining_users = $max_no_users - $AgentsCreated ;
if($max_no_users){
				?> 
				  <div class="col-lg-4 mb-4">
                            

                            <!-- Project Card Example -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold  "><?php echo $this->tag->getTag('agents_listing_quota','Agents Listing Quota');?></h6>
                                </div>
                                <div class="card-body card-body-sep">
                                          <div class="row">
                          <div class="col-md-12 mb-4">
                            <div class="d-flex align-items-center pb-0">
                              
                              <p class="mb-0"><h4 class="font-weight-semibold"><span style="font-weight:normal; font-size: 17px;"><?php echo $this->tag->getTag('total_listing_quota','Total Listing Quota');?> - </span><?php echo (int) $max_no_users;?></h4> </p>
                            </div>
                            
                            <div class="progress progress-md">
                              <div class="progress-bar bg-info " role="progressbar" style="width: 100%" aria-valuenow="78" aria-valuemin="0" aria-valuemax="78"></div>
                            </div>
                          </div>
                            <?php $pecentage_used =   (($AgentsCreated/$max_no_users)*100);  $pecentage_remaining =   100-$pecentage_used; 
                            
                            if($pecentage_used <=50){
                             $pecentage_used_class = 'bg-success';
                            }
                            else{
                                $pecentage_used_class = 'bg-danger';
                            }
                           if($pecentage_remaining <=50){
                             $pecentage_remaining_class = 'bg-success';
                            }
                            else{
                                $pecentage_remaining_class = 'bg-danger';
                            }
                            
                            ?>
                          <div class="col-md-12 mt-4 mt-md-0 mb-4">
                            <div class="d-flex align-items-center pb-0">
                             
                                <p class="mb-0"><h4 class="font-weight-semibold"><span style="font-weight:normal; font-size: 17px;"><?php echo $this->tag->getTag('total_used','Total Used');?> - </span><?php echo (int)$AgentsCreated;?></h4> </p>
                            </div>
                          
                            <div class="progress progress-md">
                              <div class="progress-bar <?php echo $pecentage_used_class ;?>" role="progressbar" style="width: <?php echo $pecentage_used;?>%" aria-valuenow=" <?php echo $pecentage_used;?>" aria-valuemin="0" aria-valuemax=" <?php echo $pecentage_used;?>"></div>
                            </div>
                          </div>
                           <div class="col-md-12 mt-4 mt-md-0 mb-4">
                            <div class="d-flex align-items-center pb-0">
                                        <p class="mb-0"><h4 class="font-weight-semibold"><span style="font-weight:normal; font-size: 17px;"><?php echo $this->tag->getTag('total_remaining','Total Remaining');?> - </span><?php echo (int)$remaining_users;?></h4> </p>
                    
                             
                            </div>
                           
                            <div class="progress progress-md">
                              <div class="progress-bar <?php echo $pecentage_remaining_class;?>" role="progressbar" style="width: <?php echo  $pecentage_remaining;?>%" aria-valuenow=" <?php echo  $pecentage_remaining;?>" aria-valuemin="0" aria-valuemax=" <?php echo  $pecentage_remaining;?>"></div>
                            </div>
                          </div>
                     
                        </div>
                     
                                </div>
                            </div>

                            <!-- Color System -->
                     
                        </div>
                        
				<?php }  // } ?> 
                     </div> 
     <!--impressions end-->
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
        <!-- partial -->
