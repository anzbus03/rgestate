  <footer class="footer">
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block float-right"><a href="<?php echo Yii::app()->createUrl('faq-designer-or-photographer');?>"
            target="_blank">FAQ</a><a href="<?php echo Yii::app()->createUrl('members-terms-and-condition');?>" target="_blank" style="margin-left:20px;">Terms and Conditions</a></span>
          </div>
        </footer>