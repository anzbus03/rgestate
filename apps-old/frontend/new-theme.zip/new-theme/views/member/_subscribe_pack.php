<Style>
    .pack_type_0.col-sm-3 {
    width: 266px;
    max-width: unset !important;
}
.price-option--low.pack_type_0 .top-arch {
    padding-top: 69.25%;
}
.price-option--low.pack_type_0.pinky {
    position: relative;
    bottom: 0px;
}.pack_type_0.pinky .btm-di {
    border-left: 2px solid var(--secondary-color);
    border-right: 2px solid var(--secondary-color);
    border-bottom: 2px solid var(--secondary-color);
}.pack_type_0 .btm-di {
    padding: 6px;
    border-left: 2px solid var(--secondary-color);
    border-right: 2px solid var(--secondary-color);
    border-bottom: 2px solid var(--secondary-color);
}
 
  .pricing.row { 
      text-align:center;
}
.pricing[data-id="180"] .price-option--low.pack_type_0.pinky .price-option__detail {
    min-height: 255px;
}
html[dir="rtl"] .pricing[data-id="180"] .price-option--low.pack_type_0.pinky .price-option__detail {
    min-height: 238px;
}
</Style>
<div class="row margin-bottom-15  margin-top-40 color_1" id="pack_<?php echo $idd;?>">
	  <div class="col-sm-12">
				<div class="subscription-row subscription-row-<?php echo $idd;?>">
		        <div class="pageHeading   margin-top-15">
				 
					<div class="desc-det  "  style="width:100% !important" >
					   <div class="mm-d-h" style="color:var(--black-color) !important"><span class="m-b-b-nstyle"><svg xmlns="http://www.w3.org/2000/svg" class="margin-right-5"  style="margin-top: -9px;" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" version="1.1" width="30" height="30" x="0" y="0" viewBox="0 0 512.001 512.001" style="enable-background:new 0 0 512 512" xml:space="preserve"><g> <g xmlns="http://www.w3.org/2000/svg"> <g> <path d="M400.003,152H256.001c-5.523,0-10,4.477-10,10s4.477,10,10,10h144.002c5.523,0,10-4.477,10-10S405.526,152,400.003,152z" fill="currentColor" data-original="#000000" style=""/> </g> </g> <g xmlns="http://www.w3.org/2000/svg"> <g> <path d="M365.011,202.931c-1.86-1.86-4.44-2.93-7.07-2.93s-5.21,1.07-7.07,2.93c-1.86,1.86-2.93,4.44-2.93,7.07 s1.07,5.21,2.93,7.07s4.44,2.93,7.07,2.93s5.21-1.07,7.07-2.93c1.86-1.86,2.93-4.44,2.93-7.07S366.871,204.791,365.011,202.931z" fill="currentColor" data-original="#000000" style=""/> </g> </g> <g xmlns="http://www.w3.org/2000/svg"> <g> <path d="M263.061,45.931c-1.86-1.86-4.44-2.93-7.07-2.93s-5.21,1.07-7.07,2.93c-1.86,1.86-2.93,4.44-2.93,7.07 s1.07,5.21,2.93,7.07c1.86,1.86,4.44,2.93,7.07,2.93s5.21-1.07,7.07-2.93c1.86-1.86,2.93-4.44,2.93-7.07 S264.921,47.791,263.061,45.931z" fill="currentColor" data-original="#000000" style=""/> </g> </g> <g xmlns="http://www.w3.org/2000/svg"> <g> <path d="M315.878,200h-59.877c-5.523,0-10,4.477-10,10s4.477,10,10,10h59.877c5.523,0,10-4.477,10-10S321.401,200,315.878,200z" fill="currentColor" data-original="#000000" style=""/> </g> </g> <g xmlns="http://www.w3.org/2000/svg"> <g> <path d="M400.003,260H256.001c-5.523,0-10,4.477-10,10s4.477,10,10,10h144.002c5.523,0,10-4.477,10-10S405.526,260,400.003,260z" fill="currentColor" data-original="#000000" style=""/> </g> </g> <g xmlns="http://www.w3.org/2000/svg"> <g> <path d="M365.011,310.931c-1.86-1.86-4.44-2.93-7.07-2.93s-5.21,1.07-7.07,2.93c-1.86,1.86-2.93,4.44-2.93,7.07 s1.07,5.21,2.93,7.07s4.44,2.93,7.07,2.93s5.21-1.07,7.07-2.93c1.86-1.86,2.93-4.44,2.93-7.07S366.871,312.791,365.011,310.931z" fill="currentColor" data-original="#000000" style=""/> </g> </g> <g xmlns="http://www.w3.org/2000/svg"> <g> <path d="M315.878,308h-59.877c-5.523,0-10,4.477-10,10s4.477,10,10,10h59.877c5.523,0,10-4.477,10-10S321.401,308,315.878,308z" fill="currentColor" data-original="#000000" style=""/> </g> </g> <g xmlns="http://www.w3.org/2000/svg"> <g> <path d="M400.003,368H256.001c-5.523,0-10,4.477-10,10s4.477,10,10,10h144.002c5.523,0,10-4.477,10-10S405.526,368,400.003,368z" fill="currentColor" data-original="#000000" style=""/> </g> </g> <g xmlns="http://www.w3.org/2000/svg"> <g> <path d="M365.011,418.931c-1.86-1.86-4.44-2.93-7.07-2.93s-5.21,1.07-7.07,2.93c-1.86,1.86-2.93,4.44-2.93,7.07 s1.07,5.21,2.93,7.07s4.44,2.93,7.07,2.93s5.21-1.07,7.07-2.93c1.86-1.86,2.93-4.44,2.93-7.07S366.871,420.791,365.011,418.931z" fill="currentColor" data-original="#000000" style=""/> </g> </g> <g xmlns="http://www.w3.org/2000/svg"> <g> <path d="M315.878,416h-59.877c-5.523,0-10,4.477-10,10s4.477,10,10,10h59.877c5.523,0,10-4.477,10-10S321.401,416,315.878,416z" fill="currentColor" data-original="#000000" style=""/> </g> </g> <g xmlns="http://www.w3.org/2000/svg"> <g> <path d="M419.243,39.001h-76.379C331.823,28.48,316.898,22,300.479,22h-8.76C285.022,8.742,271.263,0,256,0 s-29.021,8.742-35.719,22H211.5c-16.419,0-31.343,6.48-42.384,17.001H92.759c-26.885,0-48.758,21.873-48.758,48.758v375.484 c0,26.885,21.873,48.758,48.758,48.758h326.483c26.885,0,48.758-21.873,48.758-48.758V87.759 C468.001,60.874,446.128,39.001,419.243,39.001z M211.501,42h15.586c4.498,0,8.442-3.003,9.639-7.338 C239.111,26.029,247.037,20,256.001,20c8.964,0,16.89,6.029,19.274,14.662c1.197,4.335,5.142,7.338,9.639,7.338h15.565 c21.705,0,39.571,16.75,41.354,38.001H170.147C171.93,58.75,189.797,42,211.501,42z M448.001,463.244 c0,15.857-12.901,28.758-28.758,28.758H92.759c-15.857,0-28.758-12.901-28.758-28.758V87.759 c0-15.857,12.901-28.758,28.758-28.758h62.347c-3.276,7.512-5.105,15.794-5.105,24.5v6.5c0,5.523,4.477,10,10,10H351.98 c5.523,0,10-4.477,10-10v-6.5c0-8.705-1.829-16.988-5.105-24.5h62.368c15.857,0,28.758,12.901,28.758,28.758V463.244z" fill="currentColor" data-original="#000000" style=""/> </g> </g> <g xmlns="http://www.w3.org/2000/svg"> <g> <path d="M192.41,149.596c-3.905-3.905-10.237-3.905-14.142-0.001l-42.762,42.763l-13.173-13.174 c-3.905-3.904-10.237-3.904-14.143,0c-3.905,3.905-3.905,10.237,0,14.143l20.245,20.245c1.953,1.953,4.512,2.929,7.071,2.929 c2.559,0,5.119-0.976,7.071-2.929l49.833-49.833C196.315,159.834,196.315,153.502,192.41,149.596z" fill="currentColor" data-original="#000000" style=""/> </g> </g> <g xmlns="http://www.w3.org/2000/svg"> <g> <path d="M168.001,368h-48c-5.523,0-10,4.477-10,10v48c0,5.523,4.477,10,10,10h48c5.523,0,10-4.477,10-10v-48 C178.001,372.477,173.524,368,168.001,368z M158.001,416h-28v-28h28V416z" fill="currentColor" data-original="#000000" style=""/> </g> </g> <g xmlns="http://www.w3.org/2000/svg"> <g> <path d="M168.001,260h-48c-5.523,0-10,4.477-10,10v48c0,5.523,4.477,10,10,10h48c5.523,0,10-4.477,10-10v-48 C178.001,264.477,173.524,260,168.001,260z M158.001,308h-28v-28h28V308z" fill="currentColor" data-original="#000000" style=""/> </g> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> <g xmlns="http://www.w3.org/2000/svg"> </g> </g></svg><?php echo $sb_title;?></span></div>
					</div>
					 <div class="clearfix"></div>
					</div>
		     	 <div class="clearfix"></div>
		     	 <div id="seperator_1"></div>
				 <div class="clearfix"></div>
			</div>
			<div class="clearfix"></div>
				 <div class="pricing row" id="pricing-row">
		
		 <?php
		 $mmost_pospular = Yii::t('app',$this->tag->getTag('most_{b}_popular','Most {b} Popular'),array('{b}'=>'<br />')); 
		 $economy = Yii::t('app',$this->tag->getTag('economy','Economy')); 
					$elite = Yii::t('app',$this->tag->getTag('elite','Elite')); 
					$premium = Yii::t('app',$this->tag->getTag('premium','Premium'));
					 $Ar = array();
					 foreach($listing_packages as $k=>$v){ 
						 
						 if(!empty($v->validity_in_days)){
								 $Ar[$v->validity_in_days] = $v->ValidityTitle;
							 }
							 		 $url =     !empty($v->is_book)   ? Yii::app()->createUrl('member/book_an_appointment',array('package_uid'=>$v->package_uid,'payment'=>'b'))  :  Yii::app()->createUrl('member/subscribe_package',array('package_uid'=>$v->package_uid)) ; 
					
						 ?>
						 		 <a href="<?php echo $url;?>" class="p-list months_<?php echo $v->validity_in_days;?>"   >
				
					<div class="[ price-option price-option--low  pack_type_<?php echo $v->p_type;?> pack_type_tag_<?php echo $v->tag;?> col-sm-<?php echo !empty($offer_packages) ? '3' : '3';?> <?php echo $v->active_package == $v->primaryKey ? 'active' : '' ;?> ] ">
						<div class="top-arch">
					
				    <?php  echo ($v->tag=='1') ? '<div class="mst-po">'.$mmost_pospular.'</div>' : '';?>
					<?php  echo ($v->tag=='1') ? '<div class="mst-po11 mst-po1">'.$premium.'</div>' : '';?>
					<?php  echo ($v->tag=='2') ? '<div class="mst-po11 mst-po1">'.$economy.'</div>' : '';?>
					<?php  echo ($v->tag=='3') ? '<div class="mst-po11 mst-po1">'.$elite.'</div>' : '';?>
					
					</div>
					<div class="btm-di">
					<div class="price-option__detail">
					<span class="price-option__cost"><?php echo   !empty($v->is_book) ? '&nbsp' :  $v->PriceTitleL ;?><br /><span style="font-size:20px;font-weight:700;color:#666"><?php echo $v->validity_in_days/30; echo ' '.$this->tag->getTag('months','Months')?> </span></span>
					<?php
					if(!empty($globalTax)){ ?> <span class="price-option__tax">+ <?php echo  $globalTax->name ;?></span> <? } ?> 
					
						<?php
						
						 	echo '<ul class="plan-details">';
						 	    
									    if(!empty($v->description )){
									    $description = explode('/n',$v->description) ;
									    echo '<li><b>'. $v->package_name.'</b></li>';
									    foreach($description as $itm){
											echo '<li>'. $itm.'</li>';
										}
									    }
									    else{
									
								 	
										if($v->max_listing_per_day !=''){
											$tot = $v->max_listing_per_day== 0  ? $this->tag->gettag('unlimited','Unlimited') :  (int) $v->max_listing_per_day;
										echo '<li>'.Yii::t('app',$this->tag->getTag('{fl}_featured_listing_out_of_{','{fl} Featured Listing out of {st}  Standard Listing'),array('{fl}'=>'<b>'.(int) $v->no_of_featured.'</b>','{st}'=>'<b>'.$tot.'</b>')).'</li>';
										}
										if(!empty($v->no_of_users)){
										echo '<li>'.Yii::t('app',$this->tag->getTag('{n}_user_accounts','{n} User Accounts'),array('{n}'=>'<b>'.(int) $v->no_of_users.'</b>')).'</li>';
										}
										if(!empty($v->valuation)){
										echo '<li>'.$v->getAttributeLabel('valuation').'</li>';
										}
										if(!empty($v->photography)){
										echo '<li>'.$v->getAttributeLabel('photography').'</li>';
										}
										if(!empty($v->campain)){
										echo '<li>'.$v->getAttributeLabel('campain').'</li>';
										}
										if(!empty($v->seo)){
										echo '<li>'.$v->getAttributeLabel('seo').'</li>';
										}
										if(!empty($v->blog)){
										echo '<li>'.$v->getAttributeLabel('blog').'</li>';
										}
										if(!empty($v->banners)){
										echo '<li>'.$v->getAttributeLabel('banners').'</li>';
										}
										if(!empty($v->floor)){
										echo '<li>'.$v->getAttributeLabel('floor').'</li>';
										}
									if(!empty($v->email_campain)){
										echo '<li>'.$v->getAttributeLabel('email_campain').'</li>';
										}
									
									
									}
								 	if(!empty($v->validity_in_days)){
										echo '<li>'.Yii::t('app',$this->tag->getTag('{n}_vallidity','{n} vallidity'),array('{n}'=>'<b>'.$v->ValidityTitle.'</b>')).'</li>';
										}
							  echo '</ul>';
						 
						
						
				 ?>
					</div>
					<div   class="price-option__purchase green"><?php echo !empty($v->call_of_action ) ? $v->call_of_action : $this->tag->getTag('subscribe','Subscribe') ;?></div>
					<div class="clearfix"></div>
					</div>
					</div>
					</a>
					<?php } ?> 
					 <?php
	 if(!empty($offer_packages)){ ?>
	 
		 <a href="javascript:void(0)" onclick="OpenPromo(this)"  class=" ">
				
				<div class="[ price-option price-option--low  pack_type_0 pack_type_tag_2 col-sm-3 promo ] ">
						<div class="top-arch">
					
										
					</div>
					<div class="btm-di">
					<div class="price-option__detail">
					<span class="price-option__cost"> </span>
					 
					
						<ul class="plan-details"><li> &nbsp;</li></ul>					</div>
					<div class="price-option__purchase green"><?php echo $this->tag->getTag('promo_code','Promo Code');?></div>
					<div class="clearfix"></div>
					</div>
					</div>
					</a>
	 
	<?php } 
	?>
 
 </div>
				 
				 <div class="clearfix"></div>
      </div>

	
</div>			 
<?php   
if(!empty($Ar)){
	$html = '<ul class="top_cls margin-top-30  margin-bottom-30" id="'.$idd.'">'; 
	foreach($Ar as $k22=>$v22){
		$html .= '<li onclick="showPackage('.$k22.','.$idd.',this)" class="mnly-optins" id="mnly-optins-'.$k22.'">'.$v22.'</li>';
	}
	$html .= '</ul>';
	?>
	<script>$('#seperator_<?php echo $idd;?>').html('<?php echo $html;?>');$('#seperator_<?php echo $idd;?>').find('li#mnly-optins-180').click(); </script>
	<?
	
}
