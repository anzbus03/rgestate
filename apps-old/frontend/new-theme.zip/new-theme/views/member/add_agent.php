<style>
 .sub_header_in h1 { text-align:center; }
 #login aside form .form-group i, #register aside form .form-group i { top :8px;font-weight:normal; }
 .signupDiv .rui-input .rui-icon{
	 position: absolute;

right: 10px;

left: unset !important;

top: 16px !important;
 }
 #user_signup #signup3-form .form-group label {

    font-size: 13px;
    font-weight: normal;

}#member .select2-container--default .select2-selection--single, #place_an_ad .select2-container--default .select2-selection--single {
    border: 1px solid #dee2e6;
}
html #UserLogin_remember_me {
    display: none !important;
}.form-control:focus {
  
transition: box-shadow .2s !important;
box-shadow: 0 0 10px 0 rgba(0,0,0,.07);
border: 1px solid #d8d8d8;
}
.browse_type .upload-btn-wrapper .btn {
 
    color: var(--secondary-color) !important;
    border-color: var(--secondary-color) !important;
}
.btn-info:not(:disabled):not(.disabled):active, .btn-info:not(:disabled):not(.disabled):hover {

    color :#fff !important;
    background-color:var(--secondary-color) !important;
    border-color: var(--secondary-color) !important ;

}
.rui-select-list input[value=""]{ display:none !important; }
.errorMessage { font-size:13px; }
 </style>
		<div class="container margin_60_35" style="padding-top:0px; ">
<div id="register" class="row">
	
	<div class="" style="width:100%;">
		<div class="col-md-12 signupDiv" style=" margin:00px auto;">
	<aside class="  " style="padding-top:0px;">
		<div class="page-header bx"  style="margin-top:0px;"> <h4 class="page-title"  style="min-width:100%;"><?php echo $model->isNewRecord ? $this->tag->getTag('add_user','Add User') :$this->tag->getTag('update_user','Update User');?> 
			<a href="<?php echo Yii::App()->createUrl('member/list_agents');?>" class="btn btn-secondary pull-right"><i class="fa fa-list"></i> <?php echo $this->tag->getTag('list_users','List Users');?></a>
		</h4> 
            <div class="clearfix"><!-- --></div>
        </div>
				<?php 
				$text = $model->isNewRecord ?  $this->tag->getTag('add_user','Add User') :$this->tag->getTag('update_user','Update User'); 
				$Validating = $this->tag->getTag('validating','Validating..');
				$please_wait = $this->tag->getTag('please_wait','Please wait..');
				
				$form=$this->beginWidget('CActiveForm', array(
				'action'=>Yii::app()->createUrl("member/add_agent",array('id'=>@$id)),
				'id'=>'signup3-form',
				'enableAjaxValidation'=>true,

				'clientOptions' => array(
				'validateOnSubmit'=>true,
				'validateOnChange'=>false,
					'beforeValidate' => 'js:function(form) {
validateThisInp();
								form.find("#bb").html("'.$Validating  .'");
								return true;
								}',
								'afterValidate' => 'js:function(form, data, hasError) { 

								if(hasError) {
								form.find("#bb").html("'. $text .'");
									  $("html, body").animate({
        scrollTop: form.find(".errorMessage:visible:first").offset().top-50
    }, 2000);
								return false;
								}
								else
								{
								form.find("#bb").html("'. $please_wait .'");	return true;
								}
								}',
				),
'htmlOptions'=>array('autocomplete'=>'off')
				));  
				
				 
				?>
				<div class="row" style="padding-top:15px;">
					<div class="row" style="width:100%">
			       <div class="form-group col-lg-9">
                  <div class="clearfix"></div>
                      <div class="clearfix"><!-- --></div>
						    
							<?php
							/*
							if(  $model->user_type != 'U') { ?> 
							<div class="form-group col-sm-6">
							 <?php echo $form->labelEx($model, 'log_not');?>
							<?php echo $form->checkbox($model, 'log_not', $model->getHtmlOptions('log_not',array('value'=>'1','uncheckvalue'=>'','style'=>'width:auto;',  'onchange'=>'hideloginIf(this)' ))); ?>
							<?php echo $form->error($model, 'log_not');?>
							</div> 
							<?php 
							    
							    
							} */ ?> 
							<style>
							    html[dir="rtl"] .eng-sor { float:left; }
							    html[dir="rtl"] .ar-sor { float:right; }
							</style>
							<div class="clearfix"></div>
		<div class="form-group col-sm-6 eng-sor " hint="">
		<?php echo $form->labelEx($model, 'first_name');?>(<?php echo $this->tag->gettag('english','English');?>)
		<div class="clearfix"></div>
		<?php 
		echo $form->textField($model , 'first_name', array_merge($model->getHtmlOptions('first_name'),array("placeholder"=>$this->tag->getTag('full_name_*','Full Name *') ,'class'=>'form-control'))); 
		?>
		 
		<?php echo $form->error($model, 'first_name');?>
		<div class="clearfix"></div>
		</div>			
         <div class="form-group col-sm-6  ar-sor" hint="">
             <label for="ListingUserAgent_first_name_ar" class="required"><?php echo $model->getAttributeLabel('first_name_ar');?> <span class="required"*</span></label>(<?php echo $this->tag->gettag('arabic','Arabic');?>)
		<div class="clearfix"></div>
		<?php 
		echo $form->textField($model , 'first_name_ar', array_merge($model->getHtmlOptions('first_name_ar'),array("placeholder"=>$this->tag->getTag('full_name_*','Full Name *') ,'class'=>'form-control'))); 
		?>
		 
		<?php echo $form->error($model, 'first_name_ar');?>
		<div class="clearfix"></div>
		</div>			
            <div class="clearfix"><!-- --></div>
         <div class="form-group col-sm-6">
							  <?php echo CHtml::activeLabel($model, 'email', array('required' => true));?>
							<?php echo $form->textField($model, 'email', $model->getHtmlOptions('email')); ?>
							<?php echo $form->error($model, 'email');?>
							</div> 
						    
		 
						 
						    
							<div class="loginf <?php echo  $model->log_not=="1" ? 'hide' : '';?>">
							
						 
							<div class="form-group col-lg-3">
							<?php if($model->isNewRecord){ echo CHtml::activeLabel($model, 'password', array('required' => true)); }else{ echo $form->labelEx($model, 'password'); }  ?>
						
							<?php echo $form->passwordField($model, 'password', $model->getHtmlOptions('password')); ?>
							<?php echo $form->error($model, 'password');?>
							</div> 
							<div class="form-group col-lg-3">
							 <?php if($model->isNewRecord){ echo CHtml::activeLabel($model, 'con_password', array('required' => true)); }else{ echo $form->labelEx($model, 'con_password'); }  ?>
						
							<?php echo $form->passwordField($model, 'con_password', $model->getHtmlOptions('con_password')); ?>
							<?php echo $form->error($model, 'con_password');?>
							</div> 
							</div>
					<div class="clearfix"><!-- --></div>  
				 
                  <div class="clearfix"></div>
	
	 <style>
	     .iti { direction:ltr; }
	 </style>
		<div class="form-group col-sm-12" hint="">
		    <?php
		    if(!Yii::app()->request->isPostRequest){
		        $model->phone = !empty($model->full_number) ? $model->full_number : $model->phone ; 
		    } ?> 
			<?php echo $form->labelEx($model, 'phone');?>
			<div class="clearfix"></div>
			<?php 
			echo $form->textField($model , 'phone', array_merge($model->getHtmlOptions('phone'),array("placeholder"=>"", 'onchange'=>'validateThisInp()' ,'class'=>'form-control'))); 
			?>
			 
			<?php echo $form->error($model, 'phone');?>
			<div class="clear"></div>
	</div>
 	       <div class="clearfix"></div>
	
							 	<div class="form-group  col-sm-3">
							 
							<?php
							 echo $form->labelEx($model, 'role_id');   
							 echo $form->dropDownList($model, 'role_id',CHtml::listData(Master::model()->listData(ListingUsers::DESIGNATION_ID),'master_id','master_name'), $model->getHtmlOptions('role_id' ,array('empty'=>$this->tag->getTag('please_select','Please Select'))));
							  ?>
							 
							<?php echo $form->error($model, 'role_id');?>
							</div> 
							 	<div class="form-group  col-sm-3">
							 
							<?php
							 echo $form->labelEx($model, 'user_status');   
							 echo $form->dropDownList($model, 'user_status', $model->user_status(), $model->getHtmlOptions('role_id' ,array('empty'=>$this->tag->getTag('please_select','Please Select'))));
							  ?>
							 
							<?php echo $form->error($model, 'user_status');?>
							</div> 
	  
				 	<div class="form-group  col-sm-6">
							 
							<?php
							 echo $form->labelEx($model, 'address');   
							 echo $form->textField($model, 'address', $model->getHtmlOptions('address' ));
							 $model->agree = '1'; 
							 echo $form->hiddenField($model, 'agree'  );
							  ?>
							 
							<?php echo $form->error($model, 'address');?>
							</div> 
				 		<div class="clearfix"></div>
		<div class="clearfix"></div>	
	 
	 
	
	 <div class="clearfix"></div>
	 <div class="openWhenUserType <?php if(!in_array($model->user_type,array('A','C','D'))){ echo 'hide';  };?>">
		 
					<div class="form-group col-sm-12" hint="">
			 
			<?php
		  	 echo $form->labelEx($model, 'description'); ?><label>(<?php echo $this->tag->gettag('english','English');?>)</label>
		  	 <div class="clearfix"></div>
		  	 <?php
			 echo $form->textArea($model, 'description', $model->getHtmlOptions('description',array('class'=>'form-control', ))); ?>
			 
			<?php echo $form->error($model, 'description');?>
			</div>  
					<div class="clearfix"></div>
				
				 	<div class="form-group col-sm-12" hint="">
			 
			<?php
		  	 echo $form->labelEx($model, 'description_ar'); ?><label>(<?php echo $this->tag->gettag('arabic','Arabic');?>)</label>
		  	 <div class="clearfix"></div>
		  	 <?php 
			 echo $form->textArea($model, 'description_ar', $model->getHtmlOptions('description_ar',array('class'=>'form-control', ))); ?>
			 
			<?php echo $form->error($model, 'description_ar');?>
			</div> </div>	
					<div class="clearfix"></div>
				
				 <div class="clearfix"></div>
			 	<div class="clearfix"></div>
							
		<div class="">
		<?php
		if(!Yii::App()->request->isPostRequest and empty($model->country_id) ){$model->country_id = $this->member->country_id;}?> 
		<div class="form-group  col-sm-6  hidden  " hint="">
		<?php echo $form->labelEx($model, 'country_id');?>
		<?php
		echo $form->dropDownList($model,'country_id', CHtml::listData(Countries::model()->Countrylist(),"country_id" ,"country_name"),array("class"=>"select2", "empty"=>"Select County*",'data-url'=>Yii::App()->createUrl('site/select_city_new'),'onchange'=>'load_via_ajax2(this,"state_id")')); 
		?>
		 
		<?php echo $form->error($model, 'country_id');?>
		<div class="clear"></div>
		</div>
		<?php
		       $cities =  CHtml::listData(States::model()->AllListingStatesOfCountry((int) $model->country_id) ,'state_id' , 'state_name') ;
             ?>
		<div class="form-group  col-sm-6  hidden" hint="">
		<?php echo $form->labelEx($model, 'state_id'); 
		 
		echo $form->dropDownList($model,'state_id',   $cities ,array("class"=>"select2", "empty"=>"Select Region*","style"=>";")); 
		?>
		 
		<?php echo $form->error($model, 'state_id');?>
		<div class="clear"></div>
		</div>
</div>
	<div class="clearfix"></div>

				 
		 			 
			 
					<div class="clearfix"></div>
				 <div class="clearfix"></div>
					 		<div class="form-group  col-sm-12" hint="">
					 
					<?php
					if(!$model->isNewRecord and !Yii::app()->request->isPostRequest){
						$model->languages_known = CHtml::listData($model->moreLanguages,'language_id','language_id');
						//print_r(	$model->service_offerng_detail);
						 
					}
					$datas = CHtml::listData(Language::model()->listData(),'language_id','name') ;
					?>
					 
					<?php
					 echo $form->labelEx($model, 'languages_known');
					 echo $form->dropDownList($model, 'languages_known', $datas , $model->getHtmlOptions('languages_known',array( 'data-placeholder'=>$this->tag->getTag('languages','Language(s)'), 'class'=>'select2 form-control' ,'style'=>'width:100%;'		,'multiple'=>true	)			)); ?>
				 
					<?php echo $form->error($model, 'languages_known');?>
					</div>
					<div class="clearfix"></div>
					<div class="clearfix"></div>
							<div class="form-group  col-sm-12" hint="">
					 
					<?php
					if(!$model->isNewRecord and !Yii::app()->request->isPostRequest){
						$model->service_offerng_detail = CHtml::listData($model->moreCategory,'category_id','category_id');
						//print_r(	$model->service_offerng_detail);
						 
					}
					$datas = CHtml::listData(Category::model()->listData(),'category_id','category_name') ;
					?>
					 
					<?php
					 echo $form->labelEx($model, 'service_offerng_detail');
					 echo $form->dropDownList($model, 'service_offerng_detail', $datas , $model->getHtmlOptions('service_offerng_detail',array( 'data-placeholder'=>$this->tag->getTag('select_your_service_categories','Select your Service Categories'), 'class'=>'select2 form-control' ,'style'=>'width:100%;'		,'multiple'=>true	)			)); ?>
				 
					<?php echo $form->error($model, 'service_offerng_detail');?>
					</div>
					<div class="clearfix"></div>
							 
					      <div class="form-group  col-sm-12"> 
				 
					 
						<?php 
						if(!$model->isNewRecord and !Yii::app()->request->isPostRequest){
						$model->mul_state_id = CHtml::listData($model->moreState,'state_id','state_id');
						 
					}
						 echo $form->labelEx($model, 'mul_state_id');
						echo $form->dropDownList($model, 'mul_state_id', CHtml::listData(States::model()->AllListingStatesOfCountry(COUNTRY_ID),'state_id' , 'state_name') , $model->getHtmlOptions('mul_state_id',array(  'class'=>'select2' ,'style'=>'width:100%;'	,'multiple'=>true	,'data-placeholder'=>$this->tag->getTag('select_service_areas','Select Service Areas')	)			)); ?>
				
				 
					
					<?php echo $form->error($model, 'mul_state_id');?>
					</div>
			
					 		<div class="clearfix"></div>
					 
		
		</div>	
		 <div class="form-group col-lg-3">
				 
		 
				<style>
					.spl-right-side .col-sm-5,	.spl-right-side .col-sm-7{ width:100% !important}
					 .spl-right-side .col-sm-7  label{ display:none; }
					 .spl-right-side .col-sm-5  .bg-warning {background-color: #ddd; margin-bottom:5px;; }
								 .browse_type   .upload-btn-wrapper .btn {   height: 62px !important; width:150px !important; background: #fff;color: var(--logo-color);border-color: var(--logo-color);}
								 .browse_type  .upload-btn-wrapper .btn i  { margin-bottom:5px !important;}
								 .browse_type    .property_img_overlay {     top: 15px;    width: 100%;    z-index: 111;    left: 0px;    right: 0px;}
								 .browse_type    .property_img_overlay  .btn{    padding: 5px;    width: 87%; }
								 .browse_type .dropzone { width:150px !important; }
								 .browse_type .dropzone .dz-message .upload-btn-wrapper {   max-width: unset; }
								.property_img_box {    width: 57px !important;    height: 57px !important;    display: inline-block;    overflow: hidden; float:left !important;}
								html  div.property_img_box div.property_img{    width: 100% !important;    height: 100% !important; display: flex; line-height: 1 !important;   }
								html .property_img_box .property_img img{    width: 100% !important;   }
								#abc_u_crdoc label{ display:none; }
								</style>
								<?php  $user = $model; ?>
					 	
				 <div class="form-group margin-bottom-0 ">

						    <div class="row">
                          
                            <?php 
										$fileField = 'image';
										$title_text =  $this->tag->getTag('photo','Photo');
										$types = '.png,.jpg,.jpeg';
										$maxFiles = '1';
										?>
							 

							<div class="col-sm-12 nolabel">

							  <?php
							  
									 
										$this->renderPartial('root.apps.frontend.new-theme.views.member._file_field_browse',compact('form','fileField','maxFilesize','types','maxFiles','model','title_text','user'));
										
		  
		 
							?>
						 

							</div>

							</div>
			 	<div class="clearfix"><!-- --></div>	
			 	</div>	
			 				<div class="form-group margin-bottom-0 ">

	 	</div> 				 
				
			 	<div class="clearfix"><!-- --></div>	
			  
					
		</div>		 				
	</div></div>
				<div id="" class="clearfix"></div>
				<a href="javascript:void(0)" onclick="$('#signup3-form').submit();" class="btn btn_1 rounded full-width container_signup_form   "  style="background:var(--secondary-color);max-width:300px; " id="bb"><?php echo $text ;?>  </a>
				<?php $this->endWidget();?>
					<div id="" class="clearfix"></div>
				<div id="" class="clearfix" style="margin-top:20px; "></div>
					 <div class="form-group focusbox">
					<div class="col-sm-12 nopaddingLR">
							<div class="df_line" style="padding: 0;">
						 
						</div>
						 
					</div>
				</div>
			
  </aside>
	</div>

	</div>
	</div> 
	<script>
    var iti; 
    function validateThisInp(){
      
    var number1 = iti.getNumber();
    $('input[name="ListingUserAgent[full_number]"]').val(number1);
    }	 
    var input = document.querySelector("#<?php echo $model->modelName;?>_phone");
    $(function(){
     window.intlTelInput(input, {
      // allowDropdown: false,
      // autoHideDialCode: false,
      // autoPlaceholder: "off",
      // dropdownContainer: document.body,
      // excludeCountries: ["us"],
      // formatOnDisplay: false,
      // geoIpLookup: function(callback) {
      //   $.get("http://ipinfo.io", function() {}, "jsonp").always(function(resp) {
      //     var countryCode = (resp && resp.country) ? resp.country : "";
      //     callback(countryCode);
      //   });
      // },
 
        initialCountry: "<?php echo COUNTRY_CODE;?>",
      // localizedCountries: { 'de': 'Deutschland' },
      // nationalMode: false,
       // onlyCountries: ['sa', 'ae' ],
       placeholderNumberType: "MOBILE",
      // preferredCountries: ['cn', 'jp'],
            separateDialCode: true,  hiddenInput: "full_number",
      utilsScript: "<?php echo Yii::app()->apps->getBaseUrl('assets/js/build/js/utils.js');?>",
    });
      iti = window.intlTelInputGlobals.getInstance(input);
    })
     function openUpdatorN(id){
					// $('#imgd').addClass('hidden');
					 $('#abc_'+id).removeClass('hidden');
					 $('#div_view_'+id).addClass('hidden');
				 }
				 $('#ListingUserAgent_mul_state_id,#ListingUserAgent_service_offerng_detail,#ListingUserAgent_languages_known').select2();
   
var setect = '<?php echo $this->tag->getTag('select','Select');?>';
$(function(){	 $('select').select2({  minimumResultsForSearch: -1,allowClear: true , placeholder:setect});  })
</Script> 
<style>
.select2  { width:100% !important; }
</style>
 
	
   <style>
     .pwdopsdiv { display:none ; } .pwdstrengthstr , .pwdstrength { height:auto; }
       
   </style>
