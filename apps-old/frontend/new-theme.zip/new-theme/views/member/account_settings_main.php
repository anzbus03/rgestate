<?php defined('MW_PATH') || exit('No direct script access allowed');  ?>
 
          <div class="row">
            <div class="col-md-12 d-flex align-items-stretch grid-margin">
              <div class="row flex-grow">
                <div class="col-12">
                  <div class="">
                    <div class="">
                      <h3 class="pageHeading">Account Settings</h3>
                      <?php $this->renderPartial('account_settings');?>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
        

 
