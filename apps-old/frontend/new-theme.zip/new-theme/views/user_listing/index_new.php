<div id="map_locator">
	<?php   echo $this->renderPartial('_index_ajax');	 ?> 
 
</div>
 
