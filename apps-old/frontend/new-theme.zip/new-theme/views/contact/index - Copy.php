<div class="clearfix"></div>
  <!-- Header Container / End --> 

<!-- Content
================================================== -->
<style>
.success-modal > div{ height: unset; }
.success-modal .info {
 
    z-index: 11111111;
    position: relative;

}
</style>
<!-- Map Container -->
 
<div class="clearfix"></div>
<!-- Map Container / End -->

 <!-- Container / Start -->
<div class="container margin-top-100">

	<div class="row">

		<!-- Contact Details -->
		 <div class="col-md-3"></div>
		<!-- Contact Form -->
	 
		<div class="col-md-6">
		<div class="success-modal visible margin-top-60">
        <div class="anim">
            <div class="container22">
                <svg width="580" height="400" xmlns="http://www.w3.org/2000/svg">
                 <!-- Created with Method Draw - http://github.com/duopixel/Method-Draw/ -->
                 <g>
                  <circle id="circle" r="80" cy="191.5" cx="294" stroke-width="10" stroke="#fff" fill="none" style="visibility: visible; stroke-dasharray: 502.655px, 0px; stroke-dashoffset: 502.655px; transition: stroke-dashoffset 1s ease-out 0s, stroke-dasharray 1s ease-out 0s; stroke-opacity: 1;fill:#56ccf2"></circle>
                  <g id="popGroup" style="visibility: visible; transition: stroke-dashoffset 0.2s ease-in-out 0s, stroke-dasharray 0.2s ease-in-out 0s; stroke-opacity: 1;">
                   <line stroke="#fff" stroke-linecap="butt" stroke-linejoin="null" id="svg_2" y2="77.981489" x2="291.5" y1="98" x1="291.5" fill-opacity="null" stroke-opacity="null" stroke-width="5" fill="none" style="visibility: visible; stroke-dasharray: 0px, 20.0185px; stroke-dashoffset: 0px; transition: stroke-dashoffset 0.2s ease-in-out 0s, stroke-dasharray 0.2s ease-in-out 0s; stroke-opacity: 1;"></line>
                  <line transform="rotate(45 375.49999999999994,123.99074554443358) " stroke="#fff" stroke-linecap="butt" stroke-linejoin="null" id="svg_3" y2="113.981489" x2="375.5" y1="134" x1="375.5" fill-opacity="null" stroke-opacity="null" stroke-width="5" fill="none" style="visibility: visible; stroke-dasharray: 0px, 20.0185px; stroke-dashoffset: 0px; transition: stroke-dashoffset 0.2s ease-in-out 0s, stroke-dasharray 0.2s ease-in-out 0s; stroke-opacity: 1;"></line>
                  <line transform="rotate(90 398.50000000000006,198.99075317382815) " stroke="#fff" stroke-linecap="butt" stroke-linejoin="null" id="svg_4" y2="188.981489" x2="398.5" y1="209" x1="398.5" fill-opacity="null" stroke-opacity="null" stroke-width="5" fill="none" style="visibility: visible; stroke-dasharray: 0px, 20.0185px; stroke-dashoffset: 0px; transition: stroke-dashoffset 0.2s ease-in-out 0s, stroke-dasharray 0.2s ease-in-out 0s; stroke-opacity: 1;"></line>
                  <line transform="rotate(135 363.5,274.99075317382807) " stroke="#fff" stroke-linecap="butt" stroke-linejoin="null" id="svg_5" y2="264.981489" x2="363.5" y1="285" x1="363.5" fill-opacity="null" stroke-opacity="null" stroke-width="5" fill="none" style="visibility: visible; stroke-dasharray: 0px, 20.0185px; stroke-dashoffset: 0px; transition: stroke-dashoffset 0.2s ease-in-out 0s, stroke-dasharray 0.2s ease-in-out 0s; stroke-opacity: 1;"></line>
                  <line transform="rotate(-180 285.5,299.99072265625) " stroke="#fff" stroke-linecap="butt" stroke-linejoin="null" id="svg_6" y2="289.981489" x2="285.5" y1="310" x1="285.5" fill-opacity="null" stroke-opacity="null" stroke-width="5" fill="none" style="visibility: visible; stroke-dasharray: 0px, 20.0185px; stroke-dashoffset: 0px; transition: stroke-dashoffset 0.2s ease-in-out 0s, stroke-dasharray 0.2s ease-in-out 0s; stroke-opacity: 1;"></line>
                  <line transform="rotate(-135 201.49999999999997,268.99072265625) " stroke="#fff" stroke-linecap="butt" stroke-linejoin="null" id="svg_7" y2="258.981489" x2="201.5" y1="279" x1="201.5" fill-opacity="null" stroke-opacity="null" stroke-width="5" fill="none" style="visibility: visible; stroke-dasharray: 0px, 20.0185px; stroke-dashoffset: 0px; transition: stroke-dashoffset 0.2s ease-in-out 0s, stroke-dasharray 0.2s ease-in-out 0s; stroke-opacity: 1;"></line>
                  <line transform="rotate(-90 183.50000000000003,197.99075317382812) " stroke="#fff" stroke-linecap="butt" stroke-linejoin="null" id="svg_8" y2="187.981489" x2="183.5" y1="208" x1="183.5" fill-opacity="null" stroke-opacity="null" stroke-width="5" fill="none" style="visibility: visible; stroke-dasharray: 0px, 20.0185px; stroke-dashoffset: 0px; transition: stroke-dashoffset 0.2s ease-in-out 0s, stroke-dasharray 0.2s ease-in-out 0s; stroke-opacity: 1;"></line>
                  <line stroke="#fff" transform="rotate(-45 207.49999999999997,127.99075317382812) " stroke-linecap="butt" stroke-linejoin="null" id="svg_9" y2="117.981489" x2="207.5" y1="138" x1="207.5" fill-opacity="null" stroke-opacity="null" stroke-width="5" fill="none" style="visibility: visible; stroke-dasharray: 0px, 20.0185px; stroke-dashoffset: 0px; transition: stroke-dashoffset 0.2s ease-in-out 0s, stroke-dasharray 0.2s ease-in-out 0s; stroke-opacity: 1;"></line>
                 </g>
                   <g id="tick" style="visibility: visible; transition: stroke-dashoffset 0.2s ease-out 0s, stroke-dasharray 0.2s ease-out 0s; stroke-opacity: 1;">
                   <line id="tick1" stroke="#fff" stroke-linecap="null" stroke-linejoin="null" y2="218.000001" x2="291.500001" y1="200" x1="263.5" fill-opacity="null" stroke-opacity="null" stroke-width="10" fill="none" style="visibility: visible; stroke-dasharray: 33.2866px, 0px; stroke-dashoffset: 33.2866px; transition: stroke-dashoffset 0.2s ease-out 0s, stroke-dasharray 0.2s ease-out 0s; stroke-opacity: 1;"></line>
                   <line id="tick2" transform="rotate(10.907037734985352 306.99999999999994,186.49999999999983) " stroke="#fff" stroke-linecap="null" stroke-linejoin="null" y2="156.999997" x2="319.500001" y1="216" x1="294.5" fill-opacity="null" stroke-opacity="null" stroke-width="10" fill="none" style="visibility: visible; stroke-dasharray: 51.2625px, 12.8156px; stroke-dashoffset: 64.0781px; transition: stroke-dashoffset 0.2s ease-out 0s, stroke-dasharray 0.2s ease-out 0s; stroke-opacity: 1;"></line>
                  </g>
                </g>
            </svg>
            </div>
        </div>
        <div class="info">
            <div class="title">Success!</div>
            <div class="text">Your request successfully send!</div>
            <a href="<?php echo Yii::App()->createUrl('contact/index');?>" style="display:block;margin:20px auto;max-width:200px;" class="continue" data-dismiss=" ">Continue</a>
        </div>
    </div>
		
		</div>
		
		 <div class="col-md-3"></div>
		<!-- Contact Form / End -->

	</div>

</div>
<div></div>
<!-- Container / End -->


<Script>
 Moveit.put(popGroup, {
          start: '0%',
          end: '0%',
          visibility: 0
        });
        Moveit.put(tick, {
          start: '0%',
          end: '0%',
          visibility: 0
        });
        Moveit.put(tick2, {
          start: '0%',
          end: '0%',
          visibility: 0
        });
        Moveit.put(circle, {
          start: '0%',
          end: '0%',
          visibility: 0
        });

        Moveit.animate(circle, {
            visibility: 1,
            start: '0%',
            end: '100%',
            duration: 1,
            delay: 0,
            timing: 'ease-out'
        })
        Moveit.animate(tick, {
            visibility: 1,
            start: '0%',
            end: '100%',
            duration: 0.2,
            delay: 0.5,
            timing: 'ease-out'
        })
        Moveit.animate(tick2, {
            visibility: 1,
            start: '0%',
            end: '80%',
            duration: 0.2,
            delay: 0.7,
            timing: 'ease-out'
        })
        Moveit.animate(popGroup, {
            visibility: 1,
            start: '20%',
            end: '60%',
            duration: 0.2,
            delay: 1.,
            timing: 'ease-in'
        }).animate(popGroup, {
            visibility: 1,
            start: '100%',
            end: '100%',
            duration: 0.2,
            delay: 1.2,
            timing: 'ease-in-out'
        });
</Script>




















