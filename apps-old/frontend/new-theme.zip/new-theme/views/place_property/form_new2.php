<?php defined('MW_PATH') || exit('No direct script access allowed');
$this->renderPartial('//place_property/form_new2', compact('model',"country","section",'list_type','image_array','option'));
?>