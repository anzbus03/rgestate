<?php defined('MW_PATH') || exit('No direct script access allowed');?>

<div class="container">

	<div class="row">
	
		<div class="col-md-12">
        <!--Tabs -->
        <div class=" " >
         
          <div class="tabs-container alt" > 
 <h4 class="subheading_font row bold-style"><?php echo $this->tag->getTag('successfully_saved.','Successfully Saved.');?></h4>
            <!-- Login -->
			<div class="tab-content" id="tab1"  style="border-top: 0px  ;padding-top:0px;">
		 	<div class="tab_container no-margin no-padding">

<div id="tab1" class="tab_content active_content" id="fbsignin-form">
	 <div class="form">
		 <div class="emil_img text-center" style="color:var(--secondary-color);"><svg height="150" viewBox="-3 0 512 512" width="150" xmlns="http://www.w3.org/2000/svg"><g><path d="m0 232.917969h43.605469v52.328125h-43.605469zm0 0" data-original="#000000" class="active-path" data-old_color="#000000"  ></path><path d="m104.65625 311.410156h43.605469v34.957032c0 9.59375-7.777344 17.371093-17.371094 17.371093h-26.234375zm0 0" data-original="#000000" class="active-path" data-old_color="#000000" fill="currentColor"></path><path d="m169.15625 226.542969 162.25-72.117188v209.3125l-162.25-72.117187zm0 0" data-original="#000000" class="active-path" data-old_color="#000000" fill="currentColor"></path><path d="m61.046875 311.410156h52.328125v95.933594h-52.328125zm0 0" data-original="#000000" class="active-path" data-old_color="#000000" fill="currentColor"></path><path d="m444.785156 6.164062-69.769531 69.773438v61.046875h61.046875l69.769531-69.769531zm-30.523437 104.65625c-7.226563 0-13.082031-5.855468-13.082031-13.082031 0-7.222656 5.855468-13.082031 13.082031-13.082031 7.222656 0 13.082031 5.859375 13.082031 13.082031 0 7.226563-5.859375 13.082031-13.082031 13.082031zm0 0" data-original="#000000" class="active-path" data-old_color="#000000" fill="currentColor"></path><path d="m59.933594 198.035156h89.445312c13.832032 0 25.046875 11.214844 25.046875 25.046875v72.003907c0 13.832031-11.214843 25.046874-25.046875 25.046874h-89.445312c-13.835938 0-25.050782-11.214843-25.050782-25.046874v-72.003907c0-13.832031 11.214844-25.046875 25.050782-25.046875zm0 0" data-original="#000000" class="active-path" data-old_color="#000000" fill="currentColor"></path><path d="m419.492188 346.546875-61.667969 61.671875 86.339843 86.339844 61.667969-61.667969zm5.496093 88.871094c-4.289062-.332031-7.695312-3.742188-8.023437-8.03125l-4.1875-54.386719 17.390625-1.335938 3.609375 46.941407 47.90625 3.679687-1.332032 17.390625zm0 0" data-original="#000000" class="active-path" data-old_color="#000000" fill="currentColor"></path><path d="m479.667969 206.753906c0 14.453125-11.710938 26.164063-26.164063 26.164063-14.449218 0-26.160156-11.710938-26.160156-26.164063 0-14.449218 11.710938-26.164062 26.160156-26.164062 14.453125 0 26.164063 11.714844 26.164063 26.164062zm0 0" data-original="#000000" class="active-path" data-old_color="#000000" fill="currentColor"></path><path d="m444.949219 241.640625h17.121093c14.539063.003906 26.320313 11.792969 26.320313 26.328125v43.441406h-69.769531v-43.441406c0-14.539062 11.789062-26.328125 26.328125-26.328125zm0 0" data-original="#000000" class="active-path" data-old_color="#000000" fill="currentColor"></path><path d="m409.898438 215.476562c0 9.632813-7.808594 17.441407-17.441407 17.441407-9.632812 0-17.441406-7.808594-17.441406-17.441407 0-9.632812 7.808594-17.441406 17.441406-17.441406 9.632813 0 17.441407 7.808594 17.441407 17.441406zm0 0" data-original="#000000" class="active-path" data-old_color="#000000" fill="currentColor"></path><path d="m392.457031 241.640625c14.449219 0 26.164063 11.714844 26.164063 26.164063v26.164062h-52.328125v-26.164062c0-14.449219 11.714843-26.164063 26.164062-26.164063zm0 0" data-original="#000000" class="active-path" data-old_color="#000000" fill="currentColor"></path><path d="m328.851562 12.332031-12.332031-12.332031-53.277343 53.261719c-27.101563-20.28125-65.515626-14.753907-85.796876 12.347656s-14.753906 65.515625 12.347657 85.796875c27.105469 20.285156 65.515625 14.753906 85.800781-12.347656 16.292969-21.773438 16.292969-51.675782 0-73.449219zm-102.097656 133.375c-24.085937 0-43.609375-19.523437-43.609375-43.605469 0-24.085937 19.523438-43.609374 43.609375-43.609374 24.082032 0 43.605469 19.523437 43.605469 43.609374-.027344 24.070313-19.535156 43.574219-43.605469 43.605469zm0 0" data-original="#000000" class="active-path" data-old_color="#000000" fill="currentColor"></path><path d="m235.472656 363.738281h-34.882812l-52.328125 52.328125 95.933593 95.933594 69.769532-69.769531zm-41.050781 63.605469 34.886719-34.886719 12.332031 12.332031-34.886719 34.886719zm38.496094 38.496094-12.332031-12.332032 34.886718-34.886718 12.332032 12.332031zm0 0" data-original="#000000" class="active-path" data-old_color="#000000" fill="currentColor"></path></g> </svg></div>
		<?php
		if($option=='update'){
		    ?>
		     <h2 class="large_h2 text-center" ><?php echo Yii::t('app',$this->tag->getTag('your_property_has_been_update','Your property has been successfully [BR] updated on [SITE]'),array('[BR]'=>'<br />','[SITE]'=>$this->project_name));?></h2>
		    <?php
		    
		}
		else{ ?> 
		 <h2 class="large_h2 text-center" ><?php echo Yii::t('app',$this->tag->getTag('your__property_has_been_succes','Your property has been successfully uploaded on [SITE]'),array('[SITE]'=>$this->project_name));?>
    </h2>
		 <?php } ?>
	 			<style>
	 			    .btn.update-btn ,   .btn.view-btn ,  .btn.post-new{ width: 114px;

display: inline-block;

font-size: 15px !important;

padding: 8px 10px !important;

height: auto !important;

line-height: 24px;

border-radius: 5px !important; margin-right:10px ; }
.mrs-new-buttons a.btn { width: auto !important; padding: 8px 20px !important;}
html[dir="rtl"] .fa-arrow-left::before {    content: "\f061";    margin-left: 10px; }
html[dir="rtl"] .btn i { margin-right: 0; margin-left: 0.3125rem;  }
.btn.post-new { background: var(--secondary-color); border:1px solid  var(--secondary-color);;}
.update-btn1	 	 { background: var(--logo-color)!important; border:1px solid  var(--logo-color) !important;}		  
	 			</style>
						<div class="text-center margin-top-20 mrs-new-buttons">
						      	<a href="<?php echo Yii::app()->createUrl('member/dashboard');?>" class="btn btn-secondary update-btn update-btn1 margin-bottom-10" ><div style="display:flex;line-height: 1.6;align-items: center;white-space:nowrap"><i class="fa fa-arrow-left"></i> <?php echo $this->tag->getTag('dashboard','Dashboard');?></div></a>
						
						    	<a href="<?php echo Yii::app()->createUrl('place_an_ad/update',array('slug'=>$ad->slug));?>" class="btn btn-warning update-btn margin-bottom-10" ><i class="fa fa-pencil"></i> <?php echo $this->tag->getTag('edit','Edit');?></a>
							<?php
							if($ad->status=='A'){ ?> 
							<a href="<?php echo $ad->DetailUrl;?>" class="btn btn-secondary view-btn margin-bottom-10" ><i class="fa fa-eye"></i> <?php echo $this->tag->getTag('view','View');?></a>
						    <?php } ?> 
							<a href="<?php echo Yii::app()->createUrl('place_an_ad/create');?>" class="btn btn-danger  post-new margin-bottom-10"   ><i class="fa fa-plus"></i> <?php echo $this->tag->getTag('post_new','Post New');?></a>
					 		</div>
							<span id="login-form"> </span>
		<div id="register-head">
		 
			    <?php  
				
				$form = $this->beginWidget('CActiveForm',array( 
				'enableAjaxValidation'=>true,
				'htmlOptions' =>array('id'=>'form-account-logina','data-abide'=>'','style'=>''),
				'clientOptions' => array(
				'validateOnSubmit'=>true,
				),
				)); 
				;?>
				<button data-layer-action="login" style="margin-top:0px; width:100%;  " id="resend_btn" class="hide btn red awesome fbsignin-button headfont" name="resent" value="resent" type="submit"  ><i class="fa fa-mail-forward"></i> Resent Verification Email</button>
				<?php $this->endWidget();?>
			<div class="clear"></div>
		</div>
	
		 <!-- end #right-col -->
		<div class="clearfix"></div>
	</div>
	<div class="clearfix"></div>
</div><!-- end #tab1 -->

		 
		</div><!-- end .tab_container -->
	
			</div>

			<!-- Register -->
		 
            </div>
          </div>
       

		

		</div>
	 
		<div class="col-md-4 hide"> 
		<div class="description-item"><i class="description-star-icon description-icon my-i"></i> <h3 class="description-title">Don’t receive th email ?</h3>
		 <p >1. Is <a href="mailto:<?php echo $model->email;?>" class="link_color"><?php echo $model->email;?></a> your correct email without typos? If not <a href="<?php echo Yii::app()->createUrl('user/signup');?>"> you can restart the signup process </a></p>
		 <p >2. Check your spam folder </p>
		 <p >3. Click <a href="javascript:void(0)" onclick="$('#resend_btn').click();"  class="link_color">here</a> to resend the  email </p>
		 
		 </div>
		 <div class="clearfix"></div>
		 <div style="position:relative;">
		<div class="description-item"><i class="description-open-icon description-icon my-i"></i> <h3 class="description-title">Still having trouble?</h3>
		 <p class="description-content"><a href="<?php echo Yii::app()->createUrl('contact/index');?>"  class="link_color">Contact Us</a></p>
		</div>
		</div>
		
		
		 	</div>
	</div>

</div>
  
<style>input, input[type=text], input[type=password], input[type=email], input[type=number], textarea, select {
    	height: 51px;
            line-height: 51px;
            padding: 0 20px;
            outline: 0;
            font-size: 15px;
            color: gray;
            margin: 0 0 16px;
            max-width: 100%;
            width: 100%;
            box-sizing: border-box;
            display: block;
            background-color: #fff;
            border: 1px solid #dbdbdb;
            box-shadow: 0 1px 3px 0 rgba(0,0,0,.06);
            font-weight: 500;
            opacity: 1;
            border-radius: 3px;
    margin-left: 0 !important;
    width:100%;
}.no-padding-left{padding-left:0px;}.no-padding-right{padding-right:0px;}.pull-right{ float:right;}.forgotpassword a{color:#82addc !important;}</style>
