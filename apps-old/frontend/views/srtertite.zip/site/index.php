<?php   $this->widget('frontend.components.web.widgets.home_banner.HomeBannerWidget'); ?>
<!-- Content
            ================================================== -->
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <h3 class="headline  margin-top-40 col-md-12 no-margin-left "> Explore Askaan </h3>
               </div>
            </div>
         </div>
         <!-- Category Boxes -->
         <div class="container">
            <div class="row">
               <div class="col-md-12 home_exp_sec">
				   <a href="<?php echo Yii::app()->createUrl('listing/index',array('country'=>$this->default_country_slug,'type_of[]'=>'33'));?>">
                  <div class="col-md-3">
                     <div class="spanstyle">
                        <div class="col-md-4" style="padding: 0px;"><img src="<?php echo $this->appAssetUrl('images/Offices.jpg');?>" alt=""> </div>
                        <div class="col-md-8 spanfontstyle">
                           <h3>Offices</h3>
                           <p>
                           <i>Offices</i> in <?php echo $default_country_name;?>.
                           </p>
                        </div>
                     </div>
                  </div>
                  </a>
                   <a href="<?php echo Yii::app()->createUrl('listing/index',array('country'=>$this->default_country_slug,'type_of[]'=>'31'));?>">
                  <div class="col-md-3">
                     <div class="spanstyle">
                        <div class="col-md-4" style="padding: 0px;"><img src="<?php echo $this->appAssetUrl('images/Villas.jpg');?>" alt=""> </div>
                        <div class="col-md-8 spanfontstyle">
                           <h3>Villas</h3>
                            <p>
                           <i>Villas</i> in <?php echo $default_country_name;?>.
                           </p>
                        </div>
                     </div>
                  </div>   </a>
                   <a href="<?php echo Yii::app()->createUrl('listing/index',array('country'=>$this->default_country_slug,'type_of[]'=>'30'));?>">
                  <div class="col-md-3">
                     <div class="spanstyle">
                        <div class="col-md-4" style="padding: 0px;"><img src="<?php echo $this->appAssetUrl('images/Apartments.jpg');?>" alt=""> </div>
                        <div class="col-md-8 spanfontstyle">
                           <h3>Apartments  </h3>
                           <p>
                           <i>Apartments</i> in <?php echo $default_country_name;?>.
                           </p>
                        </div>
                     </div>
                  </div>
                  </a> <a href="<?php echo Yii::app()->createUrl('listing/index',array('country'=>$this->default_country_slug,'type_of[]'=>'32'));?>">
                  <div class="col-md-3">
                     <div class="spanstyle">
                        <div class="col-md-4" style="padding: 0px;"><img src="<?php echo $this->appAssetUrl('images/Land.jpg');?>" alt=""> </div>
                        <div class="col-md-8 spanfontstyle">
                           <h3>Land</h3>
                           <p>
							    <i>Lands</i> in <?php echo $default_country_name;?>.
                           </p>
                        </div>
                     </div>
                  </div> </a>
               </div>
            </div>
         </div>
       <style>  .item_ko:nth-child(4n+1){ clear:both; }  .developer_logo { position: absolute;right: 7px;bottom: 57px;z-index: 1111;}
       </style>
       <div class="home_section">
        <div class="item homer">
		<?php
			   if($featued_banners){ ?> 
               <section class="fullwidth  padding-top-40 padding-bottom-0" id="">
                  <div class="container">
                     <div class="row">
                        <div class="col-md-12">
						<?php 
						if(!empty($featured_text) and !empty($featured_text->header_text)){
							$header_text = unserialize($featured_text->header_text); 
							echo '<h3 class="headline margin-bottom-0 col-md-12 no-margin-left">'.@$header_text['row1'].'</h3>';
						}
						else{
							echo '<h3 class="headline margin-bottom-0 col-md-12 no-margin-left">Featured Projects  in MENA Region</h3>';
						}
						?>
                        </div>
                        <div class="col-md-12 col-sm-12">
                           <div class="simple-slick-carousel dots-nav spandots_01  " style="margin-bottom: 0px;">
                              <!-- Listing Item -->
                              <?php
                              foreach($featued_banners as $k=>$v){ ?> 
                              <div class="carousel-item featured_pro item_ko_100">
                                 <div class="listing-item spanimgsize">
									<?php   $image = $v->AdImage ;?>
                                    <a href="<?php echo $v->detailUrl;?>" ><img src="<?php echo $this->app->apps->getBaseUrl('timthumb.php');?>?src=<?php   echo  $image   ;?>&h=300&w=1044&zc=1" alt=""></a>
                                    <div class="listing-item-content spansec01">
                                       <h3> <?php echo $v->adTitle;?>.
                                       </h3>
                                       <a href="<?php echo $v->DetailUrl;?>" class="button">View</a> 
                                    </div>
                                 </div>
                              </div>
                              <?php 
                              }
                              ?> 
                              
                              <!-- Listing Item / End --> 
                              <!-- Listing Item --> 
                              <!-- Listing Item / End --> 
                              <!-- Listing Item --> 
                              <!-- Listing Item / End --> 
                           </div>
                        </div>
                     </div>
                  </div>
               </section>
               <?php } ?> 
		</div>
		<div class="clearfix"></div>
		</div>
         <style>
         ._12n1ibqr span {
    margin: 0px !important;
    overflow-wrap: break-word !important;
    font-size: 15px !important;
    line-height: 22px !important;
    letter-spacing: normal !important;
    padding-top: 0px !important;
    color:rgb(72, 72, 72);
   }
   ._1ws65d6 {
    border-top: 1px solid rgba(0, 0, 0, 0.1) !important;
    border-bottom: 1px solid rgba(0, 0, 0, 0.1) !important;
    padding-top: 24px !important;
    padding-bottom: 24px !important;
    margin-top: 24px !important;
    margin-bottom: 24px !important;
}
._1v8tiivp {
    -moz-box-pack: center !important;
    -moz-box-align: center !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    margin: 0px auto !important;
    width: 85% !important;
    max-width: 1100px !important;
}
._1671pmsc {
    margin-right: 12px !important;
    padding-right: 12px !important;
    width: 45% !important;
    height: 100% !important;
float: left !important;
}

._18q6tiq {
    position: relative !important;
    width: 100% !important;
    z-index: 0 !important;
}
._1szwzht {
    position: absolute !important;
    top: 0px !important;
    bottom: 0px !important;
    left: 0px !important;
    right: 0px !important;
    height: 100% !important;
    width: 100% !important;
}
._e296pg {
    position: relative !important;
}
._6ikqekk {
    position: absolute !important;
    background-position: 50% 50% !important;
    background-repeat: no-repeat !important;
    animation-name: keyframe_18jn58a !important;
    animation-duration: 300ms !important;
    animation-timing-function: ease-out !important;
    background-size: cover !important;
}
._ynnb8vg {
    text-align: left !important;
}
._ynnb8vg {
    white-space: normal !important;
}
._d2f3gw {
    margin-bottom: 8px !important;
}
._7c46qo2 {
    margin: 0px !important;
    overflow-wrap: break-word !important;
    font-size: 16px !important;
    line-height: 22px !important;
    padding-top: 0px !important;
    padding-bottom: 0px !important;
    color: rgb(72, 72, 72) !important;
    font-weight: 700 !important;
}
._74l3jy {
    font-size: 19px !important;
    line-height: 26px !important;
    letter-spacing: normal !important;
    padding-top: 0px !important;
    padding-bottom: 0px !important;
    color: rgb(72, 72, 72) !important;
}
._12n1ibqr {
    margin: 0px !important;
    overflow-wrap: break-word !important;
    font-size: 14px !important;
    line-height: 18px !important;
    letter-spacing: normal !important;
    padding-top: 0px !important;
    padding-bottom: 0px !important;
    color: rgb(72, 72, 72) !important;
    font-weight: 300 !important;
}
._16syclo {
    letter-spacing: 0.2px !important;
    font-size: 17px !important;
}
._16tkiskg::-moz-focus-inner {
    border: 0px none !important;
    padding: 0px !important;
    margin: 0px !important;
}
._16tkiskg {
    cursor: pointer !important;
    display: inline-block !important;
    margin: 0px !important;
    position: relative !important;
    text-align: center !important;
    text-decoration: none !important;
    transition-property: background, border-color, color !important;
    transition-duration: 0.2s !important;
    transition-timing-function: ease-out !important;
    width: auto !important;
    border-radius: 4px !important;
    font-size: 14px !important;
    line-height: 18px !important;
    padding: 8px 16px !important;
    font-weight: normal !important;
    border-width: 1px !important;
    border-style: solid !important;
    min-width: 51.7771px !important;
    background: rgb(0, 132, 137) none repeat scroll 0% 0% !important;
    border-color: transparent !important;
    color: rgb(255, 255, 255) !important;
}
._l8z70zb {
    font-size: 14px !important;
    line-height: 18px !important;
    padding-top: 0px !important;
    padding-bottom: 0px !important;
    color: inherit !important;
}

         </style>
		<div class="home_section">
		<?php 
	    $Ar_ad = array();
		foreach($advertisement_layout as $k=>$v){
			$Ar_ad[$k] = array('advertisemen_id'=>$v->advertisemen_id,'title'=>$v->header_text);
		}
		 
		$i=1;
		foreach($countries_list as $k=>$country){
			if($k%2=='0' and $k!='0'){
				if(isset($Ar_ad[$i])){
				$row = $Ar_ad[$i];$i++;
				echo $this->renderPartial('_ad_section',compact('row'));
				}
			}
	    	echo $this->renderPartial('_section',compact('country','k'));
		}   
		?>
		<div class="clearfix"></div>
		</div>
         
